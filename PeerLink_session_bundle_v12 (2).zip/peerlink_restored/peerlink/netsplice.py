"""netsplice — M21: a real network line for the headless game.

The game's online stack (static libcurl + OpenSSL inside libUE4.so)
talks to the internet through normal libc socket imports. Under our
Unicorn harness those imports are ours to service — so we service them
with REAL Python sockets:

    game's socket()   ->  real Python socket
    game's connect()  ->  real TCP connect to the real host
    game's sendto()   ->  real bytes on the wire
    game's recvfrom() ->  real server response into game memory

The game's own code then does everything else by itself: DNS-shape
handling, TLS handshake + crypto, msgpack bodies, RSA signing, KGS
flow. Nothing is forged, nothing is reimplemented — the same native
code a real app runs, now with a wire.

Self-test (this file's __main__): resolve + connect + HTTP GET to the
NTL host THROUGH the game's own PLT surface, then run the online-config
registrars and dump the live config — everything the game needs to go
online, in one place.

Usage:
    python -m peerlink.netsplice            # full self-test
"""
from __future__ import annotations

import errno as _pyerrno
import os
import select as _pyselect
import socket as _pysock
import struct
import time

from unicorn import UcError
from unicorn.arm64_const import (
    UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3,
    UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_PC, UC_ARM64_REG_LR,
    UC_ARM64_REG_SP,
)

# the socket-surface symbols we service with real implementations
NETSYMS = (
    "socket", "connect", "shutdown", "close",
    "sendto", "sendmsg", "recvfrom", "recvmsg",
    "select", "setsockopt", "fcntl", "ioctl",
    "getaddrinfo", "freeaddrinfo", "gethostbyname", "gethostname",
    "open", "read", "write", "fstat",
    "epoll_create", "epoll_create1", "epoll_ctl", "epoll_wait",
    "clock_gettime", "gettimeofday",
)

AF_INET, AF_INET6 = 2, 10
SOCK_STREAM, SOCK_DGRAM = 1, 2
SOL_SOCKET, SO_REUSEADDR = 1, 2
F_GETFL, F_SETFL = 3, 4
O_NONBLOCK = 0o4000
FIONBIO = 0x8004667E
CLOCK_REALTIME, CLOCK_MONOTONIC = 0, 1
FD_SETSIZE = 1024
EPOLL_CTL_ADD, EPOLL_CTL_DEL, EPOLL_CTL_MOD = 1, 2, 3

_ERRNO = _pyerrno


def _rd(uc, r):
    return uc.reg_read(r)


def _ret(uc, val):
    uc.reg_write(UC_ARM64_REG_X0, val & 0xFFFFFFFFFFFFFFFF)
    uc.reg_write(UC_ARM64_REG_PC, _rd(uc, UC_ARM64_REG_LR))


class OnlineCoreMixin:
    """Real-network socket surface for EFootballCoreV2."""

    def install_netsplice(self):
        """Hijack every NETSYM PLT entry to our handlers. Idempotent."""
        if getattr(self, "_net_installed", False):
            return self
        self._net_installed = True
        self._net_socks = {}          # our fd -> python socket
        self._net_files = {}          # our fd -> 'urandom'
        self._net_flags = {}          # our fd -> os flags (O_NONBLOCK)
        self._net_nextfd = 10
        self._net_epolls = {}         # our fd -> {reg_fd: (events, data)}
        self._net_sock_of_fileno = {}
        import json
        plt = json.load(open(f"{self._AN}/plt_map.json")) \
            if hasattr(self, "_AN") else json.load(open(
                "/home/z/my-project/apk_lab/analysis/plt_map.json"))
        wired = []
        for sym in NETSYMS:
            hits = [(int(k, 16), v) for k, v in plt.items()
                    if v["sym"] == sym]
            if not hits:
                continue
            stub = self._get_stub(f"{sym}_h")
            for _plt_addr, info in hits:
                self.write_u64(self.base + info["got"], stub)
            wired.append(sym)
        if getattr(self, "verbose", False):
            print(f"[netsplice] wired {len(wired)} socket imports: "
                  f"{', '.join(wired)}")
        self._net_wired = wired
        return self

    # ------------------------------------------------------------ dispatch
    def _stub_hook(self, uc, addr, size, ud):
        name = self.stub_of.get(addr, "")
        if name.endswith("_h"):
            name = name[:-2]
        h = _HANDLERS.get(name)
        if h is not None:
            self.import_calls[name] = self.import_calls.get(name, 0) + 1
            try:
                h(self, uc)
            except Exception as e:
                self._log.append(f"netsplice {name}: {type(e).__name__}: {e}")
                _ret(uc, -1)
            return
        super()._stub_hook(uc, addr, size, ud)

    # ------------------------------------------------------------ helpers
    def _newfd(self):
        fd = self._net_nextfd
        self._net_nextfd += 1
        return fd

    def _cstr(self, p, cap=512):
        if not p:
            return b""
        return bytes(self.safe_read(p, cap)).split(b"\0")[0]

    def _set_errno(self, e):
        try:
            a = self._errno_addr()
            self.write_u32(a, int(e) & 0xFFFFFFFF)
        except Exception:
            pass

    def _sock_of(self, fd):
        s = self._net_socks.get(fd)
        if s is None:
            raise OSError(_ERRNO.EBADF, "bad fd")
        return s

    def _parse_sockaddr(self, p, _len):
        """-> (family, python address tuple) or None."""
        if not p or _len < 8:
            return None
        fam = struct.unpack_from("<H", self.safe_read(p, 2))[0]
        if fam == AF_INET:
            raw = self.safe_read(p, 16)
            port = struct.unpack(">H", raw[2:4])[0]
            ip = _pysock.inet_ntop(_pysock.AF_INET, raw[4:8])
            return (AF_INET, (ip, port))
        if fam == AF_INET6 and _len >= 28:
            raw = self.safe_read(p, 28)
            port = struct.unpack(">H", raw[2:4])[0]
            ip = _pysock.inet_ntop(_pysock.AF_INET6, raw[8:24])
            return (AF_INET6, (ip, port))
        return None

    def _fdset_read(self, p):
        """bitmap -> set of our fds present."""
        if not p:
            return set()
        raw = bytes(self.safe_read(p, FD_SETSIZE // 8))
        out = set()
        for byte_i in range(len(raw)):
            b = raw[byte_i]
            for bit in range(8):
                if b & (1 << bit):
                    out.add(byte_i * 8 + bit)
        return out

    def _fdset_write(self, p, fds):
        raw = bytearray(FD_SETSIZE // 8)
        for fd in fds:
            if 0 <= fd < FD_SETSIZE:
                raw[fd // 8] |= 1 << (fd % 8)
        self.uc.mem_write(p, bytes(raw))


# ---------------------------------------------------------------- handlers

def _h_socket(core, uc):
    fam, typ, proto = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                       _rd(uc, UC_ARM64_REG_X2))
    typ &= ~0x40000  # SOCK_NONBLOCK handled via flags lazily
    typ &= ~0x80000  # SOCK_CLOEXEC
    py_fam = _pysock.AF_INET if fam == AF_INET else _pysock.AF_INET6 \
        if fam == AF_INET6 else _pysock.AF_INET
    py_typ = _pysock.SOCK_STREAM if typ == SOCK_STREAM else _pysock.SOCK_DGRAM
    s = _pysock.socket(py_fam, py_typ, 0)
    s.settimeout(10.0)
    fd = core._newfd()
    core._net_socks[fd] = s
    _ret(uc, fd)


def _h_connect(core, uc):
    fd, sa, salen = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                     _rd(uc, UC_ARM64_REG_X2))
    s = core._sock_of(fd)
    pa = core._parse_sockaddr(sa, salen)
    if pa is None:
        core._set_errno(_ERRNO.EAFNOSUPPORT)
        _ret(uc, -1)
        return
    _fam, addr = pa
    try:
        s.settimeout(10.0)
        s.connect(addr)
        _ret(uc, 0)
    except BlockingIOError:
        core._set_errno(_ERRNO.EINPROGRESS)
        _ret(uc, -1)
    except OSError as e:
        core._set_errno(e.errno or _ERRNO.ECONNREFUSED)
        _ret(uc, -1)


def _sock_send(core, uc, fd, data):
    s = core._sock_of(fd)
    try:
        n = s.send(data)
        _ret(uc, n)
    except BlockingIOError:
        core._set_errno(_ERRNO.EAGAIN)
        _ret(uc, -1)
    except OSError as e:
        core._set_errno(e.errno or _ERRNO.EPIPE)
        _ret(uc, -1)


def _h_sendto(core, uc):
    fd, buf, n = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                  _rd(uc, UC_ARM64_REG_X2))
    data = bytes(core.safe_read(buf, n)) if buf and n else b""
    _sock_send(core, uc, fd, data)


def _h_sendmsg(core, uc):
    fd, mh = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    # struct msghdr: name(8) namelen(4+pad) iov(8) iovlen(8) ctrl(8) ctrllen(8) flags(4)
    raw = core.safe_read(mh, 48)
    iov_ptr = struct.unpack_from("<Q", raw, 16)[0]
    iov_cnt = struct.unpack_from("<Q", raw, 24)[0]
    data = b""
    for i in range(min(iov_cnt, 32)):
        ent = core.safe_read(iov_ptr + i * 16, 16)
        base, ln = struct.unpack("<QQ", ent)
        if ln:
            data += bytes(core.safe_read(base, ln))
    _sock_send(core, uc, fd, data)


def _sock_recv_into(core, uc, fd, buf, n):
    s = core._sock_of(fd)
    try:
        data = s.recv(n)
        if buf and data:
            core.uc.mem_write(buf, data)
        _ret(uc, len(data))
    except _pysock.timeout:
        core._set_errno(_ERRNO.EAGAIN)
        _ret(uc, -1)
    except BlockingIOError:
        core._set_errno(_ERRNO.EAGAIN)
        _ret(uc, -1)
    except OSError as e:
        core._set_errno(e.errno or _ERRNO.ECONNRESET)
        _ret(uc, -1)


def _h_recvfrom(core, uc):
    fd, buf, n = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                  _rd(uc, UC_ARM64_REG_X2))
    _sock_recv_into(core, uc, fd, buf, n)


def _h_recvmsg(core, uc):
    fd, mh = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    raw = core.safe_read(mh, 48)
    iov_ptr = struct.unpack_from("<Q", raw, 16)[0]
    iov_cnt = struct.unpack_from("<Q", raw, 24)[0]
    if iov_cnt < 1 or not iov_ptr:
        _sock_recv_into(core, uc, fd, 0, 0)
        return
    ent = core.safe_read(iov_ptr, 16)
    base, ln = struct.unpack("<QQ", ent)
    _sock_recv_into(core, uc, fd, base, min(ln, 0x10000))


def _h_select(core, uc):
    nfds = _rd(uc, UC_ARM64_REG_X0)
    rp, wp, ep, tv = (_rd(uc, UC_ARM64_REG_X1), _rd(uc, UC_ARM64_REG_X2),
                      _rd(uc, UC_ARM64_REG_X3), _rd(uc, UC_ARM64_REG_X4))
    rf = core._fdset_read(rp) if rp else set()
    wf = core._fdset_read(wp) if wp else set()
    xf = core._fdset_read(ep) if ep else set()
    timeout = None
    if tv:
        sec, usec = struct.unpack("<qQ", core.safe_read(tv, 16))
        timeout = min(sec + usec / 1e6, 30.0)
    sock_map = {}
    rf2, wf2, xf2 = [], [], []
    for fd in sorted(rf | wf | xf):
        s = core._net_socks.get(fd)
        if s is not None:
            sock_map[s.fileno()] = fd
            if fd in rf:
                rf2.append(s)
            if fd in wf:
                wf2.append(s)
            if fd in xf:
                xf2.append(s)
    try:
        rr, rw, rx = _pyselect.select(rf2, wf2, xf2, timeout)
    except (OSError, ValueError):
        rr, rw, rx = [], [], []
    rset = {sock_map[s.fileno()] for s in rr}
    wset = {sock_map[s.fileno()] for s in rw}
    xset = {sock_map[s.fileno()] for s in rx}
    if rp:
        core._fdset_write(rp, rset)
    if wp:
        core._fdset_write(wp, wset)
    if ep:
        core._fdset_write(ep, xset)
    _ret(uc, len(rset | wset | xset))


def _h_setsockopt(core, uc):
    fd, lvl, opt = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                    _rd(uc, UC_ARM64_REG_X2))
    valp, vlen = _rd(uc, UC_ARM64_REG_X3), _rd(uc, UC_ARM64_REG_X4)
    s = core._sock_of(fd)
    try:
        if lvl == SOL_SOCKET and opt == SO_REUSEADDR and valp:
            s.setsockopt(_pysock.SOL_SOCKET, _pysock.SO_REUSEADDR, 1)
        # everything else: accept silently
        _ret(uc, 0)
    except OSError:
        _ret(uc, 0)


def _h_shutdown(core, uc):
    fd, how = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    try:
        core._sock_of(fd).shutdown(
            _pysock.SHUT_RDWR if how == 2 else _pysock.SHUT_WR
            if how == 1 else _pysock.SHUT_RD)
    except OSError:
        pass
    _ret(uc, 0)


def _h_close(core, uc):
    fd = _rd(uc, UC_ARM64_REG_X0)
    s = core._net_socks.pop(fd, None)
    if s is not None:
        try:
            s.close()
        except OSError:
            pass
    core._net_files.pop(fd, None)
    core._net_epolls.pop(fd, None)
    _ret(uc, 0)


def _h_fcntl(core, uc):
    fd, cmd, arg = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                    _rd(uc, UC_ARM64_REG_X2))
    if cmd == F_GETFL:
        _ret(uc, core._net_flags.get(fd, 2))
        return
    if cmd == F_SETFL:
        core._net_flags[fd] = arg
        s = core._net_socks.get(fd)
        if s is not None:
            s.setblocking(bool(arg & O_NONBLOCK) is False)
            if arg & O_NONBLOCK:
                s.settimeout(0.0)
            else:
                s.settimeout(10.0)
        _ret(uc, 0)
        return
    _ret(uc, 0)


def _h_ioctl(core, uc):
    fd, req, argp = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                     _rd(uc, UC_ARM64_REG_X2))
    if req == FIONBIO and argp:
        v = struct.unpack("<I", core.safe_read(argp, 4))[0]
        s = core._net_socks.get(fd)
        if s is not None:
            if v:
                s.setblocking(False)
            else:
                s.setblocking(True)
                s.settimeout(10.0)
    _ret(uc, 0)


def _h_getaddrinfo(core, uc):
    nodep, servp, hintsp, resp = (_rd(uc, UC_ARM64_REG_X0),
                                  _rd(uc, UC_ARM64_REG_X1),
                                  _rd(uc, UC_ARM64_REG_X2),
                                  _rd(uc, UC_ARM64_REG_X3))
    node = core._cstr(nodep, 256).decode() if nodep else ""
    serv = core._cstr(servp, 32).decode() if servp else "0"
    fam = _pysock.AF_UNSPEC
    if hintsp:
        h = struct.unpack("<iiii", core.safe_read(hintsp, 16))
        fam = {AF_INET: _pysock.AF_INET, AF_INET6: _pysock.AF_INET6}.get(
            h[1], _pysock.AF_UNSPEC)
    try:
        res = _pysock.getaddrinfo(node, serv, fam, _pysock.SOCK_STREAM)
    except OSError as e:
        core._set_errno(e.errno or _ERRNO.EAI_NONAME)
        _ret(uc, -1)
        return
    head = 0
    prev = 0
    for af, _st, _pr, _cn, sa in res[:8]:
        if af == _pysock.AF_INET:
            sa_raw = struct.pack("<HH", AF_INET, _pysock.htons(sa[1])) \
                + _pysock.inet_aton(sa[0]) + b"\0" * 8
        else:
            continue  # keep v6 out for now
        sa_ptr = core.alloc(len(sa_raw), sa_raw, name="ai_addr")
        canon = core.alloc(len(node) + 1, node.encode() + b"\0",
                           name="ai_canon")
        entry = struct.pack(
            "<iiiiQQQQ",
            0, AF_INET, SOCK_STREAM, 6,     # flags, family, socktype, proto
            len(sa_raw), canon, sa_ptr, 0)  # addrlen, canonname, addr, next
        e_ptr = core.alloc(48, entry, name="addrinfo")
        if prev:
            core.write_u64(prev + 40, e_ptr)   # ai_next
        else:
            head = e_ptr
        prev = e_ptr
    core.write_u64(resp, head)
    _ret(uc, 0)


def _h_freeaddrinfo(core, uc):
    _ret(uc, 0)          # arena is leak-by-design


def _h_gethostbyname(core, uc):
    name = core._cstr(_rd(uc, UC_ARM64_REG_X0), 256).decode()
    try:
        ip = _pysock.gethostbyname(name)
    except OSError:
        _ret(uc, 0)
        return
    name_ptr = core.alloc(len(name) + 1, name.encode() + b"\0", name="he_name")
    aliases = core.alloc(8, b"\0" * 8, name="he_aliases")
    ip_cell = core.alloc(8, _pysock.inet_aton(ip) + b"\0" * 4, name="he_ip")
    addrs = core.alloc(16, struct.pack("<QQ", ip_cell, 0), name="he_list")
    he = core.alloc(32, struct.pack(
        "<QQiiQ", name_ptr, aliases, AF_INET, 4, addrs), name="hostent")
    _ret(uc, he)


def _h_gethostname(core, uc):
    buf, ln = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    name = b"localhost\0"[:ln]
    core.uc.mem_write(buf, name)
    _ret(uc, 0)


def _h_open(core, uc):
    path = core._cstr(_rd(uc, UC_ARM64_REG_X0), 128)
    if path == b"/dev/urandom":
        fd = core._newfd()
        core._net_files[fd] = "urandom"
        _ret(uc, fd)
        return
    _ret(uc, -1)          # no other files in the headless world


def _h_read(core, uc):
    fd, buf, n = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                  _rd(uc, UC_ARM64_REG_X2))
    kind = core._net_files.get(fd)
    if kind == "urandom":
        data = os.urandom(min(n, 0x10000))
        core.uc.mem_write(buf, data)
        _ret(uc, len(data))
        return
    _ret(uc, -1)


def _h_write(core, uc):
    fd, buf, n = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                  _rd(uc, UC_ARM64_REG_X2))
    if fd in (1, 2):
        data = bytes(core.safe_read(buf, min(n, 4000)))
        tag = "[game-stdout]" if fd == 1 else "[game-stderr]"
        print(f"{tag} {data.decode('utf-8', 'replace').rstrip()}", flush=True)
    _ret(uc, n)


def _h_fstat(core, uc):
    fd, st = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    core.uc.mem_write(st, b"\0" * 128)
    struct.pack_into("<Q", core.uc.mem_read(st, 8), 0, 0)
    # st_mode = S_IFCHR at offset 24 (stat arm64: dev,ino,nlinks? keep simple)
    core.write_u32(st + 24, 0x2000)     # S_IFCHR
    _ret(uc, 0)


def _epoll_new(core, uc):
    fd = core._newfd()
    core._net_epolls[fd] = {}
    _ret(uc, fd)


def _h_epoll_create(core, uc):
    _epoll_new(core, uc)


def _h_epoll_create1(core, uc):
    _epoll_new(core, uc)


def _h_epoll_ctl(core, uc):
    epfd, op, fd, evp = (_rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1),
                         _rd(uc, UC_ARM64_REG_X2), _rd(uc, UC_ARM64_REG_X3))
    regs = core._net_epolls.get(epfd)
    if regs is None:
        _ret(uc, -1)
        return
    if op == EPOLL_CTL_DEL:
        regs.pop(fd, None)
    else:
        ev = 0
        data = 0
        if evp:
            raw = core.safe_read(evp, 12)
            ev, data = struct.unpack("<IQ", raw + b"\0" * 0)
        regs[fd] = (ev, data)
    _ret(uc, 0)


def _h_epoll_wait(core, uc):
    epfd, events, maxev, to_ms = (_rd(uc, UC_ARM64_REG_X0),
                                  _rd(uc, UC_ARM64_REG_X1),
                                  _rd(uc, UC_ARM64_REG_X2),
                                  _rd(uc, UC_ARM64_REG_X3))
    regs = core._net_epolls.get(epfd)
    if regs is None:
        _ret(uc, -1)
        return
    socks = [core._net_socks[fd] for fd in regs
             if fd in core._net_socks]
    timeout = min(to_ms / 1000.0, 30.0) if to_ms >= 0 else 30.0
    try:
        rr, _rw, _rx = _pyselect.select(socks, [], [], timeout)
    except (OSError, ValueError):
        rr = []
    n = 0
    fileno_to_fd = {s.fileno(): fd for fd, s in core._net_socks.items()}
    for s in rr:
        fd = fileno_to_fd.get(s.fileno())
        if fd is None or fd not in regs or n >= maxev:
            continue
        ev, data = regs[fd]
        core.uc.mem_write(events + n * 12,
                          struct.pack("<IQ", ev | 0x1, data))
        n += 1
    _ret(uc, n)


def _h_clock_gettime(core, uc):
    clk, tsp = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    if clk == CLOCK_MONOTONIC:
        t = time.monotonic()
    else:
        t = time.time()
    sec = int(t)
    nsec = int((t - sec) * 1e9)
    if tsp:
        core.uc.mem_write(tsp, struct.pack("<qq", sec, nsec))
    _ret(uc, 0)


def _h_gettimeofday(core, uc):
    tv, tz = _rd(uc, UC_ARM64_REG_X0), _rd(uc, UC_ARM64_REG_X1)
    t = time.time()
    if tv:
        core.uc.mem_write(tv, struct.pack("<qq", int(t), int((t % 1) * 1e6)))
    _ret(uc, 0)


_HANDLERS = {
    "socket": _h_socket,
    "connect": _h_connect,
    "sendto": _h_sendto,
    "sendmsg": _h_sendmsg,
    "recvfrom": _h_recvfrom,
    "recvmsg": _h_recvmsg,
    "select": _h_select,
    "setsockopt": _h_setsockopt,
    "shutdown": _h_shutdown,
    "close": _h_close,
    "fcntl": _h_fcntl,
    "ioctl": _h_ioctl,
    "getaddrinfo": _h_getaddrinfo,
    "freeaddrinfo": _h_freeaddrinfo,
    "gethostbyname": _h_gethostbyname,
    "gethostname": _h_gethostname,
    "open": _h_open,
    "read": _h_read,
    "write": _h_write,
    "fstat": _h_fstat,
    "epoll_create": _h_epoll_create,
    "epoll_create1": _h_epoll_create1,
    "epoll_ctl": _h_epoll_ctl,
    "epoll_wait": _h_epoll_wait,
    "clock_gettime": _h_clock_gettime,
    "gettimeofday": _h_gettimeofday,
}
