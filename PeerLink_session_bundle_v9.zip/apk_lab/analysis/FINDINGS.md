# PeerLink — eFootball Native Match Engine: Session Findings (v5)

Mission: execute the original Konami gameplay code from eFootball's
`libUE4.so` (Android, v11.0.1, versionCode 311000101) headlessly under
Unicorn Engine, verified against the game's own tutorial replay oracles,
bit-exact. All addresses below are virtual addresses of the
SHA-256-pinned build `2ac4ff17ac8ad713d9531c2601e38a3c8335e02ea882ba2dc4445c191c1298cd`
(160,822,968 bytes). NOTE (v5): file-offset == vaddr only in .rodata;
see §11 for the correct vaddr->offset mapping used by all scanners.

## Milestone status

| Milestone | State | Evidence |
|---|---|---|
| M1 kernel PoC | PASS | gravity −9.80665 exact; reference y=2.9865/vy=−0.3632 reproduced |
| M2 real ball module, bit-exact | PASS | F0/F1/FC/F2(30/30 ticks, 0/296 byte diffs)/F3/FB all green (`scripts/ball_object_run.py`) |
| M3 replay-oracle fit | CLOSED (flight) | 2.4 cm RMS / 7.7 cm out-of-sample on shooting_02 frames 49..66 (`scripts/rep_flight_fit.py`) |
| M3+ driven-mode / paramsB | LOCALIZED | kick velocity/spin/ladder = the action processor (see §12) |
| M4 match-core climb | **SPINE FOUND + MODULE LAYER RUNS** | real path 0x6a059b0→driver_C→kernel executes headlessly (see §8) |
| M5 lockstep bridge | **REAL TICK + RECORD STREAM DECODED** | 0x6e92ce8 = the per-frame tick; params-offset anomaly solved; real-path flight at cm-level (see §10) |
| M6 MatchMain state machine | **PASS — FULL PLAYING FRAME RUNS HEADLESSLY** | 0x69917d8 state 1 → 0x69919e0 → input/ball(6 kernel calls)/dt=1/27/team orchestrator, ZERO faults, 495 functions (see §13) |
| M7 input bank + .trep | **BANK CONSTRUCTS HEADLESSLY + .TREP DECODED** | 0x6a06b60 runs clean (21k blocks); .trep = 24×0x3A input records + analog + camera + replay trajectory (see §14) |
| M8 real kick installer | **DEMONSTRATED** | 0x6e93aec installs KICKED substate 7; velocity zeroed BY DESIGN → the action processor is the exact next climb (see §12) |

## 1. Binary and data recovery (this container)

- Binary re-fetched from APKCombo (eFootball 11.0.1, versionCode 311000101,
  `.apks` split archive), SHA-256 verified against the pinned build.
  Surgical ranged downloader: `scripts/apks_surgical_download.py` +
  `scripts/inner_apk_remote.py` (stream-extracts only needed splits from the
  823 MB STORE-method zip).
- `dt270_mobile_all.cpk` pulled from `pad_it_0.apk` asset pack; extracted
  with `scripts/cpk_extract.py` → 81 files: 21 tutorial replay pairs
  (`.rep` = per-substep ball records, `.trep` = per-frame input stream),
  constants, gimmick + path-to-glory replays.
- `constant_match.bin` decoded via the QWESYS decoder (`peerlink1/qwesys.py`)
  → `ball.o` (1040 bytes; `[0x30]=0x00`; drag 7.5 at 0x2c and 0x140;
  restitution 0.8 at 0x3f0; speed gates 10.0 at 0x23c row).

## 2. Construction of the real ball module (M2)

Object: 0x14B8 bytes. Construction through the game's own chain
(`6a35434` semantics):

1. `operator new(0x14B8)` — via GOT/PLT hijack of `_Znwm` (UE FMemory
   override at 0x3ba1d8c needs full engine boot, so the import is
   redirected to a controllable stub).
2. base ctor `6e92768` — installs vtables incl. `+0x498`, inits both 296-byte
   state buffers at `+0x30` (input) and `+0x158` (output mirror).
3. holder wiring BEFORE module ctor: `[ball+0x3A0] = holder` (0x8000 zero
   buffer), validity byte `[ball+0x360] = 1`.
4. module ctor `6e91da8` → `6e91de4` (ball ctor) + registry + `6e920a0`
   (retrieves holder via `6a3562c`) + `6e920e0` (match-setup reader).

Neutralized engine plumbing (DROP-class, empirically derived):
`6e921a0` (ICU factory +0x498), `6e92228` (ICU factory +0x358/+0x3a8),
`68b24c4` (registration ctor +0x3f8), `6e920e0` (match-setup reader — abort
path via 68c8c14→68ce104→ICU), `68d3054` (camera sub-object
pthread_cond_wait spin on the render thread — presentation sync; was 30 s
per tick, now 0).

Params: component manager singleton at `*(0xa40f950)`;
`68d3cc0(68d34a4(), 0x4D)` → component; **`68d3cb8` does `ldr x0,[x0,#8]`**
— the component HOLDS A POINTER to the params object: `*(C+8) = P`,
ball.o bytes installed at P. (Installing ball.o inline at C+8 makes the
kernel read float bits as a pointer — demand-zero pages masked this as
zero-drag.)

Tick entry `ball_update_entry = 0x6e938a0`: gate/branch on `[ball+0x2D3]`
(byte) → recorder path (transform + N record writes, no kernel) or physics
path (`6e93adc` → chain_top). The word gate `[ball+0x2D4]` bit0 is the
"process this tick" one-shot (cleared during the tick; without it the ball
freezes).

## 3. The two-stream tick architecture (decoded this session)

`chain_top = 0x6ea1e90` builds 4 observer sub-contexts from the holder,
merges them into the working state, then calls `chain_mid = 0x6ea20fc`
TWICE:

- **Call A (0x6ea1f64): w3=1, N = *(*(0x98dddc8))** — substep 0 gets
  `w4=(idx==0)&w3 = 1` = the INIT step (`y += v·dt`, no forces), then
  N−2 physics substeps. Result feeds the PUBLISHED state stream
  (observer[0] snapshot → `+0x158`).
- **Call B (0x6ea23d4): w3=0, N=1** — ONE PURE semi-implicit substep
  (`w4=0`), result memcpy'd forward. This is the RECORDER stream.

Consequences (all measured):
- Entry tick with N=3 and feedback publishes [init+phys] per tick →
  effective gravity −19.61 (2× advance). The published stream is NOT the
  replay record stream.
- **`.rep` records = Call B semantics: 1 record = 1 committed w4=0 kernel
  substep, dt = 1/27, semi-implicit Euler.** Pure w4=0 kernel chains
  reproduce gravity at exactly −9.8067 (all 7 state rows).
- The correct simulator for replay comparison is a pure w4=0 chain from the
  segment-start state (implemented in `scripts/rep_flight_fit.py`).

Kernel `0x6ea0958` call protocol: `w0=0, w1=1, x2=state, x3=params,
s0=dt, w4=init_flag, w5`. Persistent ctx lives in the fabricated G-chain —
mirror call history or reset between comparisons. `N=1` comparisons are
degenerate; assert N≥2.

Observer layer: chain_top builds 4 observers from the holder. observer[0] =
state publisher — pre-hook snapshots the working state into `obs+0x10` on
the LAST substep (gate `[0x9959f98]−1 == idx`; set BOTH substep globals:
`*(*(0x98dddc8))` and `[0x9959f98]`), finish publishes via
`memcpy(state, obs+0x10, 0x128)`. The N−1 commit rule follows from this
snapshot-before-last-call timing.

## 4. Kernel physics (decoded)

- Gravity: hardcoded −9.80665 (m/s², Y up).
- Quadratic drag with speed gates: ball.o 10.0 (km/h, at 0x23c row) and a
  hardcoded 85.0 (0x42aa0000) in the post-kernel drag function.
- Bounce: at `y ≤ radius` with `[state+0x90] != 0` (phys) and
  `[state+0x91] == 6` (substate) → `vy *= −0.8`, `y = radius`
  (kernel block at 0x6ea0bd8). Native drop-bounce through the object path:
  peaks 2.0458/1.4216/0.9589/0.6415, restitution 0.6949.
- Params row path: `params + 0x50 + idx*4` (state idx 0..6) — no effect on
  the shooting_02 flight (row sweep is flat).

## 5. The air-curve ladder (the localized remaining gap)

The kernel calls the air-curve/drag fn `0x6ea1938` (call site 0x6ea0a44)
every substep; guards: transformed-velocity scalar > 0 OR `pos.y > 0.1187`
(airborne, `[x20−8]` where x20 = state+0xc) OR velocity norm > 0. Inside,
when L1 speed `|vx|+|vy| > 7.716` (= conv(10 km/h)² — the game compares an
unsquared L1 norm against a squared threshold), it invokes the speed-class
ladder `0x6ea555c`:

- `w8 = [state+0x8c]` (mode): 0 = threshold ladder, 1 = FText label branch,
  ≥2 = `68352cc` zero-return (disabled).
- Mode 0 ladder: 6 thresholds at `state+0x74..0x88` (class = first
  threshold > speed; if speed ≥ all: `speed −= [state+0x88]`, RECURSE).
  Class table entries: 12 bytes each at `state+0x2c + class*0xc`.
- **Zeroed thresholds + any speed > 0 → infinite recursion → stack
  exhaustion.** This is the crash that blocked the direct-kernel fit at
  25.4 m/s. (The M2 suite never crashed only because its trajectories
  stayed below 7.716 m/s L1 — the drop from 3 m peaks at 7.53.)
- The real thresholds/class-table are installed at kick time by paramsB
  machinery (chain_mid observer family) — NOT reconstructed yet.
  Workaround for measurement: state+0x8c = 8 (disabled) → ladder skipped,
  kernel's own quadratic drag still active.

## 6. M3 flight fit result (record-stream semantics, mode 8)

Oracle: `tutorial_replay_shooting_02.rep`, clean flight frames 49..66
(18 points, ~0.67 s), goal impact 67–68.

- Kernel-only prediction (airRegist=1, no spin): 1.27 m max error at
  frame 66; kernel g_eff −10.19 vs replay −8.543; kernel drag_x −8.88 vs
  replay −4.63.
- Least-squares fit of v0(3) + spin rot(3) + airRegist(1):
  **v0 = [24.76, 5.20, −4.70] m/s, rot = 0, airRegist = 0.399**
  → **residual RMS 0.0241 m, out-of-sample (last 6 flight frames) max
  error 0.0774 m.** The replay's 16-bit position quantization is ~1.6 cm,
  so this is at noise level.
- Interpretation: the "missing forces" anomaly of the prior session
  resolves to an effective airRegist ≈ 0.4 (vs ball.o raw 1.0 at
  params[0]) — either the real match params object carries 0.4 there, or
  the disabled air-curve ladder (paramsB) supplies the difference. Both
  hypotheses are precisely testable once the state installer is
  reconstructed.

## 7. Loader techniques (uc_loader2.py)

- Full ELF load with RELATIVE (1.29 M relocs), symbol + JUMP_SLOT
  relocation passes; 38 stubbed imports.
- `UC_HOOK_MEM_FETCH_PROT` coverage (required — pc=0 crashes otherwise).
- GOT/PLT hijack map from `apk_lab/analysis/plt_map.json`: C++ allocation
  operators redirected to controllable stubs.
- Zeroing malloc (UE zeroes payloads); `posix_memalign` must WRITE the
  pointer; pthread TLS keys; real `vsnprintf` (a stub returning 0 corrupts
  UE object names); fault-tolerant stub reads.
- Fabricated singletons: G at `*(0xa465d88)` (0x40000 zeros), component
  manager, module registry, substep globals.
- Per-address watchers with removal (no accumulation — hooks must not
  cross-fire).
- `core.call()` must initialize FP (x29) — some callees use the caller's
  frame pointer (`stur x8, [x29, #−0x10]`).

## 8. M4 — the match-core climb (photocopy strategy, this session)

Strategy pivot per user directive: **stop descending into equations; copy
Konami's machine code and only keep the plugs connected.** The ball core
(118 functions, 12.7 KB) already proved the method; M4 climbs to the match.

### 8.1 Call-graph wall broken (BL + B tail-calls)

The BL-only function graph stopped at 23 ancestors of the ball update —
the virtual/tail-call wall. Adding unconditional `B` inter-function edges
(2.04M edges; `scripts/bscan.py` → `fgraph2.npz`) broke through.

### 8.2 The spine (exact call chain, game's own code)

```
0x69c3e98  GameModeMatchListenerRecvMessage.cpp  (top; virtual entry)
  -> 0x69c6c58 -> 0x698ada0
  -> 0x69917d8  MATCHMAIN STATE MACHINE (state byte [obj+0x139], 11 states,
                jump table; called by 4 listeners — the update hub)
  -> 0x69919e0  'playing' state handler (match+0x26000 region; player fns)
  -> 0x6a059b0  UPDATE BALL MODULE (ldr x0,[match+0x3C98])
  -> 0x6a36a64  driver_C (manager)
  -> 0x6a35688  driven driver -> 0x6e938a0 ball_update_entry
```

`0x6a00e50` = the 110-command dispatcher ([cmd+8] = id 0..0x6c, jump
table, fans to 0x6a027f8 with command classes) — the single common
ancestor of the ball AND player update paths (the command core).

### 8.3 Module architecture (decoded + runs headlessly)

```
match object (giant, 0x26000+ embedded region)
  +0x3C98 -> BALL MODULE MANAGER
              ctor 0x6a352c4 (vtable 0x978d388 @ +0, 0x978d440 @ +0x18;
              registers global 0xa469908)
              3 module lanes:  +0x38 (idx 0, ctor w1=0)
                               +0x40 (idx 1, ctor w1=1)
                               +0x48 (idx 2, ctor w1=2)
              current lane idx [mgr+0xC]; current module [mgr+0x30]
              [module+2] = is-current gate (6a35970: strb w1,[x0,#2])
```

- Full construction driver `0x6a35434`: gate 0x71faa50(mgr+0x58); deletes
  and rebuilds lanes 0/1 (operator new 0x14B8 → 6e92768(w1) → 6e91da8(w1));
  first driven tick 6a35688(mgr, 0, 0,0,0).
- Driven driver `0x6a35688(mgr, lane, x, y, z)` = **install position into
  that lane's module state + tick** (verified: (7.5, 1.25, −3.5) installed
  exactly; physics advances).
- driver_C ticks all lanes with per-lane installs: lane0 (0,0,0) [y=0
  clamps to ground radius → reset-to-center], lane1 (1,0,100), lane2
  (2,0,100). driver_B 0x6a359f4 installs from an ENTITY array
  ([entity+0x218] xyz) with y = 1.7 (chest) / 0.01 (ground) — restart
  placements. The per-frame continuous tick is one of the remaining
  manager methods (6a362d0 / 0x6a37068 / 0x6e92ce8) — next session.
- `scripts/match_core_run.py` results (all headless, zero faults):
  - M0 manager ctor PASS (vtable 0x978d388 exact)
  - M1 **the real game path runs**: 0x6a059b0(match stub) → driver_C →
    6 kernel calls (N=3 × lanes A+B)
  - M4 decode: driven-driver install+tick semantics
  - M3 13-byte diffs vs direct tick = the decoded (0,0,0) reset install
- Module manifest candidate: function-pointer table at 0x98d0500 region
  (40+ entries 0x6a33ba8…0x6a9c430) — full module list for the closure.

### 8.4 Closure funnel (the photocopy set estimate)

Downward static closure (BL+B, virtual dispatch excluded):
- from MatchMain SM 0x69917d8: **22,337 functions / 8.4 MB code**
- from playing state 0x69919e0: **20,334 functions / 8.2 MB**
- 356 PLT imports (FreeType, AInputQueue, ANativeWindow = presentation
  to strip; the deterministic core is a subset — dynamic run will prune).

### 8.5 .trep (per-frame input stream) first decode

12-byte header + 1,200 × 844-byte samples (16B sample header + 828
payload). 375/422 u16 lanes constant; toggles at bytes 24/216 (mode
switch 749/451 frames), phase counter byte 148 (0/24). Controller-state
snapshot stream — the command-feed decode is M5 work.

### 8.6 Regression

M2 suite re-run at session start: **ALL PASS** (F0/F1/FC/F2 30/30
0-diffs, F3 0, FB peaks 2.0458/1.4216/0.9589/0.6415, restitution
0.6949). Bit-exactness unchanged by all M4 additions.

## 9. Next steps (pre-M5, kept for history)

1. Per-frame continuous tick: decode 0x6a362d0 / 0x6a37068 / 0x6e92ce8
   (manager methods calling ball_update_entry with feedback semantics).
2. MatchMain SM harness: construct the match object (0x69917d8 needs its
   singletons 0x813fe80/0x81604f4 + [obj+0x139] state byte) — the next
   stub-on-crash climb (match stub → SM → playing state → all modules).
3. .trep command feed → 0x6a00e50 dispatcher → driven-mode validation of
   a full tutorial replay (the photocopy proof at match scale).
4. paramsB state installer (unchanged: ladder thresholds +0x74..0x88).

## 10. M5 — the lockstep bridge (this session)

Mission frame: Peerlink netplay = deterministic lockstep (GGPO model).
Peers exchange controller inputs (.trep-format samples) over UDP; both run
the same photocopy; identical state by construction. The correctness proof
= feed a recorded input stream, tick, compare state vs the recorded output
(.rep) — a replay IS lockstep with one side recorded.

### 10.1 The .rep oracle (full match state, format pinned)

`44,400B header + 1,200 × 10,976B records; record = 808B global +
31 × 328B entities (22 players, pos at block+0xB6 i16/256) + ball slots`.
**Ball = THREE 28B slots at global+0x2D4/+0x2F0/+0x30C — the 3-lane module
manager architecture confirmed in data**: during the shooting_02 flight
slot 0 carries the real ball, slots 1/2 sit PARKED at (1,0,100)/(2,0,100)
— exactly driver_C's reset installs (M4 decode validated by the oracle).
Slot layout: +0x00 quat f32×4, +0x10 pos i16×3 (/256), +0x16 slot,
+0x17 player-ref, +0x18 flags. Ball record writer = **0x6a6b604** (28B
stride 0x28, gate [0x9959f98] <= idx, copies a {pos f32×3, quat f32×4}
source; called with the per-frame record target).

### 10.2 The .trep input stream (event/controller feed)

12B header {id, 12, 828} + 1,200 × 844B (16B sample hdr + 828 payload).
It is NOT an entity-position feed: discrete lanes carry formation-script
positions during idle; the shot charge = bits at bytes 196/216 with event
bursts in u32 lanes 110–159 during frames 42–49 (shooting_02), clearing
at frame 50; a continuously varying angle lane at byte 156 (0–358°). The
kick charges during 42–49, ball launches at .rep frame 48.

### 10.3 The two entries = the two streams (ARCHITECTURE DECODED)

```
ball_update_entry 0x6e938a0 → chain_top 0x6ea1e90 (RETURNS after Call A)
    Call A 0x6ea1f64: w3=1, N from *(0x98dddc8): init + N-2 phys substeps
    → memcpy to +0x158 — the PUBLISHED stream
0x6e92ce8(module, dt) → 0x6ea233c(state=+0x158, ctx, gate)
    ONE PURE w4=0 substep (dt = 1/27 HARDCODED via 0x6813eb8)
    + 2 recorder observers → memcpy back — the .rep RECORD stream
```
**0x6e92ce8 is the REAL per-frame continuous tick** (called by driver_B
0x6a359f4 per lane, with dt from 0x72205b4 (XOR-decoded match time-scale)
and the install gate from 0x7244990). Inside: time accumulator
[module+8] += dt; the pure substep runs when floor(time+dt) > floor(time)
— with dt = 1.0 (frame units) that is EVERY frame = 1 record/frame ✓;
physics dt stays 1/27. The state chain lives at +0x158 and SELF-ADVANCES.
0x6e93adc → [module+0x2F8] = install-source object (NULL = no install);
0x6e93aec(module, src, quat) = the KICK installer (pos from src,
substate 7 = kicked, flags 0x700 at +0x90, quat, ground clamp 0.1084,
[module+0x2D8]=3, notify).

### 10.4 The params offset — M3 anomaly SOLVED

The game's own chain passes kernel x3 = **0x6ea0874()+8 = P+8**
(component's params object + 8). The kernel reads its drag coefficient at
x3+0 — so the REAL path's drag = f32 at P+8, NOT at P+0 where M2/M3
installed ball.o. With ball.o at P+0 the game path read ball.o[+8] = 7.0
(17× the needed 0.399 → the 20× damping anomaly). Writing the calibrated
airRegist at P+8 → the real-path flight matches the oracle at the same
cm-level as the M3 kernel control (frames 49–~60, errors 2–10 cm). The
"effective airRegist 0.4 vs raw 1.0" M3 anomaly = the params layout
offset + the runtime paramsB modification, both now structurally located.

### 10.5 The message/command bus (the netplay fabric)

**Input bank singleton `*(0xa417188)`** (0x1C070 bytes, ctor 0x6a06b60,
factory 0x6a07120): a 1200-frame history ring (nodes {obj, buf, prev,
next} at +0x110F90, 32B each; list head +0x1BFC8, count +0x1BFD8),
command-header pool (800 × 0x18 at +0xD488), per-entity command states
(≤31 × 0x20 at +0x1B590), module list at +0x1BF88, message queue at
+0x1BFE0. Pump = **0x6a075b8** (pop queue → wrap in nodes → register
per-entity via 0x6a07d68). Message object: header at +0x68 (id u32,
class byte +4, kind byte +7), sub-objects +0x34/+0x58, flags +0x2D..0x33.
0x6a067c4 = header pool allocator (counter at +0x110F88). 1200 = the
frame-history capacity (≈44 s at 27 fps) — the game's own rollback/
resync substrate. Per-module state serialize/deserialize:
**0x6774ce4 / 0x67750ec** (the save/restore pair the replay system uses).

### 10.6 The playing-state tick map (per frame)

```
0x69919e0(match): clear scratch (0x142/0x144/0x27C)
  input collect: 0x68b0408(match+0x265B0) → virtual controller
    (lazy-created 0x68b1e90/0x68c79e8, source factory 0x7256700)
    → attach to slot manager 0x720edb0 (3×0x50 controller slots at
    match+0x26830+0x10, per-slot release 0x68b9464)
  ball: if [match+0x2DB]: 0x6a059b0([match+0x2F8]) — the inner
    "match core" object (module managers at its +0x3C98)
  dt install: 0x66f1770(0x66f0238(), 1/0x6813eb8()) = 1/27
  team orchestrator: 0x6992220 (2 sides, 0x2B8 stride at match+0x227D0)
```

### 10.7 Real-path flight validation status (shooting_02)

- Kernel-only control (M3 semantics, x3=P, air@+0=0.399): frames 49–56
  errors 0.7–9.7 cm — reproduces M3.
- Real path (0x6e92ce8, state@+0x158, air@P+8=0.399, v0 from records,
  rot=0): same cm-level on early frames (f50–54: 2.4–10 cm). Recorder
  idx2 record per tick = the current .rep record ✓.
- With spin installed (rot from .rep quat derivative, |ω|≈6.9 rad/s):
  the Magnus curve activates (z-error −0.72 at f69); late frames still
  diverge — the exact spin-drag/ladder constants = the paramsB gap.
- REMAINING for bit-exact flight: the paramsB values (ladder thresholds
  state+0x74..0x88, real airRegist/spin-drag constants) — installed at
  kick time by the real installer; the .trep kick event (frames 42–50)
  is the source. Then the full 75-frame window incl. bounce/roll.

### 10.8 Harness notes

- core.call(fn, w0, w1, x2, x3, s0, w4, w5, x0=, x1=) — no w2 kwarg.
- Reset world.reset_kernel_ctx() between parameter variants (the G-chain
  kernel ctx carries state across calls — stale-ctx artifacts otherwise).
- The recorder target is consumed after first use (re-bound per frame in
  the real game); null-target writes still capture the payload bytes.

## 11. vaddr→offset mapping (v5 fix — affects all raw file scans)

The LOAD segments are NOT identity-mapped:

```text
seg1 .rodata          vaddr 0x0        off 0x0        (identity)
seg2 .text            vaddr 0x28293c0  off 0x28253c0  (delta −0x4000)
seg3 .data.rel.ro     vaddr 0x8b75140  off 0x8b6d140  (delta −0x8000)
seg4 .data/.bss       vaddr 0x9906cc0  off 0x98facc0  (delta −0xC000)
```

Consequences:
- All .rodata reads (jump tables, constants) were already correct.
- Raw text scans (find_bl / adrp) done before v5 with `data[vaddr:]` were
  misaligned by +0x4000 and partially wrong; `scripts/scan.py` (v2o()) is
  the corrected vectorized scanner. Function-graph results (fgraph2.npz,
  built by bscan.py with correct mapping) were always correct and were
  re-validated by disasm.
- `scripts/disasm.py` (capstone) was always correct.

## 12. M8 — the real kick installer 0x6e93aec (decoded + demonstrated)

```text
0x6e93aec(module, src, quat):
  0x68bf588(module+0x3C)   ; RESETS state+0x0C = VELOCITY (zeros)
  0x68bf588(module+0x48)   ; RESETS state+0x18 = ROT/spin  (zeros)
  [module+0x30 ..+0x0C)  = src[0..12)        ; position (3×f32)
  strh 0x700, state+0x90                      ; +0x91 = 7 = KICKED substate
  0x729bae0(state+0x98) / 0x729ba50(quat, state+0x98)  ; quaternion install
  if pos.y < 0x3DDE96BB (=0.1084): pos.y = 0.1084      ; ground clamp
  [module+0x300] notify: 0x6ab1150(mod+0x300, state) / 0x6ab1104(...,0)
  [module+0x2D8] = 3
  0x6e93870(module+0x2C8, 0) ; tail 0x6e93898(module)
```

Measured (`scripts/m8_kick_installer.py`, shooting_02 f48): 28 input-state
bytes changed, substate 7, [module+0x2D8]=3, y clamped to 0.1087, velocity
ZEROED BY DESIGN. **The kick velocity is installed AFTER the installer by
the player-action processor** (the paramsB climb): the .trep analog cluster
(charge 0.644, angle 358.067°, burst frames 37–49) is its input; the
resulting velocity + spin + ladder thresholds (+0x74..0x88) are its output.
After the installer + v0-at-+0x30 + entry tick 0x6e938a0 (gate
[module+0x2D4] bit0), the continuous tick 0x6e92ce8 flies the ball through
the real path (frame alignment = the known two-stream offset, §3).

## 13. M6 — the MatchMain state machine runs headlessly (the playing frame)

### 13.1 The state machine 0x69917d8 (fully decoded)

```text
x20 = *(0xa4cff08)   [singleton A, 0x813fe80]   must be non-NULL
x22 = *(0xa4d0228)   [singleton B, 0x81604f4]   must be non-NULL
vtobj = *(0x9959fa0) [0x6836474]; w21 = vtobj->vt[0x10](vtobj)
state = match[0x139]  (0..10; jump table 0xc69522, byte offsets ×4 from 0x6991848)
  0 (0x6991848): gates → state 1                    [PRE-MATCH]
  1 (0x699187c): guards → 0x69919e0(match) = PLAYING UPDATE
      guard A: *(0xa40ff48) (0x6988524) — if non-NULL: bit 8 of [+0x270] set
      guard B: *(0xa409788)[9] — vtable+0x48 must return true
      after: w21? → state 2 → vt[0x288](vtobj, match+0x308) → state 3
             else → state 4
  2/3: vt[0x288]/vt[0x2a0] phases (2↔3 cycle)
  4..10: presentation/finish states (0x6991af8, 0x6991cb0, 0x8160680(x22)…)
```

### 13.2 The playing-state update 0x69919e0 (per frame)

```text
0x6836474() → x20 (vtobj)
clear scratch: match+0x142(h16), +0x144(b8), +0x27c(w32)
input: ctrl = 0x68b0408(match+0x265B0)
  if ctrl: 0x720edb0(match+0x26840, ctrl) attach → 0x720e3ac → 0x720ee5c(match+0x26840)
0x68b047c(match+0x265B0)                 ; release previous
ball: if match[0x2DB]: 0x6a059b0([match+0x2F8])    ; module manager tick
      else: 0x69920f0(match); if !match[0x14c]: 0x6992174()
dt: 0x66f1770(*(0xa409b10), 1/0x6813eb8())         ; dt=1/27 EXACT
0x68034d0(match[0x14c])
if match[0x146]: vtobj->vt[0x10] ... else 0x6992218() (RET) ...
→ TAIL CALL 0x6992220(match) = TEAM ORCHESTRATOR (never returns here)
```

### 13.3 Data-only plugs (the M6 "no code patching" discovery)

The lazy-getter family on embedded match regions:

```text
0x68b0408(match+0x265B0) → [hub+0x40]   (virtual controller)
0x68b2a3c(match+0x265B0) → [hub+0x48]   (command source, team orchestrator)
0x68b335c(match+0x26B60) → [reg+0x48]   (team-side object)
family shape: valid byte [X+8] → cached [X+0x40/0x48] → create via
[X+0x30] SOURCE pointer → if source NULL, the game stores NULL and
returns NULL CLEANLY.
```

Plug = `{[X+8]=1, [X+0x30]=NULL}` — "no source configured", zero patches.
M7 will replace the NULL sources with the real input bank.

### 13.4 Results (`scripts/matchmain_run.py`)

- SM call with state 1: **error=None, ZERO faults**
- Event chain: `sm → playing → input_collect → ball_update (6 kernel calls
  through the real module manager) → team_orch`
- dt = 0.03703703731298447, inv = 27.0 (EXACT 1/27)
- 38,117 basic blocks / **495 distinct functions** / 107 in the
  player-machinery range (0x6f40000..0x7300000)
- Coverage saved: `analysis/mm_exec_funcs.npy`; write-map: 1,298 match-object
  bytes changed (12-byte stride pattern 0x300..0x2a00 = per-entity
  timer/stat blocks). Team sides at match+0x227D0 untouched (player objects
  not constructed — the module-manifest climb, §15).

### 13.5 Harness construction (`scripts/matchmain_run.py:MatchMainWorld`)

- match object 0x40000 zeros; inner core obj with [core+0x3C98] = ball
  module manager (M4-verified construction: 0x6a352c4 + modules A/B)
- singletons A/B fabricated ([B+0x30]=4), vtobj with RWX stub vtable
  (w21=0 → state stays controllable), guard array *(0xa409788) with
  [9]=obj whose vt[0x48] returns 1, dt manager zeroed 0x1000
- data plugs per §13.3

## 14. M7 — the input bank + the .trep input stream

### 14.1 The input bank constructs headlessly (M7a)

- ctor 0x6a06b60 on a 0x1C070 buffer: **21,068 blocks, ZERO faults**;
  the 1200-frame history ring (nodes +0x110F90, 0x18 each), command-header
  pool (800×0x18 at +0xD488), per-entity states (≤31×0x20 at +0x1B590),
  module list (+0x1BF88), message queue (+0x1BFE0) — all initialized
  (18,161 nonzero bytes; `analysis/inputbank_run.json`).
- singleton `*(0xa417188)`; getter 0x6a067b8; pool allocator 0x6a067c4
  (idx gate ≤0x31F, 0x18 stride); release-with-destroy 0x6a07190
  (refcount at +0x1BFFC).
- pump 0x6a075b8: iterates queue → 0x6a07e50 (pool alloc) → 0x6a07ec0 →
  0x6a07ea4 → wraps message → class byte [msg+4] == 5 → id [msg+0] ==
  0x17 special path → per-entity register 0x6a07d68. Called from
  0x6a0757c(bank, dt) ← 0x6a9ba94 (message listener, vtable slot
  0x978e288) with dt = 0x72205b4()/0x6813eb8() (match time-scale XOR
  chain) — i.e. the pump runs per frame in the message pipeline.

### 14.2 The .trep format (decoded to field level)

```text
12B header {id, 12, 828} + 1200 × 844B
sample = 16B hdr + 828B payload
  hdr: f32 1.0 (time scale) + 12B zeros
  payload+0x90..0x24B: 24 input records × 0x3A (58B), stride 12B inside:
     {9B const config, u16 sub-id, 5B zero, u16 counter (+7/record),
      u16 checksum-ish, u16 flags (0x18), 24B keyframe floats, 4B zero}
  payload+0x90..0xAC: analog cluster (6 floats):
     +144 charge 0..0.644, +148 angle 0..358.067, +152/+160 drifting pair,
     u16 slots at 156/158 (17260 counting down)
  payload+0xC8..0xD0: button lane — bytes 200/201 = 0/1 PRESS,
     204..207 = A3 00 18 00 command header while held
  payload+0xD0..0xF4: camera record (9 floats: pos, target, fov-ish pair)
  payload+0x152+: replay trajectory record (9 floats/frame, 12B stride):
     3 path points A/B/C + 2 curved-axis floats (frozen after the action)
```

Timing (shooting_02): analog burst 37–49, button held 42–49, ball
launches at .rep frame 48. Survey across all 21 tutorials: consistent.
**The .trep is the game's own per-frame input stream — the lockstep wire
format PeerLink needs.**

## 15. Next climbs (for 1200/1200 exactness)

1. **Player modules**: the module manifest table at 0x98d0500 (63
   function-pointer entries via RELATIVE relocs: 0x6a33ba8, 0x6a33f50,
   0x6a35248, 0x6a38b7c…0x6a9de14) = the module-manager construction set.
   Construction driver 0x6a02000 (the ancestor of the ball-module
   construction 0x6a35434) reads the match+0x3818 region; find the full
   match setup that builds ALL module managers into the inner core object
   (ball at +0x3C98), then the team orchestrator will tick 22 players.
2. **The action processor → kick velocity + spin + paramsB**: input = the
   .trep analog cluster; output = velocity at state+0x0C, spin at +0x18,
   ladder thresholds +0x74..0x88. Locate via the [module+0x300] notify
   chain (0x6ab1150/0x6ab1104) fired by the kick installer.
3. **Input-bank feed**: push .trep samples through the message queue
   (bank+0x1BFE0) → pump 0x6a075b8 → per-entity 0x6a07d68 → dispatcher
   0x6a00e50 ([cmd+8] = id 0..0x6c) → MatchMain.
4. Then: full-replay differential test (1200/1200 frames, all 31 entity
   blocks + global state, first-divergence report).

## 16. M9 — the match-setup command sequencer + the real platform layer (v6)

### 16.1 THE DISCOVERY: 0x6a00e50 is a self-driving 109-command setup protocol

The input-bank dispatcher (vtable slot +0x10 of listener vtables
0x978bf38 / 0x978cf60) is a SELF-DRIVING command sequencer that
constructs the entire match:

```text
dispatcher 0x6a00e50(match_core, msg)
  cmd id = [match_core+8]              (jump table 0xc6bdcc, 0x6d entries)
  handler executes
  handler stores NEXT cmd id at [match_core+8]   (0x6a01924: str w8, [x19,#8])
```

Decoded chain head (verified executing headlessly):

```text
cmd 0 -> 0x6a0093c  (main init: named subsystems; singleton *(0xa417108))
      -> 1
cmd 1 -> 0x6a00cd4 check -> 2
cmd 2 -> *(0xa417111) one-shot gate -> 3
cmd 3 -> (guard 0xa if gate) -> 4
cmd 4 -> 0x6a0195c(core) gate -> 0x6a02000(core) = CONSTRUCTION DRIVER
         (2 sides x 11 slots from core+0x10 = THE 22 PLAYER MODULES
          + 3 at core+0xC0 + [core+0xD8]) -> 5
cmd 5 -> guards -> 0x6a027b0 -> 6
...  cmd 0x40..0x66 -> 0x6a027f8(core, side, slot) = per-player constructions
...  109 commands total = the full match setup protocol.
```

RESULT (scripts/m9_setup_seq.py): **the sequencer runs cmd 0 -> 1 -> 2 ->
3 -> 4 headlessly with ZERO faults** through Konami's own code. cmd 4's
gate (0x6a0195c) now reaches the TEAM-DATABASE construction chain
(0x70c1c00 -> 0x70c37f0, the roster lookup) — the exact next climb.

### 16.2 Object architecture (two objects, now confirmed)

```text
OUTER match (0x69917d8 world): state +0x139, +0x2DB, +0x2F8 -> inner,
             input hub +0x265B0, team region +0x26B60
INNER core  (dispatcher world): cmd id +8, 22-player table +0x10..0xB8,
             hubs +0x3818/+0x3868 (controllers), +0x3958/+0x39F8 (per-side
             team data, 0x50 stride), +0x3B88 hub, context +0x3C40,
             mgrs +0x3C88/+0x3C98, flags +0x3CA0/+0x3CA4
```

### 16.3 THE REAL PLATFORM LAYER (uc_loader2.py upgrades, v6)

The bootstrap climb (JNI_OnLoad 0x2830374 + .init_array 0x98bd898,
11,829 entries) forced REAL implementations of platform imports that
were previously fake:

1. **pthread_once**: real semantics (run the init routine; set the
   control). The old zero-return stub made TLS init retry ~292k times.
2. **posix_memalign / pthread_* / mmap / munmap / sysconf plain-name
   dispatch**: rich-stub names carry a _h suffix but GOT-relocated calls
   arrive with PLAIN names — the dispatch now strips the suffix, so
   posix_memalign writes the out-pointer, TLS get/set work, etc.
3. **mmap/munmap**: REAL mapping in a dedicated arena 0xA90000000000
   (the game's pools mmap/munmap for growth).
4. **sysconf**: _SC_PAGESIZE(39) = 4096 (the memory pools use it as the
   per-block overhead; 0 broke the pool math).
5. **timed_mutex contention wait removal** (0x823bef4: ldrb -> movz w8,#0):
   DROP-class — headless has no other threads, so the owner/waiter flag
   can never be legitimately set.
6. **__cxa_guard single-thread semantics** (0x8207b84/0x8207cc8/0x8207d70):
   keep the in-progress marker (prevents ctor re-entry recursion) but
   drop the same-thread abort. Acquire = test done-byte; release = set
   done; abort = clear.
7. **Allocator plugin fabrication** ([0x9e7b260]): 0x421eabc (18,629 call
   sites) dispatches allocation through *(0x98d5148)->plugin->vt[0x28].
   We install a plugin whose alloc routes to the REAL malloc PLT.
8. **Guard hub** [garr+0x10] with an empty-list invariant + benign
   vtable (0x66cff24's observer walk + register-notify vt[0x70]).

BOOTSTRAP RESULTS: **JNI_OnLoad completes with ZERO faults; init_array
entries 0-14 all pass** (the "mini-bootstrap" the sequencer needs). The
full 11,829-entry run: 5,277 pass; the failures cascade from partially
built locale/static state (UTF-16 garbage pointers) — each requires the
next platform service; the minimal set (15 entries) is what the
sequencer path actually needs.

### 16.4 The M9 runtime plug set (data-only; scripts/m9_setup_seq.py)

```text
locale facet-insert store @ 0x8130a20      -> nop (locale statics partial)
one-shot gate *(0xa417111) = 1             (cmd-2 string check done)
hub plugs: inner+{0x3818,0x3868,0x3b88,0x3b90,0x3b98,0x3ba0,
             0x3958,0x39a8,0x39f8,0x3a48,0x128,0x3bd8,0x3c40,0x3c88} +8 = 1
ctrl3868 (cmd-4 gate controller): [+0x14]=1 [+0x16]=1 [+0xCA]=1
             [+0xA0]=1 [+0x98]=1000 [+0x9C]=0
ctrl3818 (construction driver controller): zeros (defaults)
registry *(0xa417250) via the game's lazy getter 0x6a09418
guard array *(0xa409788): [9] and [10] = ret1 guard objects
empty-list invariant at 0xa40ff50
```

### 16.5 Where the chain stands (next climbs, in order)

1. **cmd 4 -> 5**: the gate's team loop needs 0x70c1c00(team, iter) to
   return a roster — the TEAM DATABASE. The team data lives in the CPK
   assets (constant_team.bin, already extracted). The chain
   0x70c1c00 -> 0x70c37f0(team_container, id1, id2) -> 0x70c201c /
   0x6f44e18 / 0x6a0b2bc builds the team objects; the DB singleton must
   be fed the CPK team data (the same pattern as ball.o in M2).
2. Then cmd 5+ registers the 22 modules (0x6a02000 reads core+0x10..0xB8),
   cmd 0x40+ constructs the players (0x6a027f8).
3. The .trep feed: the input bank's message queue -> pump 0x6a075b8 ->
   the listener vtable (0x978bf38 +0x10) = the dispatcher itself — the
   command protocol and the input stream are THE SAME PIPE. Feeding the
   .trep's per-frame records through the bank's queue drives the match.
4. The action processor (kick velocity/spin/paramsB) installs during the
   player constructions (cmd 0x40+); the M8 kick-installer semantics
   (velocity zeroed at install; the action processor computes it) remain
   the pinpointed climb.

## 17. M10 (this session): the 22 players constructed; cmd 4 -> 5

### 17.1 THE BREAKTHROUGH (scripts/m9f_drive.py, m10t_drive.py)

**slots22 = 22/22 via Konami's own constructors.** The cmd-4 gate's
slot-fill loop runs the real chain:

```text
0x70c1c00(&side, &slot):
    obj = operator new(0x18bf0)              # PLT 0x8b35260
    0x70c37f0(obj, side, slot)               # the team-db ctor (46 calls)
    0x70c1c50(obj)                           # release/commit
    return obj                               # always non-NULL
0x6993afc(obj) = add x0, #8; b 0x66ec9d0     # the module construction
[core + side*0x58 + slot*8 + 0x10] = obj     # THE 22-PLAYER SLOT
```

46 db_query + 46 teamdb_ctor + 44 player_ctor events; slots22 = 22/22;
cmd 4 -> 5 advances. **Nothing fabricated**: every byte of the 22 player
module slots is installed by Konami code.

### 17.2 Root cause of the M9 stall (the "team-data gate" was a red herring)

The cmd-0 handler RELEASES [inner+0x3868+0x40] (0x68b69a8 via 0x68b69c8)
before cmd 4 runs -> the gate's lazy-get (0x68b694c) returns NULL ->
early exit at 0x6a019e0. FIX: re-plug both controller pointers before
every dispatcher call (harness-side, zero code changes).

### 17.3 The REAL inner-core constructor: 0x69ff76c

Called from the outer match ctor 0x6992ee0. Installs [core] =
0x978cf60 (the listener vtable whose vt[+0x10] IS the dispatcher
0x6a00e50), 0x71f8614(core+0x128) = the team-data base (hubs at
+0x3620+side*0x50 relative to it), all ctrl/team hubs with REAL vtables
(0x9787030/0x97871a0/0x9787258/0x9787310/0x97873c8/0x97876a8), the
22-slot table, the 0x3bd8 readiness bytes, the 0x101 ids. Running it
headlessly installs every vtable (this is what un-crashed teamdata_get).

### 17.4 The dispatcher jump table (109 commands)

u16 byte-offsets at 0xc6bdcc; target = 0x6a00ea4 + off*4. Decoded
heads: cmd0=0x6a00fec, 1=0x6a01048, 2=0x6a01058, 3=0x6a01420,
4=0x6a0108c, 5=0x6a010a8, 6=0x6a01448, 7=0x6a01468, 8=0x6a010e0,
9=0x6a010f8, 0xa=0x6a01480... **cmds 8..0x66 each call
0x6a027f8(core, side, slot) = the per-player construction ladder**
(the "real 0x6a027f8 constructor events" the user wants; reached after
cmd 5 passes).

### 17.5 constant_team.bin decoded

QWESYS container (ff 20 'QWESYS', u32 comp/raw, zlib at +0x10) ->
{ basePosition.o: 864 bytes } = the formation position table
(24 entries x 9 f32; pitch-scale coords). Decoder: scripts/qwesys.py.

### 17.6 The three missing singleton inits (each = Konami's own init fn)

| global      | getter    | init fn   | what it is                  |
|-------------|-----------|-----------|-----------------------------|
| *(0xa40c388)| 0x67f4bcc | 0x68a7a5c | message queue hub           |
| *(0xa409e10)| 0x66fb244 | 0x66fb250 | registry hub (visitor trees)|
| *(0xa409b50)| 0x66f1e7c | 0x66f3f3c | envelope/message hub        |

All three run headlessly clean (err=None). They belong to the
module-manifest registration cascade (the mega-init 0x68a6a28, which
itself needs more platform context - documented, not yet runnable).

### 17.7 The cmd-5 guard chain (0x6a027b0) blockers fixed

1. cv-wait drain spin (0x68a0f1c loop; 0x8b38350 =
   std::condition_variable::wait -> 0x8239c48 -> pthread_cond_wait):
   DROP-class nop of the cbnz @ 0x68a0f30 (single-thread semantics,
   same precedent as the v4 camera cond_wait).
2. The three singleton inits above (NULL members cascading into
   garbage-pointer reads: 0x68ccc00 "Send", 0x66fd970 tree walk,
   0x67f4934 list insert).

### 17.8 Current frontier (next session's first target)

cmd 5 runs 0x6a027b0's guard chain 200+ times per drive; the remaining
fault: `blr x8 @ 0x66f0a40` with x8 = [[x25]+0x18] = a HEAP pointer
(0x9000xxxxxxx) - x25 = the envelope from 0x66eca24(slot). The envelope
system's slot at x20 (0xa00000a6e00-ish fabricated region) yields an
envelope whose [+0] "vtable" is an object pointer. NEXT: dump the slot
address x20, find its writer (the send path 0x68a0e40-family or the
envelope ctor 0x66f2xxx-family), and fix the partially-built envelope
state (likely another missing init in the 0x66f**** family: check
*(0xa409b70) [0x66f1e50 uses 0x8b35310 = new on it], and the
0x66f3f68/0x66f373c/0x66f308c sibling init sites).

After that: cmds 6,7 -> cmds 8..0x66 (0x6a027f8 per-player) -> 0x67 done
-> then the .trep feed via the input bank + the action processor
(unchanged v6 plan).

## 18. M11 (this session): the subsystem-bootstrap era — cmd 5 -> 6

### 18.1 THE ENVELOPE SYSTEM (fully decoded)

```text
0x8b34bb0  outline-atomics CAS (casal x0,x1,[x2])
0x66eca24  atomic exchange push/pop (validated-retry): *slot <-> new, ret old
0x66ec9b4  refcount +1 wrapper (atomic fetch_add)
0x66ec9d0  refcount +1 wrapper (also used as generic counter inc)
0x66ec9ec  refcount -1 wrapper
vtable+0x18 = the envelope's virtual handler (called when count drops to <=1)
refcount lives at +8 (some families) or +0x10 (others)
0x66f566c(index) -> &slots[index] via *(*(0xa409c38)+0x18)
```

The dtmgr fault (v7's blocker): 0x66f09c0 pops envelope from
[this+0xd0]+w6*8, decs refcount, calls vt[0x18]. `this` = 0x66f0238 ->
*(0xa409b10) = the DTMGR — the M6 harness had a ZEROED FABRICATION there
([this+0xd0]=NULL -> slots read from mapped page 0 = garbage -> heap-ptr
"vtable" -> FETCH_PROT).

### 18.2 THE REAL DTMGR + THE SUBSYSTEM BOOTSTRAP

```text
0x66eec8c  dtmgr lazy ctor: if *(0xa409b10)==NULL: calloc(0x340,0x10)
           + big ctor 0x66eece0 (installs the global itself,
           vtable 0x977ae90, slot arrays +0xd0, count/cap +0xc4)
0x677dbf0  THE SUBSYSTEM BOOTSTRAP (the real game calls it 3x, e.g.
           0x69921f0 inside the MatchMain playing update, args (1,1,0,1,0)):
           0x66ee9b0() -> *(0xa409b08); 8 sibling hub inits;
           0x66eec8c(0) = the real dtmgr; [dtmgr+0x328] flags
```

FIX: NULL *(0xa409b10) before calling 0x677dbf0 — the M6 fabrication
blocked the lazy ctor. RESULT: CMD 5 -> 6 ADVANCED.

### 18.3 THE 41-INITIALIZER GAMETHREAD CASCADE

```text
0x68a83b4: straight-line bl cascade (no static callers — virtual entry):
  0x66f5568  the 10-slot envelope hub *(0xa409c38) (vtable 0x977ae70,
             ctor 0x66f4a08: slot array grown to 10 via 0x66eeab8)
  0x66f21a4, 0x66f9dfc, 0x66fa024, 0x68a847c, 0x68a85d0, 0x68a8ab0,
  0x68a92cc, 0x68a94b0, 0x6731228, 0x68a8b94, 0x68a94b4, 0x67724f8,
  0x68a9544, 0x68a9724, 0x6775f54, 0x68a9728, 0x68a99b8, 0x68a9b40,
  0x6732528, 0x68a87f0, 0x67ea90c, 0x68a9cdc, 0x68aa0e0, 0x68aa2e8,
  0x68aa524, 0x68aa81c, 0x67ee350, 0x68aab88, 0x67e9a48, 0x68aaef4,
  0x68ab344, 0x68ab4d4, 0x68ab678, 0x68ab808, 0x68ab9ac, 0x68abbb4,
  0x68abdf0, 0x68abff8, 0x67e8a2c, 0x67734a0; tail 0x68ac234
0x68a8468 = the matching SHUTDOWN (0x66f373c + 0x66f55a4)
```

Runs headlessly CLEAN (err=None). Installs the whole 0x66f/0x68a family.

### 18.4 THE NAME REGISTRY (named subsystems)

```text
0x66d930c  hub getter -> *(0xa4097f8)  (lazy, 0x20-byte)
0x66d9a88  lookup(hub, &name) -> node or NULL
0x66d9360  register(hub, &name, &path, &file)
0x66d91fc  erase; 0x66d9264 clear; register has a "body" special case
0x68f3834  enroll-by-name: lookup(name) -> 0x66dccdc(enroller, node,...)
0x66dccdc  stores [enroller+0x190]=node, parses [node+0x80] payload
0x679081c  payload walk: count@+0xc, s32 offset table@+0x20, id table
           at 0xc62838 (rodata)
```

"body" registration (the game's own): 0x6819f70 (virtual, needs the anim
manager this with [this+0x80] container): registers "body" ->
"cpk_dat/common/anime/FoxAnim/Body/", "Projekt.hkx" (Havok), then
0x68197cc looks up "fixdemo". Our harness calls 0x66d9360 directly with
the same args (libc++ strings marshaled, SSO + long form).

### 18.5 cmd-6 asset wiring (the current wall)

Per-player animation objects (factory 0x678bd6c -> ctor 0x678b8b4, vtable
0x977dc38) are created by the enroll (0x66dd15c); their [+0x80] payload
is filled by the ASYNC FILE LOADER in the real game. Headless without
assets:
- empty-payload plug at 0x66dd444 (zeroed buffer, count=0)
- asset-hash guard at 0x66ee728 (the crypto hash engine 0x66ee098; data
  via 0x66f853c/0x66f8548 = [[src]]/[[src]+8]; unmapped -> empty)
- the pooled allocator (0x2efa57c/0x2efa830, pool table 0x9a9dac0+8*i,
  lazy init guard 0x9a9da10, emutls TLS at 0x99071f8/0x99071d8):
  __emutls_get_address now REAL in uc_loader2 (per-control buffers)
- REMAINING: free(8) from 0x6783260's node-list cleanup (the animation
  node list contains 8 = another unloaded-data artifact) -> the -8 write
  at 0x2efa884. 0x6a027f8 (player_ctor2) fires (side=0,slot=0 repeated —
  each step rebuilds player 0 then faults).

### 18.6 THE DATA WALL

The cmd-6+ flow wants the real animation files. The dt270 CPK came from
pad_it_0.apk inside the 862MB .apks (APKCombo R2, surgical ranged
downloader scripts/apks_surgical_download.py). The R2 URL expired;
APKCombo is now JS-gated and apkpure CF-challenged. Options: another
mirror, or the Konami CDN manifest, or continue empty-plugs through the
animation state machine.

---

## M14 — the friend-match net layer + FULL-STACK lockstep (Task 16)

### 14.1 The net layer (peerlink/ package)
- `transport.py`: UDP direct/hole-punch/relay (RFW via the lobby), lobby
  pass-through (ptype 0xFFFE), drain-all recv (256/call), pushback queue.
- `rooms.py`: LobbyServer (PLC/PLJ/PLP/PLH + RFW relay), Crockford-style
  6-char codes, 30-bit room ids.
- `lockstep.py`: 56-i32 input packets (.trep field layout), per-tick
  acks + gap-safe retransmit, per-tick FNV-1a checksum exchange with
  deferred same-tick comparison, divergence = abort (never resync).
- `session.py`: create() -> code -> wait_for_guest()/join() -> frame().

### 14.2 Protocol determinism rules (all four were REAL bug fixes)
1. CANONICAL input order: sim always gets (host, guest) — local/remote
   order forks the two worlds (asymmetric weights prove it in demo_match).
2. Per-tick checksum comparison only (comparing a tick-T remote checksum
   against our current state false-positives when the peers sit at
   different ticks).
3. Per-tick ACK retirement only (`tick < max_acked` drops unacked inputs
   on gaps => permanent lockstep deadlock — found via wire_debug.py).
4. Pushback, never drop: frames drained while waiting for the lobby's
   PEERINFO (the guest's early inputs arrive in the same 200ms window)
   must be requeued for the LockstepPeer.

### 14.3 EngineSim (peerlink/engine_sim.py)
- Binds the Unicorn engine to the sim interface: tick(host,guest) +
  state_checksum() (FNV-1a of the 0x128 ball state).
- Rising shoot edge on ints[2] (either player) -> the game's own kick
  installer 0x6e93aec; velocity from analog deflection = the documented
  paramsB stand-in (10.3 gap).
- Per tick: reset_kernel_ctx + native 0x6e938a0 + output->input mirror
  (the F2-proven cadence). Boots in ~2.2s, ticks ~2ms.

### 14.4 RESULTS (all reproducible)
- Twin-run (two independent processes, own libUE4.so mappings):
  60/60 per-tick checksums identical (cs e72fb0160583f5d7).
- demo_match (BallSim, threads): 1200/1200, 44/44, bit-exact, 105 f/s.
- demo_process_mode (BallSim, processes): 300/300 bit-exact.
- FULL-STACK (demo_engine_net.py, real engine + real UDP + room codes +
  punch + relay, two processes):
    108/108: PASS. 1200/1200: PASS — 400 frames, 5.4s, 62 kicks via
    0x6e93aec, 44/44 checksum exchanges, final cs 33fd1587bcaf0c3b,
    ball (37.2441, 1.5068, 24.8508) bit-identical, zero divergence.
