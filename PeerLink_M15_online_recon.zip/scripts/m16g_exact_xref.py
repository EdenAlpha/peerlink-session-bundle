#!/usr/bin/env python3
"""M16g: exact-match xref scan for GateInfo.php / ntl url + dump the
GateInfo request builder (its field list = the probe body)."""
import numpy as np, struct
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO,'rb'); elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)
def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            f.seek(s['offset'] + (va - s['vaddr'])); return f.read(n)
    return b''
def cstr(va, maxlen=100):
    b = read_vaddr(va, maxlen); e = b.find(b'\0')
    return b[:e if e>=0 else maxlen].decode('utf8','replace')

data = open(SO,'rb').read()
def find_str_va(t):
    off = data.find(t)
    for s in loads:
        if s['offset'] <= off < s['offset'] + s['filesz']:
            return s['vaddr'] + (off - s['offset'])
    return None

targets = {}
for t, name in ((b'GateInfo.php', 'GateInfo'),
                (b'GateInfo', 'GateInfo_nophp'),
                (b'http://ntl.service.konami.net/ntl/api/GateInfo.php', 'ntlurl'),
                (b'ntl/api/', 'ntlapipath')):
    va = find_str_va(t)
    while va is not None and t == b'GateInfo' and va in targets:
        va = None
    if va is not None and va not in targets:
        targets[va] = name
print("targets:", {hex(k): v for k, v in targets.items()})

code = read_vaddr(text['vaddr'], text['filesz'])
n = len(code)//4
insns = np.frombuffer(code[:n*4], dtype='<u4')
adrp_idx = np.nonzero((insns >> 24) == 0b10010000)[0]
v = insns[adrp_idx].astype(np.int64)
immlo = (v >> 29) & 3; immhi = (v >> 5) & 0x7FFFF
imm = (immhi << 2) | immlo
imm = np.where(imm & (1 << 20), imm - (1 << 21), imm)
rd = v & 0x1F
pages = ((text['vaddr'] + adrp_idx.astype(np.uint64) * np.uint64(4))
         & np.uint64(0xFFFFFFFFFFFFF000))
bases = (pages.astype(np.int64) + (imm << 12)) & np.int64(0xFFFFFFFFFF)

hits = []
for tv, name in targets.items():
    mask = (bases <= tv) & (tv < bases + 0x1000)
    for k in np.nonzero(mask)[0]:
        i = int(adrp_idx[k])
        for j in range(1, 6):
            if i+j >= n: break
            v2 = int(insns[i+j])
            if (v2 >> 24) == 0b10010001 and ((v2 >> 5) & 0x1F) == int(rd[k]):
                final = int(bases[k]) + ((v2 >> 10) & 0xFFF)
                if final == tv:
                    hits.append((text['vaddr']+i*4, final, name))
                break

print(f"\nEXACT hits: {len(hits)}")
for site, final, name in hits:
    print(f"  {site:#x} -> {name}")

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
for site, final, name in hits:
    if name != 'GateInfo' and name != 'ntlurl': continue
    print(f"\n===== window at {site:#x} ({name}) =====")
    blob = read_vaddr(site-0x60, 0x300)
    last_adrp = {}
    for insn in md.disasm(blob, site-0x60):
        line = f"  {insn.address:#x}: {insn.mnemonic} {insn.op_str}"
        if insn.mnemonic == 'adrp':
            p = insn.op_str.split(', #')
            if len(p)==2:
                try: last_adrp[p[0].strip()] = int(p[1],0) & 0xFFFFFFFFFF
                except: pass
        elif insn.mnemonic == 'add' and ', #' in insn.op_str:
            parts = [p.strip() for p in insn.op_str.split(',')]
            if len(parts)==3 and parts[0] in last_adrp and parts[1] in last_adrp:
                try:
                    imm2 = int(parts[2].replace('#',''),0)
                    s = cstr(last_adrp[parts[1]]+imm2)
                    if 2 < len(s) < 90 and all(31<ord(c)<127 for c in s[:6]):
                        line += f'   ; "{s}"'
                except: pass
        print(line)
