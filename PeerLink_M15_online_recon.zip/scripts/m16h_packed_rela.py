#!/usr/bin/env python3
"""Decode Android packed relocations (DT_ANDROID_RELA) and build the full
(offset -> addend) map, then resolve who points at the GateInfo URL,
the game host, RSA key, etc."""
import struct, sys

SO = '/home/z/my-project/apk_lab/libUE4.so'
data = open(SO, 'rb').read()

START, SIZE = 0x2ed270, 0x3de65a

def sleb128(d, pos):
    result = 0; shift = 0
    while True:
        b = d[pos]; pos += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            if b & 0x40:
                result -= (1 << shift)
            return result, pos

relmap = {}   # offset -> addend (RELATIVE only)
offset = 0; addend = 0
pos = START; end = START + SIZE
nrel = 0
while pos < end:
    count, pos = sleb128(data, pos)
    if count == 0:
        break
    last = False
    if count < 0:
        count = -count
        last = True
    flags, pos = sleb128(data, pos)
    group_info = 0
    if flags & 2:  # GROUPED_BY_OFFSET
        offset, pos = sleb128(data, pos)
    if flags & 1:  # GROUPED_BY_INFO
        group_info, pos = sleb128(data, pos)
    if flags & 4:  # HAS_ADDEND
        addend, pos = sleb128(data, pos)
    for i in range(count):
        if not (flags & 2):  # offset varies per reloc
            delta, pos = sleb128(data, pos)
            offset += delta
        if (flags & 4) and (flags & 2):
            # grouped-by-offset: addend delta per reloc
            delta, pos = sleb128(data, pos)
            addend += delta
        elif (flags & 4) and not (flags & 2):
            # offset deltas also have addend deltas
            delta, pos = sleb128(data, pos)
            addend += delta
        if group_info == 0x403:  # R_AARCH64_RELATIVE
            relmap[offset] = addend
        nrel += 1
    if last:
        break

print(f"decoded {nrel} relocs, {len(relmap)} RELATIVE (offset->addend)")
print(f"pos ended at {pos:#x} vs table end {end:#x}")

# now: find addends pointing at our strings of interest
def find_str_va(t):
    off = data.find(t)
    if off < 0: return None
    # find the segment containing this file offset: we know data segs.
    # quick approach: strings are in rodata; vaddr = file offset for the
    # first PT_LOAD in this binary (offset 0 vaddr 0)? verify: 0xaab9f5 file->va?
    return off

targets = {
    find_str_va(b'http://ntl.service.konami.net/ntl/api/GateInfo.php'): 'GateInfoURL',
    find_str_va(b'pes22-game.cs.konami.net'): 'gamehost',
    find_str_va(b'-----BEGIN PUBLIC KEY-----'): 'rsa',
    find_str_va(b'CmdLogin.php'): 'CmdLogin',
    find_str_va(b'CmdGetKgsGuestLoginToken.php'): 'guestlogin',
    find_str_va(b'pesam.stun.service.konami.net'): 'stun',
    find_str_va(b'CmdCreatejoinRoom.php'): 'createroom',
}
targets = {v: k for k, v in targets.items() if k is not None}
print("\ntarget file offsets:", {k: hex(v) for k, v in targets.items()})

hits = []
for slot, add in relmap.items():
    for name, tva in targets.items():
        if tva - 16 <= add <= tva + 16:
            hits.append((slot, add, name))

print(f"\n{len(hits)} relocs pointing at targets:")
for slot, add, name in hits:
    print(f"  slot {slot:#x} -> {name} (addend {add:#x})")

# dump neighbor slots for context on the interesting ones
import collections
by_name = collections.defaultdict(list)
for slot, add, name in hits:
    by_name[name].append(slot)
for name, slots in by_name.items():
    slots.sort()
    print(f"\n--- {name}: {len(slots)} slots, first: {[hex(s) for s in slots[:8]]}")
