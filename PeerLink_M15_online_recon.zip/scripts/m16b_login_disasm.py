#!/usr/bin/env python3
"""M16b: disassemble the CmdLogin.php request builder at 0x76b13b0."""
import struct, sys
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)

def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            off = s['offset'] + (va - s['vaddr'])
            f.seek(off)
            return f.read(n)
    return b''

def cstr(va, maxlen=120):
    b = read_vaddr(va, maxlen)
    e = b.find(b'\0')
    if e < 0: e = maxlen
    try:
        return b[:e].decode('utf8')
    except Exception:
        return b[:e].decode('utf8', 'replace')

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)

# find function start: scan back for a prologue (stp x29/x30 with fp)
SITE = 0x76b13b0
back = 0x600
blob = read_vaddr(SITE - back, back + 0x900)
start = SITE - back

out = []
last_adrp = {}   # reg -> page
for insn in md.disasm(blob, start):
    line = f"{insn.address:#x}: {insn.mnemonic} {insn.op_str}"
    # resolve adrp+add string refs inline
    if insn.mnemonic == 'adrp':
        # op_str: x0, #0x9ed000
        parts = insn.op_str.split(', #')
        if len(parts) == 2:
            try:
                last_adrp[parts[0].strip()] = int(parts[1], 0) & 0xFFFFFFFFFF
            except ValueError:
                pass
    elif insn.mnemonic == 'add' and ', #' in insn.op_str:
        parts = [p.strip() for p in insn.op_str.split(',')]
        if len(parts) == 3 and parts[0] in last_adrp and parts[1] in last_adrp:
            try:
                imm = int(parts[2].replace('#', ''), 0)
                va = last_adrp[parts[1]] + imm
                s = cstr(va)
                if 3 < len(s) < 100 and all(32 <= ord(c) < 127 for c in s[:8]):
                    line += f'   ; "{s}"'
            except ValueError:
                pass
    out.append(line)

for l in out:
    print(l)
