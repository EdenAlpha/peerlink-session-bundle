#!/usr/bin/env python3
"""M16k: APS2 ANDROID_RELA decoder v2 — validated model:

  header: b'APS2' + sleb128(total_count)
  primer: (0, 1, info)   [size-0 group, skipped]
  first reloc raw: (offset, info, addend)
  then groups: (size, flags, [X], [Y], [Z], per-reloc slebs)
    bit0 (1)  GROUPED_BY_INFO   -> Y = info
    bit1 (2)  GROUPED_BY_OFFSET-> X = offset delta; relocs stride +8
    bit2 (4)  GROUPED_BY_ADDEND-> Z = absolute addend
    bit3 (8)  HAS_ADDEND       -> per-reloc addend delta slebs
    non-grouped offsets: per-reloc offset delta slebs

Validates: every slot 8-aligned inside writable PT_LOADs; total == count.
"""
import struct, json, sys
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
data = open(SO, 'rb').read()
f = open(SO, 'rb'); elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          memsz=seg['p_memsz'], offset=seg['p_offset'],
                          flags=seg['p_flags']))
writable = [s for s in loads if s['flags'] & 2]
maxva = max(s['vaddr'] + s['memsz'] for s in loads)

def slot_ok(va):
    if va % 8 or va < 0 or va > maxva: return False
    for s in writable:
        if s['vaddr'] <= va < s['vaddr'] + s['memsz']:
            return True
    return False

def sleb128(d, pos):
    result = 0; shift = 0
    while True:
        b = d[pos]; pos += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            if b & 0x40:
                result -= (1 << shift)
            return result, pos

START = 0x2ed270
count, pos = sleb128(data, START + 4)

# primer group (0, 1, info)
size, pos = sleb128(data, pos)
flags, pos = sleb128(data, pos)
assert size == 0 and flags == 1, f"unexpected primer {(size, flags)}"
info, pos = sleb128(data, pos)

# first raw reloc
offset, pos = sleb128(data, pos)
info, pos = sleb128(data, pos)
addend, pos = sleb128(data, pos)

relmap = {}
nrel = 0
def emit(off, inf, add):
    global nrel
    if inf == 0x403:
        relmap[off] = add
    nrel += 1

emit(offset, info, addend)
end = START + 0x3de65a
groups = 0
while pos < end and nrel < count:
    size, pos = sleb128(data, pos)
    if size <= 0:
        print(f"terminator/odd size {size} at group {groups}, nrel={nrel}")
        break
    flags, pos = sleb128(data, pos)
    groups += 1
    if flags & 2:
        dx, pos = sleb128(data, pos)
        offset += dx
    if flags & 1:
        info, pos = sleb128(data, pos)
    gadd = None
    if flags & 4:
        gadd, pos = sleb128(data, pos)
        addend = gadd
    for i in range(size):
        if not (flags & 2):
            dx, pos = sleb128(data, pos)
            offset += dx
        if flags & 8:
            da, pos = sleb128(data, pos)
            addend += da
        if not slot_ok(offset):
            print(f"BAD SLOT {offset:#x} group {groups} (size {size} flags {flags:#x}) reloc {i} nrel {nrel}")
            sys.exit(1)
        emit(offset, info, addend)
        offset += 8

print(f"decoded {nrel} relocs ({len(relmap)} RELATIVE) in {groups+1} groups; expected {count}")
assert nrel == count, "count mismatch!"
json.dump({str(k): v for k, v in relmap.items()},
          open('/home/z/my-project/apk_lab/analysis/android_relocs.json', 'w'))
print("saved analysis/android_relocs.json")
