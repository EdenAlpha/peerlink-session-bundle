#!/usr/bin/env python3
"""Decode APS2 ANDROID_RELA properly (skip 'APS2'+count header) and map
who points at the Konami server strings."""
import struct, collections

SO = '/home/z/my-project/apk_lab/libUE4.so'
data = open(SO, 'rb').read()

HDR = 0x2ed278          # after "APS2" + u32 count
END = 0x2ed270 + 0x3de65a

def sleb128(d, pos):
    result = 0; shift = 0
    while True:
        b = d[pos]; pos += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            if b & 0x40:
                result -= (1 << shift)
            return result, pos

BY_INFO, BY_OFFSET, HAS_ADDEND = 1, 2, 4

relmap = {}
pos = HDR
offset = 0; addend = 0
nrel = 0
while pos < END:
    count, pos = sleb128(data, pos)
    if count == 0:
        break
    last = False
    if count < 0:
        count = -count; last = True
    flags, pos = sleb128(data, pos)
    info = 0
    if flags & BY_INFO:
        info, pos = sleb128(data, pos)
    if flags & BY_OFFSET:
        offset, pos = sleb128(data, pos)
    if flags & HAS_ADDEND:
        addend, pos = sleb128(data, pos)
    for i in range(count):
        if not (flags & BY_OFFSET):
            delta, pos = sleb128(data, pos)
            offset += delta
        if flags & HAS_ADDEND and (i > 0 or not (flags & BY_OFFSET)):
            if flags & BY_OFFSET:
                delta, pos = sleb128(data, pos)
                addend += delta
            else:
                delta, pos = sleb128(data, pos)
                addend += delta
        if info == 0x403:   # R_AARCH64_RELATIVE
            relmap[offset] = addend
        nrel += 1
    if last:
        break

print(f"decoded {nrel} relocs ({len(relmap)} RELATIVE)")

# string file-offset == vaddr for this binary's rodata? verify via PT_LOAD map
from elftools.elf.elffile import ELFFile
f = open(SO, 'rb'); elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
def off2va(off):
    for s in loads:
        if s['offset'] <= off < s['offset'] + s['filesz']:
            return s['vaddr'] + (off - s['offset'])
    return None

targets = {}
for t, name in ((b'http://ntl.service.konami.net/ntl/api/GateInfo.php', 'GateInfoURL'),
                (b'pes22-game.cs.konami.net\x00', 'gamehost'),
                (b'-----BEGIN PUBLIC KEY-----', 'rsa'),
                (b'CmdLogin.php\x00', 'CmdLogin'),
                (b'CmdGetKgsGuestLoginToken.php', 'guestlogin'),
                (b'pesam.stun.service.konami.net', 'stun'),
                (b'CmdCreatejoinRoom.php', 'createroom'),
                (b'CmdGetServerEnv.php', 'serverenv'),
                (b'gate.php', 'gatephp')):
    off = data.find(t)
    va = off2va(off) if off >= 0 else None
    if va: targets[va] = name

print("target VAs:", {hex(k): v for k, v in targets.items()})

hits = []
for slot, add in relmap.items():
    for tva, name in targets.items():
        if tva - 0x20 <= add <= tva + 0x20:
            hits.append((slot, add, name))

print(f"\n{len(hits)} hits:")
for slot, add, name in hits:
    print(f"  slot {slot:#x} -> {name} (addend {add:#x})")

by_name = collections.defaultdict(list)
for slot, add, name in hits:
    by_name[name].append(slot)
for name, slots in by_name.items():
    slots.sort()
    print(f"\n{name}: slots {[hex(s) for s in slots[:12]]}")

import json
json.dump({str(k): v for k, v in relmap.items()}, open('/home/z/my-project/apk_lab/analysis/relative_relocs.json','w'))
print("\nfull relmap saved to analysis/relative_relocs.json")
