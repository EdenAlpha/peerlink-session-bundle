#!/usr/bin/env python3
"""M16c: full annotated dump of the request-builder function containing
0x76b13b0 (the CmdLogin.php site) — every string ref, every call."""
import struct, sys, json
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)

def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            off = s['offset'] + (va - s['vaddr'])
            f.seek(off)
            return f.read(n)
    return b''

def cstr(va, maxlen=120):
    b = read_vaddr(va, maxlen)
    e = b.find(b'\0')
    if e < 0: e = maxlen
    return b[:e].decode('utf8', 'replace')

# PLT symbol map (for call annotation)
import subprocess
plt_map = {}
try:
    j = json.load(open('/home/z/my-project/apk_lab/analysis/plt_map.json'))
    plt_map = {int(k): v.get('sym', '?') for k, v in j.items()}
except Exception:
    pass

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)

# function start: find stp x29, x30 prologue going back from 0x76b0e00ish
# we saw the function body spans roughly 0x76b0c00..0x76b1900
START = 0x76b0c00
SIZE = 0x76b1a00 - START
blob = read_vaddr(START, SIZE)

lines = []
last_adrp = {}
for insn in md.disasm(blob, START):
    note = ''
    if insn.mnemonic == 'adrp':
        parts = insn.op_str.split(', #')
        if len(parts) == 2:
            try: last_adrp[parts[0].strip()] = int(parts[1], 0) & 0xFFFFFFFFFF
            except ValueError: pass
    elif insn.mnemonic == 'add' and ', #' in insn.op_str:
        parts = [p.strip() for p in insn.op_str.split(',')]
        if len(parts) == 3 and parts[0] in last_adrp and parts[1] in last_adrp:
            try:
                imm = int(parts[2].replace('#', ''), 0)
                va = last_adrp[parts[1]] + imm
                s = cstr(va)
                if 2 < len(s) < 100 and all(31 < ord(c) < 127 for c in s[:6]):
                    note = f'   ; "{s}"'
            except ValueError: pass
    elif insn.mnemonic in ('bl', 'b') and insn.op_str.startswith('#'):
        try:
            tgt = int(insn.op_str[1:], 0)
            if tgt in plt_map:
                note = f'   ; PLT {plt_map[tgt]}'
        except ValueError: pass
    if insn.mnemonic == 'movk':
        note += f'   ; w9 magic check'
    lines.append(f"{insn.address:#x}: {insn.mnemonic} {insn.op_str}{note}")

# print only the interesting region 0x76b1380..0x76b1900
for l in lines:
    addr = int(l.split(':')[0], 16)
    if 0x76b1380 <= addr <= 0x76b1800:
        print(l)
