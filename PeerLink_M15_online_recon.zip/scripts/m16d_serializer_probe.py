#!/usr/bin/env python3
"""M16d: identify the serializer — disassemble the field-setter family
(0x2f92514, 0x2f913c8, 0x2f8f898) and find the wire format."""
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)

def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            off = s['offset'] + (va - s['vaddr'])
            f.seek(off)
            return f.read(n)
    return b''

def cstr(va, maxlen=120):
    b = read_vaddr(va, maxlen)
    e = b.find(b'\0')
    if e < 0: e = maxlen
    return b[:e].decode('utf8', 'replace')

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)

def dump(start, size, label):
    print(f"\n{'='*20} {label} {'='*20}")
    blob = read_vaddr(start, size)
    last_adrp = {}
    for insn in md.disasm(blob, start):
        line = f"{insn.address:#x}: {insn.mnemonic} {insn.op_str}"
        if insn.mnemonic == 'adrp':
            parts = insn.op_str.split(', #')
            if len(parts) == 2:
                try: last_adrp[parts[0].strip()] = int(parts[1], 0) & 0xFFFFFFFFFF
                except ValueError: pass
        elif insn.mnemonic == 'add' and ', #' in insn.op_str:
            parts = [p.strip() for p in insn.op_str.split(',')]
            if len(parts) == 3 and parts[0] in last_adrp and parts[1] in last_adrp:
                try:
                    imm = int(parts[2].replace('#', ''), 0)
                    s = cstr(last_adrp[parts[1]] + imm)
                    if 2 < len(s) < 100 and all(31 < ord(c) < 127 for c in s[:6]):
                        line += f'   ; "{s}"'
                except ValueError: pass
        print(line)

# the field setter
dump(0x2f92514, 0x180, "field-setter 0x2f92514 (get slot by name)")
# the value wrapper
dump(0x2f913c8, 0x100, "value-wrap 0x2f913c8")
# the assign
dump(0x2f8f898, 0x140, "assign 0x2f8f898")
