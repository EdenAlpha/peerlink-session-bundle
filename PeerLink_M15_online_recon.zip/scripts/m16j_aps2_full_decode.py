#!/usr/bin/env python3
"""M16j: FULL decoder for the APS2 packed relocations (DT_ANDROID_RELA)
of eFootball's libUE4.so, empirically validated:

  header: b'APS2' + sleb128(total_count)
  groups: (size, flags, [X], [Y], [Z], then per-reloc slebs)
    flags bit0 (1): Y = group r_info (e.g. 1027 = R_AARCH64_RELATIVE)
    flags bit1 (2): X = offset delta (first reloc of group)
    flags bit2 (4): Z = group addend (all relocs share)
    flags bit3 (8): per-reloc addend deltas
    within a group: each subsequent reloc slot += 8 (consecutive)
    per-reloc: if not bit1: read an offset delta sleb (slot += delta)

Outputs analysis/android_relocs.json: {"slot_va": addend, ...}
"""
import struct, json, sys
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
data = open(SO, 'rb').read()

f = open(SO, 'rb'); elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
writable = [s for s in loads if s['flags'] & 2]

def slot_ok(va):
    if va % 8: return False
    for s in writable:
        if s['vaddr'] <= va < s['vaddr'] + s['memsz']:
            return True
    return False

def sleb128(d, pos):
    result = 0; shift = 0
    while True:
        b = d[pos]; pos += 1
        result |= (b & 0x7F) << shift
        shift += 7
        if not (b & 0x80):
            if b & 0x40:
                result -= (1 << shift)
            return result, pos

START = 0x2ed270
assert data[START:START+4] == b'APS2', "bad magic"
count, pos = sleb128(data, START + 4)
print(f"total relocs: {count}")

offset = 0
addend = 0
info = 0
relmap = {}
nrel = 0
groups = 0
errors = 0
end = START + 0x3de65a
while pos < end and nrel < count:
    size, pos = sleb128(data, pos)
    if size < 0:
        size = -size
    flags, pos = sleb128(data, pos)
    groups += 1
    if flags & 1:
        info, pos = sleb128(data, pos)
    if flags & 2:
        dx, pos = sleb128(data, pos)
        offset += dx
    if flags & 4:
        addend, pos = sleb128(data, pos)
    for i in range(size):
        if not (flags & 2):
            dx, pos = sleb128(data, pos)
            offset += dx
        if flags & 8:
            if i == 0 and not (flags & 4):
                pass  # first delta applies below
            da, pos = sleb128(data, pos)
            addend += da
        if not slot_ok(offset):
            errors += 1
            if errors < 10:
                print(f"  BAD SLOT {offset:#x} at group {groups} reloc {i}")
                sys.exit(1)
        if info == 0x403:
            relmap[offset] = addend
        nrel += 1
        if nrel > count: break
        offset += 8          # consecutive stride

print(f"decoded {nrel} relocs in {groups} groups, {len(relmap)} RELATIVE")
print(f"errors: {errors}")

json.dump({str(k): v for k, v in relmap.items()},
          open('/home/z/my-project/apk_lab/analysis/android_relocs.json', 'w'))
print("saved analysis/android_relocs.json")

# ---- now find who points at our targets ----
def off2va(off):
    for s in loads:
        if s['offset'] <= off < s['offset'] + s['filesz']:
            return s['vaddr'] + (off - s['offset'])
    return None

targets = {}
for t, name in ((b'http://ntl.service.konami.net/ntl/api/GateInfo.php', 'GateInfoURL'),
                (b'pes22-game.cs.konami.net\x00', 'gamehost'),
                (b'-----BEGIN PUBLIC KEY-----', 'rsa'),
                (b'CmdLogin.php\x00', 'CmdLogin'),
                (b'CmdGetKgsGuestLoginToken.php', 'guestlogin'),
                (b'pesam.stun.service.konami.net', 'stun'),
                (b'CmdCreatejoinRoom.php', 'createroom'),
                (b'CmdGetServerEnv.php', 'serverenv'),
                (b'gate.php', 'gatephp')):
    off = data.find(t)
    va = off2va(off) if off >= 0 else None
    if va: targets[va] = name

print("\ntargets:", {hex(k): v for k, v in targets.items()})
hits = []
for slot, add in relmap.items():
    for tva, name in targets.items():
        if tva - 0x40 <= add <= tva + 0x40:
            hits.append((slot, add, name))

print(f"\n{len(hits)} relocs near targets:")
for slot, add, name in hits[:40]:
    print(f"  slot {slot:#x} -> {name} (addend {add:#x}, delta {add - [t for t,n in targets.items() if n==name][0]:+#x})")
