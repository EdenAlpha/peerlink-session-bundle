#!/usr/bin/env python3
"""M16a: find the code that builds Cmd*.php HTTP requests.

Strategy:
 1. Locate endpoint strings (CmdLogin.php, GateInfo.php, ...) in the .so
 2. Find ADRP/ADD materializations referencing those string addresses
 3. Disassemble the surrounding functions -> the request-builder family
 4. Dump every string the same code region references (URL parts, headers,
    format strings) -> the wire format
"""
import re
import struct
import sys
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO, 'rb')
elf = ELFFile(f)

# ---- build vaddr->file-offset map + read helper ----
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], memsz=seg['p_memsz'],
                          flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)
data_segs = [s for s in loads if not (s['flags'] & 1)]
END = max(s['vaddr'] + s['filesz'] for s in loads)

def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            off = s['offset'] + (va - s['vaddr'])
            f.seek(off)
            return f.read(n)
    return b''

def cstr(va, maxlen=200):
    b = read_vaddr(va, maxlen)
    e = b.find(b'\0')
    return b[:e if e >= 0 else maxlen]

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
md.detail = False

# ---- 1. locate the endpoint strings ----
data = open(SO, 'rb').read()
targets = [b'CmdLogin.php', b'GateInfo.php', b'CmdCreatejoinRoom.php',
           b'CmdGetKgsGuestLoginToken.php', b'CmdGetSessionId.php',
           b'CmdStartGame.php', b'CmdGetServerEnv.php', b'gate.php']
str_va = {}
for t in targets:
    # find file offset -> vaddr
    off = data.find(t)
    while off != -1:
        for s in loads:
            if s['offset'] <= off < s['offset'] + s['filesz']:
                va = s['vaddr'] + (off - s['offset'])
                str_va.setdefault(t.decode(), []).append(va)
                break
        off = data.find(t, off + 1)

print("=== endpoint string addresses ===")
for k, v in str_va.items():
    print(f"  {k}: {[hex(x) for x in v]}")

# ---- 2. scan the executable segment for ADRP+ADD referencing them ----
tset = set()
for v in str_va.values():
    tset.update(v)
tarr = np.array(sorted(tset), dtype=np.uint64)

code = read_vaddr(text['vaddr'], text['filesz'])
n = len(code) // 4
insns = np.frombuffer(code[:n * 4], dtype='<u4').reshape(n)

# adrp: [31:24]=0b10010000 immlo[30:29] immhi[23:5] Rd[4:0]
is_adrp = (insns >> 24) == 0b10010000
adrp_idx = np.nonzero(is_adrp)[0]
print(f"\nscanning {len(adrp_idx)} ADRPs for {len(tset)} target strings...")

refs = []   # (site, target, rd)
for i in adrp_idx:
    v = int(insns[i])
    immlo = (v >> 29) & 3
    immhi = (v >> 5) & 0x7FFFF
    imm = (immhi << 2) | immlo
    if imm & (1 << 20):
        imm -= 1 << 21
    rd = v & 0x1F
    page = (text['vaddr'] + i * 4) & ~0xFFF
    target = (page + (imm << 12)) & 0xFFFFFFFFFF
    # check page match against any target string
    for tv in tarr:
        if target <= int(tv) < target + 0x1000:
            # look ahead a few insns for add/ldr completing the address
            for j in range(1, 6):
                if i + j >= n: break
                v2 = int(insns[i + j])
                # ADD Xd, Xn, #imm12  : 0b100100010 (shift 0)
                if (v2 >> 24) == 0b10010001 and ((v2 >> 5) & 0x1F) == rd and (v2 & 0x1F):
                    final = target + ((v2 >> 10) & 0xFFF)
                    if final == int(tv):
                        refs.append((text['vaddr'] + i * 4, final))
                        break
                # LDR Xd, [Xn, #imm] : 1111 1001 01 imm12 Rn Rd
                if (v2 >> 22) == 0b1111100101 and ((v2 >> 5) & 0x1F) == rd:
                    refs.append((text['vaddr'] + i * 4, -1))  # ptr-to-ptr
                    break

print(f"\n=== ADRP+ADD direct refs: {len(refs)} ===")
for site, tgt in refs:
    print(f"  site {site:#x} -> {cstr(tgt,60) if tgt>0 else 'indirect'}")

# ---- 3. dump the neighborhood of each ref site ----
def dump_fn(site, back=0x100, fwd=0x300):
    """disassemble around a site, return interesting strings"""
    start = max(text['vaddr'], site - back) & ~3
    blob = read_vaddr(start, back + fwd)
    found = set()
    for insn in md.disasm(blob, start):
        m = insn.op_str
        # track adrp/add in the linear stream
        if insn.mnemonic == 'adrp':
            pass
    # simpler: re-scan this window with the vectorized approach
    win_n = len(blob) // 4
    wins = np.frombuffer(blob[:win_n * 4], dtype='<u4')
    for i in range(win_n - 1):
        v = int(wins[i])
        if (v >> 24) == 0b10010000:
            immlo = (v >> 29) & 3
            immhi = (v >> 5) & 0x7FFFF
            imm = (immhi << 2) | immlo
            if imm & (1 << 20):
                imm -= 1 << 21
            rd = v & 0x1F
            page = (start + i * 4) & ~0xFFF
            base = page + (imm << 12)
            v2 = int(wins[i + 1])
            if (v2 >> 24) == 0b10010001 and ((v2 >> 5) & 0x1F) == rd:
                s = cstr(base + ((v2 >> 10) & 0xFFF), 80)
                if s and all(32 <= c < 127 for c in s[:4]) and len(s) > 3:
                    found.add(s.decode('utf8', 'replace'))
    return found

print("\n=== string neighborhoods of the ref sites ===")
seen_fn = set()
for site, tgt in refs:
    if tgt < 0: continue
    strs = dump_fn(site)
    print(f"\n--- around {site:#x} (refs {cstr(tgt,40)}) ---")
    for s in sorted(strs)[:25]:
        print("   ", s)
