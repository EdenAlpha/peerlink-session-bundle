#!/usr/bin/env python3
"""M16e: find who references the pes22-game host string + the NTL gate URL
-> the URL/HTTP config functions."""
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        loads.append(dict(vaddr=seg['p_vaddr'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], flags=seg['p_flags']))
text = next(s for s in loads if s['flags'] & 1)

def read_vaddr(va, n):
    for s in loads:
        if s['vaddr'] <= va < s['vaddr'] + s['filesz']:
            off = s['offset'] + (va - s['vaddr'])
            f.seek(off)
            return f.read(n)
    return b''

def cstr(va, maxlen=120):
    b = read_vaddr(va, maxlen)
    e = b.find(b'\0')
    if e < 0: e = maxlen
    return b[:e].decode('utf8', 'replace')

# locate targets
data = open(SO, 'rb').read()
def off2va(off):
    for s in loads:
        if s['offset'] <= off < s['offset'] + s['filesz']:
            return s['vaddr'] + (off - s['offset'])
    return None

targets = {}
for name, t in (('host', b'pes22-game.cs.konami.net\x00'),
                ('ntlurl', b'http://ntl.service.konami.net'),
                ('rsa', b'-----BEGIN PUBLIC KEY-----'),
                ('appid', b'jp.konami.pesam')):
    off = data.find(t)
    if off >= 0:
        va = off2va(off)
        if va: targets[name] = va
print("targets:", {k: hex(v) for k, v in targets.items()})

tset = np.array(sorted(set(targets.values())), dtype=np.uint64)

code = read_vaddr(text['vaddr'], text['filesz'])
n = len(code) // 4
insns = np.frombuffer(code[:n*4], dtype='<u4')
is_adrp = (insns >> 24) == 0b10010000
adrp_idx = np.nonzero(is_adrp)[0]

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
hits = []
for i in adrp_idx:
    v = int(insns[i])
    immlo = (v >> 29) & 3
    immhi = (v >> 5) & 0x7FFFF
    imm = (immhi << 2) | immlo
    if imm & (1 << 20): imm -= 1 << 21
    rd = v & 0x1F
    page = (text['vaddr'] + i * 4) & ~0xFFF
    base = (page + (imm << 12)) & 0xFFFFFFFFFF
    for tv in tset:
        tv = int(tv)
        if base <= tv < base + 0x1000:
            # look ahead for the add/ldr
            for j in range(1, 4):
                if i + j >= n: break
                v2 = int(insns[i + j])
                if (v2 >> 24) == 0b10010001 and ((v2 >> 5) & 0x1F) == rd:
                    final = base + ((v2 >> 10) & 0xFFF)
                    if base <= tv < base + 0x1000 and (tv == final or abs(final - tv) < 0x60):
                        hits.append((text['vaddr'] + i * 4, tv))
                        break

print(f"\nrefs: {len(hits)}")
for site, tv in hits:
    name = [k for k, v in targets.items() if v == tv][0]
    print(f"  {site:#x} refs {name} ({tv:#x})")
    # dump annotated window
    blob = read_vaddr(site - 0x40, 0x180)
    last_adrp = {}
    for insn in md.disasm(blob, site - 0x40):
        line = f"    {insn.address:#x}: {insn.mnemonic} {insn.op_str}"
        if insn.mnemonic == 'adrp':
            parts = insn.op_str.split(', #')
            if len(parts) == 2:
                try: last_adrp[parts[0].strip()] = int(parts[1], 0) & 0xFFFFFFFFFF
                except ValueError: pass
        elif insn.mnemonic == 'add' and ', #' in insn.op_str:
            parts = [p.strip() for p in insn.op_str.split(',')]
            if len(parts) == 3 and parts[0] in last_adrp and parts[1] in last_adrp:
                try:
                    imm = int(parts[2].replace('#', ''), 0)
                    s = cstr(last_adrp[parts[1]] + imm)
                    if 2 < len(s) < 90 and all(31 < ord(c) < 127 for c in s[:6]):
                        line += f'   ; "{s}"'
                except ValueError: pass
        print(line)
