# eFootball 11.0.1 — Online Spine Recon (M15)

## Version confirmation
- Our binary: `jp.konami.pesam` v11.0.1, versionCode 311000101 (from the
  surgical download of the .apks bundle, apkcombo mirror of Google Play).
- User's installed game: 11.0.1. **MATCH CONFIRMED.**
- Internal lineage: `G:\PES22HC\Dev-600Series\Source\Shared\` (leaked dev
  paths) — PES22 Hybrid Client source tree, 600 series dev branch.
- Prior session's "3.4.1" label was wrong; dt270 = internal data version.

## Konami server infrastructure (all DNS-resolve + reachable from sandbox)
| Host | IP | Role |
|------|----|------|
| pes22-game.cs.konami.net | 44.226.252.93 | game coordination (CS) — PHP API |
| pesam.stun.service.konami.net | 35.76.243.83 | STUN/TURN (NAT hole punch) |
| ntl.service.konami.net | 18.179.74.81 | network gate (GateInfo.php) |
| info.service.konami.net | 35.79.166.126 | info/maintenance |

- `http://ntl.service.konami.net/ntl/api/GateInfo.php` responds (400 to
  bare GET = alive, needs proper request format).
- AWS-hosted (44.x, 35.x, 18.x ranges).

## Auth architecture
- Login model: **PHP-over-HTTP API** (not gRPC) — 330 `Cmd*.php` endpoints.
- Guest path exists: `CmdGetKgsGuestLoginToken.php` (KGS = Konami Game
  Service) — throwaway accounts, zero user-account risk.
- RSA-2048 public key embedded (see below) next to game server host.
- `SessionKeyEncryptionAlgorithm` / `SessionKeyEncryptionKeyLength` are
  CONFIG-DRIVEN key names — the cipher name arrives from server params
  at runtime (must find the parser in the disassembly).
- gRPC + application/grpc + application/octet-stream also present
  (used by match coordination: CmdConnectGrpc, HeartbeatGrpc,
  MatchControlSession).

## The friend-match API flow (endpoints confirmed present)
```
CmdCreateUser.php            create guest account
CmdLogin.php                  login
CmdGetSessionId.php           session establish
CmdCreatejoinRoom.php         CREATE ROOM  -> MATCH_ID (the number)
CmdGetRoomInfo.php            poll room state
CmdSendJoinRoomRequest.php    friend joins
CmdSetRoomSettings.php        match config
CmdSetRoomMatchReady.php      ready up
CmdStartGame.php              START MATCH
CmdGetTurnAddressData.php     TURN servers for relay fallback
CmdGetGameSession.php         match session
CmdCheckGameResult.php        result check
CmdSetGameResult.php          report result
CmdGetMatchingResult.php      matching status
```

## Onboarding gates (user warning confirmed: forced tutorial)
- `CmdGetMyclubTutorial.php` / `CmdSetMyclubTutorial.php` — tutorial
  progression is SERVER-TRACKED. The compulsory shooting/tackling
  training gates likely report completion through these (plus
  CmdGetVscomOpponent / CmdGetVscomGameResult for the forced AI match).
- Strategy options: (a) drive the tutorial with our headless engine (it
  IS the match engine), (b) replay the completion calls, (c) find the
  client-side skip path the game offers returning players.

## RSA-2048 public key (embedded, offsets ~0xa5ed56 region)
-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApC/7GywWS+F2J3/GcD2W
QiRAhGOp7Y8VkMThCczHTd/ygGmuCSH0312p+9u0vZv/v5MyuAWK8Gm9jbZuDwAY
uWKhgFCc4p9xoAMmLBzLoog81VWwQERu4QHRrH/p5z4G5I73aI253gGoZufLvhFO
cLomKOxgEERSvy9uk9zQ8FgIQ03mjKI6XWxIrIaxLg7Kvb5QgcHPQARqmkEgnlNY
/LS/P7lYUEt+leEyXTgzOq9iySmcQlhiUlfey26JQw06FZhT6aB/s5+/sTpxbGy9
cNf0MCPi8x2Eks0oSXc0PMFJkHK8xZf/ecWTAKzk24QNnpHEcpFfWRKSsgaJtzU+
mGHKeeCrZ9YF2n8rc7XJe+fKHK8L1qlz8pcXO/7sL3O1Mt9jKyDAuJivqlvs/V6a
qOjydXJ5HpL5LHSqPxRwost0dMDVMnntC4p75lmRYNyCCRwjF9ELJHgeAKOc2EZS
S2Z78Iw/+z+HAE1cC39yVETb4pDWWdeg4dFEeHSs8jpEnyJ6yATvI+w1Z1O1xGGe
A/pLpHAVEBrqNWWkkeY2klPnQu0R6LFdP36aL7+97y0/INKa/ovULwzGTlunyIFi
44iv4DzixU5N3pBzb5cI6ftqQhC+0R1zULwCrKoRxEX26CuI/ZkI8P20DCCDN516
BVYMH4rOt3mF9VafazdTg7cCAwEAAQ==
-----END PUBLIC KEY-----

## Next climb (in order)
1. Disassemble the Cmd*.php request builder: find xrefs to the endpoint
   strings -> the HTTP client path -> URL composition (base path
   prefix), headers, payload serialization (protobuf?), and where the
   RSA key is used (handshake? login token encryption?).
2. Run the KGS guest login under the harness (or reimplement the wire
   format if it's a thin wrapper).
3. GateInfo → server list → CreateUser → Login → GetSessionId.
4. Tutorial gate handling.
5. Room create → MATCH_ID → friend join → StartGame.
6. Bridge the match session (STUN/TURN + MatchControlSession) to the
   proven Unicorn engine harness.

---
# M16 addendum: wire protocol

## Login request (CmdLogin.php) — COMPLETE field list
auth_code, hash, client_version, platform, device_identifier, device,
lang, country_code[], os_version, model_name, gpu_name, soc_name,
is_rooting, phy_mem_used_mib, phy_mem_available_mib,
app_storage_used_mib, app_storage_available_mib,
data_storage_used_mib, data_storage_available_mib,
payment_store_link_send_info

## Request builder machinery (libUE4.so v11.0.1)
- 0x2f92514(map, "field") -> slot insert-by-name (std::map RB-tree)
- 0x2f913c8(string value) -> variant wrap; 0x2f9135c(int value)
- 0x2f92940 -> array append; 0x2f8f898 assign; 0x2f91730 destroy
- shared base 0x74e3374 (328 Cmd builders call it)
- login builder: 0x76b1530; endpoint-name SSO ctor at 0x76b13b0
- example disasm: scripts/m16b_login_disasm.py + m16c_annotated_dump.py

## Relocations = Android APS2 packed (DT_ANDROID_RELA @ file 0x2ed270)
- classic .rela.dyn parsing FAILS (garbage); use LIEF
- 1,335,097 relocs total; 1,297,240 R_AARCH64_RELATIVE
- decode: lief.parse(so).relocations
- NO pointers (code/reloc/raw/pool) to: GateInfo URL, pes22-game host,
  RSA key, stun host -> runtime-decrypted config (NTL init_array
  0x98bd898 with 1,868 initializers is the next target)

## Base APK (new, apk_lab/apks/base.apk)
- Java layer is a downloader only; all networking native
- 3 dex files scanned: no Konami endpoints in Java

## Next steps
1. Serializer: who consumes the request map -> bytes (json_string.cc
   xrefs / follow 0x2f91f98 callers up)
2. NTL URL decryption: run init_array under Unicorn, dump config
3. First live contact: GateInfo -> CmdGetKgsGuestLoginToken
4. Tutorial gates -> room create -> match session
