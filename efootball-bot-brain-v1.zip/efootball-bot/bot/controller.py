"""Touch execution: turns an ActionPlan into real taps on LDPlayer.

STATUS — skeleton, deliberately not yet battle-tested. Two things need the
running emulator before this layer is real (see README, "What needs the
emulator"):

  1. CALIBRATION. eFootball's touch layout is user-customisable, so the
     button coordinates below are placeholders until we screenshot YOUR
     layout and locate the buttons. `layout.json` (written by save_layout)
     overrides the defaults.
  2. MULTITOUCH. Holding the movement stick while tapping pass/shoot needs
     two simultaneous touch streams. Plain `adb shell input` can't do that;
     v1 below SEQUENCES single touches (stick swipe for most of the tick,
     then button presses — the stick releases for ~100 ms around each
     press, which the game tolerates). v2 will drive multitouch through
     raw `sendevent` once we can see the touch device on the emulator.

Everything above this layer (brain -> ActionPlan) is done and tested; this
file only matters once the emulator exists.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Optional

from .brain import Action, ActionPlan

# Placeholder coordinates for a 1280x720 landscape window, classic layout.
# EVERY value here must be re-measured before trusting it.
DEFAULT_LAYOUT = {
    "resolution": [1280, 720],
    "y_invert": True,              # screen y grows downward, pitch y upward
    "joystick": {"cx": 170, "cy": 560, "r": 90},
    "buttons": {
        "pass":    [1160, 620],
        "through": [1080, 500],
        "shoot":   [1210, 520],
        "lob":     [1000, 600],
        "sprint":  [930, 655],
        "tackle":  [1160, 620],     # attack/defense buttons share slots
        "slide":   [1080, 500],
        "switch":  [980, 460],
    },
    "_calibrated": False,
}

LAYOUT_PATH = Path(__file__).resolve().parent.parent / "layout.json"


class ADBController:
    """Sends an ActionPlan to the game window via adb."""

    def __init__(self, serial: str = "127.0.0.1:5555",
                 layout: Optional[dict] = None):
        self.serial = serial
        self.layout = layout or self._load_layout()

    # ------------------------------------------------------------- plumbing

    @staticmethod
    def _load_layout() -> dict:
        if LAYOUT_PATH.exists():
            with open(LAYOUT_PATH) as f:
                return json.load(f)
        return DEFAULT_LAYOUT

    def save_layout(self, layout: dict) -> None:
        with open(LAYOUT_PATH, "w") as f:
            json.dump(layout, f, indent=2)
        self.layout = layout

    def _adb(self, *args: str) -> subprocess.CompletedProcess:
        return subprocess.run(["adb", "-s", self.serial, *args],
                               capture_output=True, text=True, timeout=5)

    def connect(self) -> bool:
        r = subprocess.run(["adb", "connect", self.serial],
                           capture_output=True, text=True, timeout=5)
        return "connected" in r.stdout

    def screenshot(self, path: str = "/home/z/my-project/shot.png") -> Path:
        """Raw screencap for the vision layer / calibration."""
        r = subprocess.run(["adb", "-s", self.serial, "exec-out",
                             "screencap", "-p"], capture_output=True,
                            timeout=10)
        out = Path(path)
        out.write_bytes(r.stdout)
        return out

    # -------------------------------------------------------------- touches

    def tap(self, x: int, y: int) -> None:
        self._adb("shell", "input", "tap", str(int(x)), str(int(y)))

    def swipe(self, x1: int, y1: int, x2: int, y2: int,
              duration_ms: int) -> None:
        self._adb("shell", "input", "swipe", str(int(x1)), str(int(y1)),
                  str(int(x2)), str(int(y2)), str(int(duration_ms)))

    def press_button(self, action: Action, hold_s: float = 0.10) -> None:
        xy = self.layout["buttons"].get(action.value)
        if xy is None:
            return
        hold_ms = max(60, int(hold_s * 1000))
        # zero-length swipe = press and hold
        self.swipe(xy[0], xy[1], xy[0], xy[1], hold_ms)

    # --------------------------------------------------------------- driver

    def execute(self, plan: ActionPlan, tick_s: float = 1.0) -> None:
        """Play one second of the plan: stick first, then buttons."""
        if not self.layout.get("_calibrated", False):
            raise RuntimeError(
                "Layout not calibrated yet — run the calibration step "
                "against the live emulator before driving the game.")

        j = self.layout["joystick"]
        y_flip = -1.0 if self.layout.get("y_invert", True) else 1.0

        button_ms = sum(max(60, int(t.hold_s * 1000))
                        for t in plan.buttons) + 90 * len(plan.buttons)
        stick_ms = max(0, int(tick_s * 1000) - 80 - button_ms)

        if plan.steer.length > 0.15 and stick_ms > 120:
            tx = j["cx"] + plan.steer.x * j["r"]
            ty = j["cy"] + y_flip * plan.steer.y * j["r"]
            self.swipe(j["cx"], j["cy"], tx, ty, stick_ms)

        for t in plan.buttons:
            self.press_button(t.action, t.hold_s)


class PrintController:
    """Dry-run controller: logs what would be touched. For demos/tests."""

    def __init__(self):
        self.log: list[str] = []

    def execute(self, plan: ActionPlan, tick_s: float = 1.0) -> None:
        btns = ",".join(f"{t.action.value}({t.hold_s:.2f}s)"
                        for t in plan.buttons) or "-"
        self.log.append(f"stick=({plan.steer.x:.2f},{plan.steer.y:.2f}) "
                        f"sprint={plan.sprint} buttons=[{btns}] "
                        f"# {plan.note}")
