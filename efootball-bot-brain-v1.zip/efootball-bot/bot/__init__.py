"""eFootball friendly-match bot.

Pieces:
  bot.geom        - 2D vector math (pure stdlib)
  bot.state       - the GameState model: what the brain knows each second
  bot.brain       - the decision engine ("what do I do this second?")
  bot.tactics     - formation anchors (used by the simulator's off-ball AI)
  bot.controller  - turns a decision into touches on LDPlayer (ADB)
  sim.match       - a simplified but honest match simulator for testing
  tests.test_brain- scenario tests for the decision logic
"""
