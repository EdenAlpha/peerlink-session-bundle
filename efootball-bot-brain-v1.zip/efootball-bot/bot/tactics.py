"""Formations and off-ball movement targets.

Reality check: in the live game we control ONE player at a time and
eFootball's own AI moves everyone else — the brain never sees or drives
those players. These anchors exist purely for the SIMULATOR, so its 22
non-controlled players produce plausible pressure, space and possession
patterns to test the brain against. They are deliberately simple.

The anchor set is a 4-3-3. Numbers double as identity across the project.
"""
from __future__ import annotations

from .geom import Vec2, clamp
from .state import (
    PITCH_L, PITCH_W, OUR_GOAL, Player, Role, Side,
)

# num -> (role, anchor) in OUR attacking frame (+x = at their goal)
ANCHORS_433 = {
    1:  (Role.GK, Vec2(5.0, 34.0)),
    2:  (Role.DF, Vec2(22.0, 12.0)),    # LB
    4:  (Role.DF, Vec2(17.0, 27.0)),    # LCB
    5:  (Role.DF, Vec2(17.0, 41.0)),    # RCB
    6:  (Role.DF, Vec2(22.0, 56.0)),    # RB
    8:  (Role.MF, Vec2(40.0, 22.0)),    # LCM
    10: (Role.MF, Vec2(35.0, 34.0)),   # DM
    14: (Role.MF, Vec2(40.0, 46.0)),   # RCM
    7:  (Role.FW, Vec2(68.0, 12.0)),   # LW
    9:  (Role.FW, Vec2(74.0, 34.0)),   # ST
    11: (Role.FW, Vec2(68.0, 56.0)),   # RW
}

SPEED_BY_ROLE = {Role.GK: 6.4, Role.DF: 7.0, Role.MF: 7.2, Role.FW: 7.6}

COMPRESS_Y = 0.72       # defensive narrowness


def build_squad(team: Side) -> list:
    from .state import Player as P
    out = []
    for num, (role, anchor) in ANCHORS_433.items():
        if team is Side.THEM:
            anchor = anchor.flipped_x(PITCH_L)
        out.append(P(num=num, team=team, role=role, pos=anchor,
                     speed=SPEED_BY_ROLE[role]))
    return out


def target_for(p: Player, ball: Vec2, ball_team_is_ours: bool) -> Vec2:
    """Where this non-controlled player should be heading (pitch frame).

    Works for both teams: for THEM we compute in their own attacking frame
    (x mirrored, their goal at x'=0, the goal they attack at x'=105) and
    mirror the result back.
    """
    if p.team is Side.THEM:
        ball_own = ball.flipped_x(PITCH_L)
        we_attack = not ball_team_is_ours     # ball is with THEM?
        return _anchor_target(p, ball_own, we_attack).flipped_x(PITCH_L)

    return _anchor_target(p, ball, ball_team_is_ours)


def _anchor_target(p: Player, ball: Vec2, we_attack: bool) -> Vec2:
    """Target in OUR attacking frame (+x = at the opponent's goal).

    p.team must be US here, or (when called for THEM) the caller has already
    mirrored the world so that THEM is 'us' in this frame.
    """
    _, anchor = ANCHORS_433[p.num]

    if p.role is Role.GK:
        # hold the line between ball and goal center, up to ~6 m off the line
        mark = OUR_GOAL + (ball - OUR_GOAL).normalized() * 6.0
        return mark.clamped(Vec2(0.8, 22.0), Vec2(10.0, 46.0))

    if we_attack:
        # push up, keeping shape: quarter of the way toward the ball
        return anchor + (ball - anchor) * 0.25

    # defending: hold a LINE that tracks the ball (~14 m goal-side of it),
    # role-weighted so the shape stays a shape, not a pile in the box
    line_x = clamp(ball.x - 14.0, 6.0, 48.0)
    depth = {Role.GK: 0.0, Role.DF: 0.0, Role.MF: 10.0, Role.FW: 20.0}[p.role]
    x = min(line_x + depth, 58.0)
    y = 34.0 + (anchor.y - 34.0) * COMPRESS_Y + (ball.y - 34.0) * 0.12
    return Vec2(x, clamp(y, 3.0, PITCH_W - 3.0))
