"""Small 2D geometry helpers (pure stdlib, no dependencies).

All positions in the bot are meters on a 105 x 68 pitch — see bot/state.py
for the coordinate contract.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class Vec2:
    x: float
    y: float

    def __add__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x + o.x, self.y + o.y)

    def __sub__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x - o.x, self.y - o.y)

    def __neg__(self) -> "Vec2":
        return Vec2(-self.x, -self.y)

    def __mul__(self, k: float) -> "Vec2":
        return Vec2(self.x * k, self.y * k)

    def __rmul__(self, k: float) -> "Vec2":
        return Vec2(self.x * k, self.y * k)

    def __truediv__(self, k: float) -> "Vec2":
        return Vec2(self.x / k, self.y / k)

    def __repr__(self) -> str:
        return f"({self.x:.1f},{self.y:.1f})"

    @property
    def length(self) -> float:
        return math.hypot(self.x, self.y)

    def dist(self, o: "Vec2") -> float:
        return (self - o).length

    def normalized(self) -> "Vec2":
        n = self.length
        return self if n < 1e-9 else Vec2(self.x / n, self.y / n)

    def dot(self, o: "Vec2") -> float:
        return self.x * o.x + self.y * o.y

    def clamped(self, lo: "Vec2", hi: "Vec2") -> "Vec2":
        """Component-wise clamp (e.g. keep a point inside the pitch)."""
        return Vec2(min(max(self.x, lo.x), hi.x), min(max(self.y, lo.y), hi.y))

    def flipped_x(self, pitch_l: float) -> "Vec2":
        """Mirror across the halfway line: x -> pitch_l - x."""
        return Vec2(pitch_l - self.x, self.y)


def lerp(a: Vec2, b: Vec2, t: float) -> Vec2:
    return a + (b - a) * t


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def point_segment_dist(p: Vec2, a: Vec2, b: Vec2) -> float:
    """Distance from point p to the segment a->b."""
    ab = b - a
    l2 = ab.dot(ab)
    if l2 < 1e-9:
        return p.dist(a)
    t = clamp((p - a).dot(ab) / l2, 0.0, 1.0)
    return p.dist(a + ab * t)


def lane_clear(a: Vec2, b: Vec2, obstacles, clearance_m: float) -> bool:
    """True if no obstacle (anything with a .pos Vec2) sits within
    clearance_m of the segment a->b. Used for pass/shot lanes."""
    for o in obstacles:
        if point_segment_dist(o.pos, a, b) < clearance_m:
            return False
    return True
