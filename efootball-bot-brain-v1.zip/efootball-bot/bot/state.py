"""GameState — the shared language between vision, brain, and simulator.

Coordinate contract (meters, standard pitch 105 x 68):
  * x: 0 = OUR goal line, 105 = THEIR goal line. We ALWAYS attack +x in
    this model. In the live game the camera flips at halftime; the vision
    layer normalizes coordinates into this frame (see mirrored()).
  * y: 0 / 68 are the touchlines, 34 is the halfway line / goal center.

The same structure is produced by:
  - the simulator (ground truth), and later
  - the vision layer (estimated from emulator screenshots),
so the brain never has to care where its input came from.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import List, Optional, Tuple

from .geom import Vec2

PITCH_L = 105.0
PITCH_W = 68.0
GOAL_HALF = 3.66                      # 7.32 m goal mouth
THEIR_GOAL = Vec2(PITCH_L, PITCH_W / 2.0)
OUR_GOAL = Vec2(0.0, PITCH_W / 2.0)
PITCH_MIN = Vec2(0.5, 0.5)
PITCH_MAX = Vec2(PITCH_L - 0.5, PITCH_W - 0.5)


class Side(IntEnum):
    US = 0
    THEM = 1


class Role(str, Enum):
    GK = "GK"
    DF = "DF"
    MF = "MF"
    FW = "FW"


class Phase(Enum):
    OPEN_PLAY = "open"
    KICKOFF_US = "kickoff_us"
    KICKOFF_THEM = "kickoff_them"
    GOALKICK_US = "goalkick_us"
    GOALKICK_THEM = "goalkick_them"
    CORNER_US = "corner_us"
    CORNER_THEM = "corner_them"
    THROWIN_US = "throwin_us"
    THROWIN_THEM = "throwin_them"


_OUR_PHASES = {
    Phase.KICKOFF_US, Phase.GOALKICK_US, Phase.CORNER_US, Phase.THROWIN_US,
}
_THEIR_PHASES = {
    Phase.KICKOFF_THEM, Phase.GOALKICK_THEM, Phase.CORNER_THEM,
    Phase.THROWIN_THEM,
}
_MIRROR_PHASE = {
    Phase.KICKOFF_US: Phase.KICKOFF_THEM, Phase.KICKOFF_THEM: Phase.KICKOFF_US,
    Phase.GOALKICK_US: Phase.GOALKICK_THEM, Phase.GOALKICK_THEM: Phase.GOALKICK_US,
    Phase.CORNER_US: Phase.CORNER_THEM, Phase.CORNER_THEM: Phase.CORNER_US,
    Phase.THROWIN_US: Phase.THROWIN_THEM, Phase.THROWIN_THEM: Phase.THROWIN_US,
}


@dataclass
class Player:
    num: int                 # squad number, unique within the match
    team: Side
    role: Role
    pos: Vec2
    vel: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    speed: float = 7.0       # m/s off-ball top speed


@dataclass
class GameState:
    time_s: float                       # game clock, seconds since kickoff
    half: int
    score_us: int
    score_them: int
    ball: Vec2
    ball_vel: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    carrier: Optional[int] = None       # index into players; None = loose ball
    players: List[Player] = field(default_factory=list)
    phase: Phase = Phase.OPEN_PLAY
    # Where a flying ball is going to land (None while rolling/carried).
    # A human player reads this off the screen in an instant; the vision
    # layer will estimate it the same way (two frames of ball position).
    ball_landing: Optional[Vec2] = None

    # ------------------------------------------------------------------ views

    def ours(self) -> List[Player]:
        return [p for p in self.players if p.team is Side.US]

    def theirs(self) -> List[Player]:
        return [p for p in self.players if p.team is Side.THEM]

    def by_side(self, side: Side) -> List[Player]:
        return self.ours() if side is Side.US else self.theirs()

    @property
    def our_carrier(self) -> Optional[Player]:
        if self.carrier is None:
            return None
        p = self.players[self.carrier]
        return p if p.team is Side.US else None

    @property
    def their_carrier(self) -> Optional[Player]:
        if self.carrier is None:
            return None
        p = self.players[self.carrier]
        return p if p.team is Side.THEM else None

    def we_have_ball(self) -> bool:
        return self.our_carrier is not None

    # ------------------------------------------------------------- spatial ops

    def nearest_opponent(self, pos: Vec2) -> Tuple[Optional[Player], float]:
        best, bd = None, float("inf")
        for p in self.theirs():
            d = p.pos.dist(pos)
            if d < bd:
                best, bd = p, d
        return best, (bd if best is not None else 999.0)

    def mirrored(self) -> "GameState":
        """The same match seen from the OTHER side (x -> 105 - x, teams swap).

        Used for two things:
          1. the simulator lets both teams run a Brain written for 'us';
          2. live play after halftime: if the camera flips, vision can
             normalize by feeding mirrored() to the brain instead of
             maintaining two coordinate frames.
        Player list order (and therefore every player index, including
        `carrier`) is preserved.
        """
        players = [
            Player(
                num=p.num,
                team=Side(1 - int(p.team)),
                role=p.role,
                pos=p.pos.flipped_x(PITCH_L),
                vel=Vec2(-p.vel.x, p.vel.y),
                speed=p.speed,
            )
            for p in self.players
        ]
        return GameState(
            time_s=self.time_s,
            half=self.half,
            score_us=self.score_them,
            score_them=self.score_us,
            ball=self.ball.flipped_x(PITCH_L),
            ball_vel=Vec2(-self.ball_vel.x, self.ball_vel.y),
            carrier=self.carrier,
            players=players,
            phase=_MIRROR_PHASE.get(self.phase, self.phase),
            ball_landing=None if self.ball_landing is None
            else self.ball_landing.flipped_x(PITCH_L),
        )
