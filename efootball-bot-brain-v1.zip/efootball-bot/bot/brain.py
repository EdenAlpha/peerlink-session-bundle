"""The brain: turns a GameState into one second's worth of touch input.

Contract
--------
Called once per second (the "1 Hz decision loop") with the freshest state
the vision layer can produce, plus the index of the player we are currently
controlling. Returns an ActionPlan:

  * steer   — joystick direction (unit vector, pitch frame: +x = at their goal)
  * sprint  — hold the sprint button
  * buttons— list of (button, hold_seconds) touches
  * intent  — where the pass/shot was AIMED (kind + target + power)

The controller only needs steer + buttons (that is literally all the game
sees). `intent` exists so the simulator and the unit tests can verify WHERE
an action was aimed — the real game infers that from stick + button itself.

Design notes
------------
* No I/O, no randomness: pure decisions, fully unit-testable.
* One player per second: in eFootball you control one player at a time;
  teammates are the game's own AI. Off-ball logic here only covers the
  brief moments we hold a non-carrier while our team has the ball.
* The brain is stateful ONLY for the through-ball cooldown (otherwise it
  would spam the same ball every second).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

from .geom import Vec2, clamp, lane_clear
from .state import (
    PITCH_L, PITCH_W, OUR_GOAL, THEIR_GOAL,
    GameState, Phase, Player, Role,
)


# ----------------------------------------------------------------- plan types

class Action(Enum):
    """Touch targets. Names match controller layout keys 1:1."""
    PASS = "pass"        # short pass (attack)
    THROUGH = "through"  # through ball
    LOB = "lob"          # lofted pass / clearance / cross
    SHOOT = "shoot"
    SPRINT = "sprint"
    TACKLE = "tackle"    # press / standing tackle (defense)
    SLIDE = "slide"      # slide tackle (rarely used: high risk)
    SWITCH = "switch"    # cycle controlled player


@dataclass
class Touch:
    action: Action
    hold_s: float = 0.10          # seconds to hold the button


@dataclass
class Intent:
    kind: str                     # "pass" | "through" | "lob" | "shot" | "cross"
    target: Vec2
    power: float = 1.0            # 0..1


@dataclass
class ActionPlan:
    steer: Vec2 = field(default_factory=lambda: Vec2(0.0, 0.0))
    sprint: bool = False
    buttons: List[Touch] = field(default_factory=list)
    intent: Optional[Intent] = None
    note: str = ""
    # Where this movement is trying to end up (if it's a "get there"
    # movement rather than an open-ended run). The touch controller IGNORES
    # this — the stick only knows direction — but the simulator clamps the
    # stride to it so players stop on the ball instead of overshooting.
    move_target: Optional[Vec2] = None


def mirrored_plan(p: ActionPlan) -> ActionPlan:
    """Flip a plan back when it was produced for a mirrored GameState."""
    intent = None
    if p.intent is not None:
        intent = Intent(p.intent.kind, p.intent.target.flipped_x(PITCH_L),
                        p.intent.power)
    return ActionPlan(
        steer=Vec2(-p.steer.x, p.steer.y),
        sprint=p.sprint,
        buttons=list(p.buttons),
        intent=intent,
        note=p.note,
        move_target=None if p.move_target is None
        else p.move_target.flipped_x(PITCH_L),
    )


# ------------------------------------------------------------------ configur.

@dataclass
class BrainConfig:
    # attack
    shoot_range_m: float = 21.0        # shoot inside this distance to goal
    shot_clearance_m: float = 1.2      # no opponent within this of shot lane
    pressure_pass_m: float = 3.2       # pass when pressed closer than this
    min_openness_pass: float = 3.0     # receiver must be this open (m)
    through_gap_m: float = 5.0         # space required at through-ball landing
    through_cooldown_s: float = 6.0    # min seconds between through balls
    clear_pressure_m: float = 1.4      # hoof it when pressed this hard
    # defense
    tackle_range_m: float = 1.9
    # game management
    chase_game_minute: float = 78.0    # losing after this minute -> go direct
    chase_range_bonus_m: float = 5.0  # ...and shoot from further out
    # ball (nominal — the sim owns real speeds; used only for pass lead)
    pass_speed_mps: float = 15.0


# ---------------------------------------------------------------------- brain

class Brain:
    def __init__(self, cfg: BrainConfig | None = None):
        self.cfg = cfg or BrainConfig()
        self._last_through_t = -999.0

    # ----------------------------------------------------------------- entry

    def think(self, s: GameState, controlled: int) -> ActionPlan:
        try:
            if s.phase in (Phase.KICKOFF_US, Phase.GOALKICK_US,
                          Phase.CORNER_US, Phase.THROWIN_US):
                return self._our_restart(s, controlled)
            return self._open_play(s, controlled)
        except Exception as exc:                       # never kill the loop
            return ActionPlan(note=f"safe fallback ({type(exc).__name__}: {exc})")

    # ------------------------------------------------------------ open play

    def _open_play(self, s: GameState, controlled: int) -> ActionPlan:
        me = s.players[controlled]

        if s.our_carrier is not None:
            if s.carrier == controlled:
                return self._attack(s, me)
            return self._support(s, me)

        if s.their_carrier is not None:
            return self._defend(s, me)

        return self._chase(s, me)

    # --------------------------------------------------------------- attack

    def _attack(self, s: GameState, me: Player) -> ActionPlan:
        cfg = self.cfg
        d_goal = me.pos.dist(THEIR_GOAL)
        near_opp, d_opp = s.nearest_opponent(me.pos)
        field_opps = [o for o in s.theirs() if o.role is not Role.GK]

        # keeper on the ball: distribute, never dribble out of the box.
        # If anyone is nearby, don't mess about — play it long and wide.
        if me.role is Role.GK:
            _, d_opp = s.nearest_opponent(me.pos)
            mate = self._best_pass(s, me)
            mate_open = 99.0
            if mate is not None:
                mate_open = min((o.pos.dist(mate.pos) for o in s.theirs()),
                                default=99.0)
            if d_opp > 3.0 and mate is not None:
                return self._pass_plan(s, me, mate)
            if mate is not None and mate_open > 5.0:
                return self._pass_plan(s, me, mate)
            side = 1.0 if me.pos.y < PITCH_W / 2 else -1.0
            target = Vec2(62.0, clamp(me.pos.y + side * 26.0, 4, 64))
            return ActionPlan(
                steer=(target - me.pos).normalized(), sprint=False,
                buttons=[Touch(Action.LOB, 0.55)],
                intent=Intent("lob", target, 1.0),
                note="keeper plays it long",
            )

        # trailing late -> gamble from range
        late = (s.time_s > cfg.chase_game_minute * 60.0
                and s.score_us < s.score_them)
        shoot_range = cfg.shoot_range_m + (cfg.chase_range_bonus_m if late else 0.0)

        # 1) SHOOT — in range and lane to the far post is clean
        if d_goal < shoot_range:
            aim = self._shot_target(s)
            if lane_clear(me.pos, aim, field_opps, cfg.shot_clearance_m):
                power = clamp(0.35 + 0.65 * d_goal / 26.0, 0.30, 1.0)
                return ActionPlan(
                    steer=(aim - me.pos).normalized(),
                    sprint=False,
                    buttons=[Touch(Action.SHOOT, 0.08 + 0.50 * power)],
                    intent=Intent("shot", aim, power),
                    note=f"shoot {d_goal:.0f}m aim y={aim.y:.0f}",
                )

        # 2) THROUGH BALL — runner going in behind their line
        runner, spot = self._find_runner(s, me, field_opps)
        if runner is not None and (s.time_s - self._last_through_t
                                   ) > cfg.through_cooldown_s:
            self._last_through_t = s.time_s
            return self._ball_plan(
                s, me, runner, spot, Action.THROUGH, "through", power=0.9,
                note=f"through -> #{runner.num} at ({spot.x:.0f},{spot.y:.0f})")

        # 3) PASS — relieve pressure to the best open teammate
        if d_opp < cfg.pressure_pass_m:
            mate = self._best_pass(s, me)
            if mate is not None:
                return self._pass_plan(s, me, mate)

        # 4) CLEARANCE — pressed hard with no pass on: hoof it upfield
        if d_opp < cfg.clear_pressure_m:
            side = 1.0 if me.pos.y < PITCH_W / 2 else -1.0
            target = Vec2(PITCH_L - 18.0, clamp(me.pos.y + side * 28.0, 3, 65))
            return ActionPlan(
                steer=(target - me.pos).normalized(), sprint=False,
                buttons=[Touch(Action.LOB, 0.5)],
                intent=Intent("lob", target, 1.0),
                note=f"clearance lob ({d_opp:.1f}m press)",
            )

        # 5) DRIBBLE — carry it, steering around pressure
        return self._dribble(s, me, d_opp)

    def _dribble(self, s: GameState, me: Player, d_opp: float) -> ActionPlan:
        steer = (THEIR_GOAL - me.pos).normalized()

        # shield and turn: repulsion from the two nearest opponents —
        # enough to steer around pressure, not so much that we dribble
        # away from their goal for whole possessions
        opps = sorted(s.theirs(), key=lambda o: o.pos.dist(me.pos))[:2]
        for k, o in enumerate(opps):
            away = me.pos - o.pos
            d = away.length
            if k == 0:
                if d < 6.0:
                    steer = steer + away.normalized() * (6.0 - d) * 0.5
            elif d < 5.0:
                steer = steer + away.normalized() * (5.0 - d) * 0.4

        # stay off the touchlines — hard rules, not hints: near a line,
        # the component that would take us out is simply removed
        if me.pos.y < 7.0 and steer.y < 0.3:
            steer = Vec2(steer.x, 0.5)
        if me.pos.y > PITCH_W - 7.0 and steer.y > -0.3:
            steer = Vec2(steer.x, -0.5)
        # never carry the ball into our own box
        if me.pos.x < 16.0 and steer.x < 0.3:
            steer = Vec2(0.3, steer.y)
        if me.pos.x > PITCH_L - 7.0 and steer.x > -0.3:
            steer = Vec2(-0.3, steer.y)

        steer = steer.normalized()
        sprint = d_opp > 3.0 and me.pos.x > 25.0   # keep close control in traffic
        return ActionPlan(steer=steer, sprint=sprint,
                           note=f"carry ball ({d_opp:.1f}m press)")

    def _support(self, s: GameState, me: Player) -> ActionPlan:
        """We have the ball but control someone else: run into space ahead."""
        c = s.our_carrier
        base = c.pos + (THEIR_GOAL - c.pos).normalized() * 9.0
        # offset toward the sideline we're already on, to stretch the play
        side = 1.0 if me.pos.y < PITCH_W / 2 else -1.0
        target = base + Vec2(0.0, side * 8.0)
        target = target.clamped(Vec2(2, 2), Vec2(PITCH_L - 2, PITCH_W - 2))
        steer = (target - me.pos).normalized()
        return ActionPlan(steer=steer, sprint=True, note="run into space",
                           move_target=target)

    # ------------------------------------------------------------- shot/pass

    def _shot_target(self, s: GameState) -> Vec2:
        """Far post: aim away from where the keeper stands."""
        gk = next((o for o in s.theirs() if o.role is Role.GK), None)
        if gk is not None and gk.pos.y < PITCH_W / 2:
            aim_y = PITCH_W / 2 + 2.6
        else:
            aim_y = PITCH_W / 2 - 2.6
        return Vec2(PITCH_L, aim_y)

    def _find_runner(self, s: GameState, me: Player, field_opps
                     ) -> Tuple[Optional[Player], Optional[Vec2]]:
        """A teammate ahead of the ball whose landing spot is in behind their
        last defender, reachable through a clean lane, into open space."""
        if not field_opps:
            return None, None
        line_x = max(o.pos.x for o in field_opps)
        best, best_spot, best_score = None, None, -1e9
        for m in s.ours():
            if m.num == me.num or m.role is Role.GK:
                continue
            if m.pos.x < me.pos.x + 6.0:
                continue                        # must be ahead of the ball
            spot = Vec2(min(m.pos.x + 9.0, PITCH_L - 4.0),
                        clamp(m.pos.y + m.vel.y * 0.8, 2.0, PITCH_W - 2.0))
            if spot.x < line_x + 1.0:
                continue                        # must land beyond their line
            if not lane_clear(me.pos, spot, field_opps, 1.5):
                continue
            space = min(o.pos.dist(spot) for o in field_opps)
            if space < self.cfg.through_gap_m:
                continue
            score = space + (spot.x - line_x)
            if score > best_score:
                best, best_spot, best_score = m, spot, score
        return best, best_spot

    def _best_pass(self, s: GameState, me: Player) -> Optional[Player]:
        field_opps = [o for o in s.theirs() if o.role is not Role.GK]
        # lanes out of our own third need more air than ones further up
        lane_r = 2.0 if me.pos.x < 25.0 else 1.4
        best, best_score = None, -1e9
        for m in s.ours():
            if m.num == me.num:
                continue
            if m.role is Role.GK and me.role is not Role.GK:
                continue                        # never pass back to the keeper
            openness = min(12.0, min((o.pos.dist(m.pos) for o in s.theirs()),
                                      default=12.0))
            if openness < self.cfg.min_openness_pass:
                continue
            if not lane_clear(me.pos, m.pos, field_opps, lane_r):
                continue
            danger = -4.0 if (m.pos.x < 14.0 and abs(m.pos.y - 34.0) < 14.0) else 0.0
            score = openness * 0.8 + (m.pos.x - me.pos.x) * 0.30 + danger \
                + (2.0 if m.role is Role.FW else 0.0)
            if score > best_score:
                best, best_score = m, score
        return best

    def _pass_plan(self, s: GameState, me: Player, mate: Player) -> ActionPlan:
        tt = me.pos.dist(mate.pos) / self.cfg.pass_speed_mps
        lead = (mate.pos + mate.vel * tt).clamped(
            Vec2(1, 1), Vec2(PITCH_L - 1, PITCH_W - 1))
        return self._ball_plan(s, me, mate, lead, Action.PASS, "pass",
                               power=0.85, note=f"pass -> #{mate.num}")

    def _ball_plan(self, s: GameState, me: Player, mate: Player, spot: Vec2,
                   action: Action, kind: str, power: float, note: str
                   ) -> ActionPlan:
        return ActionPlan(
            steer=(spot - me.pos).normalized(),
            sprint=False,
            buttons=[Touch(action, 0.12)],
            intent=Intent(kind, spot, power),
            note=note,
        )

    # -------------------------------------------------------------- defense

    def _defend(self, s: GameState, me: Player) -> ActionPlan:
        threat = s.their_carrier
        assert threat is not None

        if me.role is Role.GK:
            # hold the line: sit between ball and goal center, max ~5 m out
            mark = OUR_GOAL + (threat.pos - OUR_GOAL).normalized() * 5.0
            return ActionPlan(steer=(mark - me.pos).normalized(),
                              note="keeper holds line")

        d = me.pos.dist(threat.pos)

        if d < self.cfg.tackle_range_m:
            return ActionPlan(
                steer=(threat.pos - me.pos).normalized(), sprint=True,
                buttons=[Touch(Action.TACKLE, 0.10)],
                note=f"tackle (d={d:.1f}m)",
                move_target=threat.pos,
            )

        # pursuit: run to where our paths CROSS, not where he stands.
        # Chasing his current spot against a 7.7 m/s runner is a permanent
        # 7 m shadow — the intercept closes because our sprint beats his
        # dribble speed and we cut the angle instead of following it.
        spot = self._intercept_point(me, threat)
        mark = spot + (OUR_GOAL - spot).normalized() * 0.25
        return ActionPlan(
            steer=(mark - me.pos).normalized(),
            sprint=d > 1.6,
            note=f"jockey carrier (d={d:.1f}m)",
            move_target=mark,
        )

    def _intercept_point(self, me: Player, threat: Player) -> Vec2:
        """Iterated pursuit: refine the meeting time until it stabilises."""
        t = 0.0
        spot = threat.pos
        for _ in range(3):
            spot = threat.pos + threat.vel * t
            t = me.pos.dist(spot) / max(me.speed * 1.22, 0.5)
        return spot.clamped(Vec2(0.5, 0.5),
                            Vec2(PITCH_L - 0.5, PITCH_W - 0.5))

    def _chase(self, s: GameState, me: Player) -> ActionPlan:
        # if the ball is flying, run to where it LANDS; the naive
        # ball+vel/2 prediction overshoots a 16 m/s pass by 8 meters
        # and sends you to the wrong side of it
        if s.ball_landing is not None:
            target = s.ball_landing
        else:
            target = (s.ball + s.ball_vel * 0.5).clamped(
                Vec2(0.5, 0.5), Vec2(PITCH_L - 0.5, PITCH_W - 0.5))
        return ActionPlan(steer=(target - me.pos).normalized(), sprint=True,
                           note="chase loose ball", move_target=target)

    # ------------------------------------------------------------ set pieces

    def _our_restart(self, s: GameState, controlled: int) -> ActionPlan:
        me = s.players[controlled]
        phase = s.phase

        if phase is Phase.KICKOFF_US:
            mate = self._most_open_near(s, me, radius=22.0, prefer_back=True)
            if mate is None:
                mate = self._best_pass(s, me)
            if mate is not None:
                return self._pass_plan(s, me, mate)
            return self._dribble(s, me, 99.0)

        if phase is Phase.GOALKICK_US:
            mate = self._best_pass(s, me)
            if mate is None:
                # everyone marked: clear long
                side = 1.0 if me.pos.y < PITCH_W / 2 else -1.0
                target = Vec2(60.0, clamp(34.0 + side * 20.0, 4, 64))
                return ActionPlan(
                    steer=(target - me.pos).normalized(),
                    buttons=[Touch(Action.LOB, 0.6)],
                    intent=Intent("lob", target, 1.0),
                    note="goal kick: long",
                )
            return self._pass_plan(s, me, mate)

        if phase is Phase.CORNER_US:
            # cross toward the far-post zone, away from the corner we're on
            side = 1.0 if s.ball.y < PITCH_W / 2 else -1.0
            target = Vec2(PITCH_L - 7.5, clamp(PITCH_W / 2 + side * 6.0, 26, 42))
            return ActionPlan(
                steer=(target - me.pos).normalized(),
                buttons=[Touch(Action.LOB, 0.45)],
                intent=Intent("cross", target, 0.75),
                note=f"corner: cross to far post",
            )

        # THROWIN_US
        mate = self._most_open_near(s, me, radius=25.0, prefer_back=False)
        if mate is None:
            mate = self._best_pass(s, me)
        if mate is not None:
            return self._pass_plan(s, me, mate)
        return self._dribble(s, me, 99.0)

    def _most_open_near(self, s: GameState, me: Player, radius: float,
                        prefer_back: bool) -> Optional[Player]:
        cands = [m for m in s.ours()
                 if m.num != me.num and m.role is not Role.GK
                 and m.pos.dist(me.pos) <= radius]
        if not cands:
            return None

        def key(m: Player) -> float:
            openness = min((o.pos.dist(m.pos) for o in s.theirs()), default=12.0)
            back = 2.0 if (m.pos.x <= me.pos.x + 3.0) else 0.0 if prefer_back else 0.0
            return openness + back

        best = max(cands, key=key)
        if min((o.pos.dist(best.pos) for o in s.theirs()), default=12.0) < 1.6:
            return None
        return best
