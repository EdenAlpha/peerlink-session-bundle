"""Scenario tests for the decision brain (plain runner, no pytest needed).

Run from the project root:
    python -m tests.test_brain
"""
