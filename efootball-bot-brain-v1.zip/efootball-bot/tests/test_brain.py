"""Scenario tests for the Brain: freeze a match situation, ask for one
second of decisions, assert the plan makes football sense.

Run from the project root:  python -m tests.test_brain
"""
from __future__ import annotations

import sys
import traceback

from bot.brain import Action, Brain, BrainConfig
from bot.geom import Vec2
from bot.state import (
    PITCH_W, GameState, Phase, Player, Role, Side,
)

US, THEM = Side.US, Side.THEM


def P(num, role, x, y, team=US, vel=(0.0, 0.0)):
    return Player(num=num, team=team, role=role, pos=Vec2(x, y),
                  vel=Vec2(*vel))


def state(players, carrier, phase=Phase.OPEN_PLAY, time_s=30 * 60.0,
          score=(0, 0), ball=None):
    ps = list(players)
    b = ball if ball is not None else ps[carrier].pos
    return GameState(time_s=time_s, half=1, score_us=score[0],
                     score_them=score[1], ball=b, carrier=carrier,
                     players=ps, phase=phase)


def think_once(s, idx):
    return Brain().think(s, idx)


def kind(plan):
    return plan.intent.kind if plan.intent else None


def has_button(plan, action):
    return any(t.action is action for t in plan.buttons)


# ----------------------------------------------------------------- scenarios

def test_open_shot():
    """Clean through on goal, 15m out, nobody near -> SHOOT at the far post."""
    s = state([
        P(9, Role.FW, 90, 34),
        P(1, Role.GK, 104, 30, team=THEM),
        P(4, Role.DF, 60, 10, team=THEM),
    ], carrier=0)
    plan = think_once(s, 0)
    assert kind(plan) == "shot", f"expected shot, got {plan.note}"
    assert plan.intent.target.x > 100, "must aim at their goal"
    assert abs(plan.intent.target.y - 36.6) < 0.1, "far post away from keeper"


def test_pressed_relieves_pressure():
    """Pressed 2m in midfield, runner free ahead, deep opponent line ->
    ball keeps moving (pass or through), not a dribble into the press."""
    s = state([
        P(10, Role.MF, 30, 34),
        P(9, Role.FW, 55, 45),
        P(4, Role.DF, 65, 20, team=THEM),
        P(5, Role.DF, 65, 48, team=THEM),
        P(8, Role.MF, 28, 33, team=THEM),     # the presser, ~2m away behind
    ], carrier=0)
    plan = think_once(s, 0)
    assert kind(plan) in ("pass", "through"), \
        f"pressed should keep the ball moving, got: {plan.note}"
    assert not has_button(plan, Action.SHOOT)


def test_through_ball_to_runner():
    """Runner level with the last defender, lane clean, space in behind ->
    THROUGH ball, aimed beyond the defensive line."""
    s = state([
        P(8, Role.MF, 55, 34),
        P(9, Role.FW, 79, 26),
        P(4, Role.DF, 80, 20, team=THEM),
        P(5, Role.DF, 80, 48, team=THEM),
        P(1, Role.GK, 103, 34, team=THEM),
    ], carrier=0)
    plan = think_once(s, 0)
    assert kind(plan) == "through", f"expected through, got {plan.note}"
    assert plan.intent.target.x > 80, "must land beyond the last defender"


def test_tackle_when_close():
    """Their carrier 1.2m from our controlled defender -> standing TACKLE."""
    s = state([
        P(4, Role.DF, 41.2, 34),
        P(9, Role.FW, 40, 34, team=THEM),
    ], carrier=1)
    plan = think_once(s, 0)
    assert has_button(plan, Action.TACKLE), f"expected tackle, got {plan.note}"


def test_jockey_when_not_close():
    """7m from their carrier: contain goal-side, no dive-in."""
    s = state([
        P(4, Role.DF, 45, 40),
        P(9, Role.FW, 40, 34, team=THEM),
    ], carrier=1)
    plan = think_once(s, 0)
    assert not has_button(plan, Action.TACKLE), "must not dive in from 7m"
    assert plan.steer.x < 0.0, "should shade toward our goal side"


def test_kickoff_passes():
    """Kickoff: give it to an open teammate behind, never a hero dribble."""
    s = state([
        P(9, Role.FW, 52, 34),
        P(10, Role.MF, 46, 34),
        P(2, Role.DF, 30, 12, team=THEM),
        P(1, Role.GK, 100, 34, team=THEM),
    ], carrier=0, phase=Phase.KICKOFF_US)
    plan = think_once(s, 0)
    assert kind(plan) in ("pass", "through"), \
        f"kickoff should release the ball, got {plan.note}"


def test_goal_kick_distributes():
    """Goal kick: keeper passes out wide, never dribbles, never shoots."""
    s = state([
        P(1, Role.GK, 5.5, 34),
        P(4, Role.DF, 18, 27),
        P(9, Role.FW, 90, 34, team=THEM),
    ], carrier=0, phase=Phase.GOALKICK_US)
    plan = think_once(s, 0)
    assert kind(plan) in ("pass", "through", "lob"), \
        f"goal kick should move the ball, got {plan.note}"
    assert plan.intent.target.x > 12, "should not restart backwards into our box"


def test_dribble_stays_off_touchline():
    """Winger by his own touchline with a defender inside -> carries infield."""
    s = state([
        P(7, Role.FW, 70, 4),
        P(2, Role.DF, 72, 8, team=THEM),
        P(1, Role.GK, 103, 32, team=THEM),
    ], carrier=0)
    plan = think_once(s, 0)
    assert kind(plan) is None, f"no pressure solution expected, got {plan.note}"
    assert plan.steer.y > 0.2, f"should cut inside, steer={plan.steer}"


def test_no_suicidal_pass():
    """Pressed but every teammate marked -> keep dribbling rather than
    passing into coverage."""
    s = state([
        P(4, Role.DF, 25, 34),
        P(5, Role.DF, 15, 27),
        P(8, Role.MF, 40, 20),
        P(2, Role.DF, 27.4, 34, team=THEM),   # presser 2.4m
        P(4, Role.DF, 16.5, 27.5, team=THEM),  # marks DF 5
        P(10, Role.DF, 41.5, 20.5, team=THEM),  # marks MF 8
    ], carrier=0)
    plan = think_once(s, 0)
    assert kind(plan) != "pass", \
        f"must not pass into coverage: {plan.note} -> {plan.intent}"


def test_chasing_game_shoots_from_range():
    """1-0 down in the 85th minute: widen the shooting range and gamble."""
    s = state([
        P(10, Role.MF, 80, 34),
        P(1, Role.GK, 104, 30, team=THEM),
        P(4, Role.DF, 60, 10, team=THEM),
        P(5, Role.DF, 60, 50, team=THEM),
    ], carrier=0, time_s=85 * 60.0, score=(0, 1))
    plan = think_once(s, 0)
    assert kind(plan) == "shot", \
        f"chasing the game should gamble from 25m, got {plan.note}"


def test_never_shoots_from_distance_in_normal_time():
    """Same spot, 30th minute, level: patient, not a 25m speculative hit."""
    s = state([
        P(10, Role.MF, 80, 34),
        P(1, Role.GK, 104, 30, team=THEM),
        P(4, Role.DF, 60, 10, team=THEM),
        P(5, Role.DF, 60, 50, team=THEM),
    ], carrier=0, time_s=30 * 60.0, score=(0, 0))
    plan = think_once(s, 0)
    assert kind(plan) != "shot", "25m pot-shot in normal time is bad process"


def test_keeper_holds_line():
    """Their striker through on our goal, we control the keeper: stay
    goal-side on the line, no charging out, no tackle button."""
    s = state([
        P(1, Role.GK, 3, 33),
        P(9, Role.FW, 14, 34.5, team=THEM, vel=(6.0, 0.0)),
    ], carrier=1)
    plan = think_once(s, 0)
    assert not has_button(plan, Action.TACKLE)
    assert not plan.sprint
    assert plan.steer.length <= 1.0 + 1e-6


# ------------------------------------------------------------------- runner

def main() -> int:
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
        except AssertionError as e:
            failed += 1
            print(f"  FAIL  {name}: {e}")
        except Exception:
            failed += 1
            print(f"  ERROR {name}:")
            print(traceback.format_exc())
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
