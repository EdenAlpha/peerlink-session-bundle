"""Simulator package: a simplified 2D match engine + runner.

NOT a replica of the game engine — that lives in /apk_lab (bit-exact
unicorn-driven ball kernel). This is a fast, honest test harness for the
decision brain: plausible geometry and possession flow, borrowed real
constants where we have them, placeholder probabilities where we don't.
"""
