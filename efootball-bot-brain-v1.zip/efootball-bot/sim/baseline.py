"""SimpleBrain — the deliberately naive sparring partner.

Exists so the simulator can measure how much the real Brain's decision
quality is actually worth. It plays like a tired human at 2 a.m.:

  * dribbles in straight lines at the goal, ignoring defenders
  * passes only when pressured, to the most advanced teammate,
    without leading the runner or checking the lane
  * shoots only from 16 m even if someone's standing in front of it
  * chases the ball carrier's CURRENT position (no intercept lead)

Same think() contract as Brain, so it can be dropped in anywhere.
"""
from __future__ import annotations

from bot.brain import Action, ActionPlan, Intent, Touch
from bot.geom import Vec2
from bot.state import (
    PITCH_L, PITCH_W, THEIR_GOAL, GameState, Phase, Player, Role,
)


class SimpleBrain:
    def think(self, s: GameState, controlled: int) -> ActionPlan:
        me = s.players[controlled]

        # set pieces: just get rid of it to the nearest teammate
        if s.phase in (Phase.KICKOFF_US, Phase.GOALKICK_US, Phase.CORNER_US,
                      Phase.THROWIN_US):
            if s.our_carrier is not None:
                cands = [m for m in s.ours()
                         if m.num != me.num and m.role is not Role.GK]
                if cands:
                    mate = min(cands, key=lambda m: m.pos.dist(me.pos))
                    return ActionPlan(
                        steer=(mate.pos - me.pos).normalized(),
                        buttons=[Touch(Action.PASS, 0.12)],
                        intent=Intent("pass", mate.pos, 0.85),
                        note=f"restart pass -> #{mate.num}")

        if s.our_carrier is not None:
            if s.carrier == controlled:
                return self._attack(s, me)
            return ActionPlan(steer=(THEIR_GOAL - me.pos).normalized(),
                              sprint=True, note="run")

        if s.their_carrier is not None:
            c = s.their_carrier
            if me.pos.dist(c.pos) < 1.6:
                return ActionPlan(steer=(c.pos - me.pos).normalized(),
                                  sprint=True,
                                  buttons=[Touch(Action.TACKLE, 0.1)],
                                  note="poke", move_target=c.pos)
            return ActionPlan(steer=(c.pos - me.pos).normalized(),
                              sprint=True, note="chase",
                              move_target=c.pos)

        # loose ball: run to where it lands if it's flying
        target = s.ball_landing if s.ball_landing is not None else s.ball
        return ActionPlan(steer=(target - me.pos).normalized(),
                          sprint=True, note="ball", move_target=target)

    def _attack(self, s: GameState, me: Player) -> ActionPlan:
        d_goal = me.pos.dist(THEIR_GOAL)
        near, d_opp = s.nearest_opponent(me.pos)

        # keeper on the ball: knock it to a defender, do not dribble
        if me.role is Role.GK:
            cands = [m for m in s.ours()
                     if m.num != me.num and m.role is not Role.GK]
            if cands:
                mate = min(cands, key=lambda m: m.pos.dist(me.pos))
                return ActionPlan(
                    steer=(mate.pos - me.pos).normalized(),
                    buttons=[Touch(Action.PASS, 0.12)],
                    intent=Intent("pass", mate.pos, 0.85),
                    note=f"gk pass -> #{mate.num}")

        if d_goal < 16.0:
            aim = Vec2(PITCH_L, PITCH_W / 2.0)   # straight at the middle
            return ActionPlan(
                steer=(aim - me.pos).normalized(), sprint=True,
                buttons=[Touch(Action.SHOOT, 0.45)],
                intent=Intent("shot", aim, 0.95),
                note=f"shot {d_goal:.0f}m",
            )

        if d_opp < 2.5:
            cands = [m for m in s.ours()
                     if m.num != me.num and m.role is not Role.GK]
            if cands:
                mate = max(cands, key=lambda m: m.pos.x)
                return ActionPlan(
                    steer=(mate.pos - me.pos).normalized(), sprint=False,
                    buttons=[Touch(Action.PASS, 0.12)],
                    intent=Intent("pass", mate.pos, 0.85),
                    note=f"pass -> #{mate.num}",
                )

        return ActionPlan(steer=(THEIR_GOAL - me.pos).normalized(),
                          sprint=True, note="straight run")
