"""Trace defensive sequences: our controlled player vs their carrier.

Usage:  python -m sim.def_debug [seed] [max_lines]
"""
from __future__ import annotations

import sys

from bot.brain import Brain
from sim.baseline import SimpleBrain
from sim.match import Match, Side


def main() -> int:
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    max_lines = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    m = Match(seed, Brain(), SimpleBrain())

    shown = 0
    while not m.done and shown < max_lines:
        ctrl = m._controlled_for(Side.US)
        if m.carrier is not None and m.players[m.carrier].team is Side.THEM:
            state = m._snapshot()
            plan = m.brains[Side.US].think(state, ctrl)
            me = m.players[ctrl]
            them = m.players[m.carrier]
            d = me.pos.dist(them.pos)
            print(f"t={m.t:5.0f} carrier#({them.pos.x:.0f},{them.pos.y:.0f}) "
                  f"ctrl#{me.num}({me.pos.x:.0f},{me.pos.y:.0f}) "
                  f"d={d:4.1f} plan='{plan.note}' "
                  f"sprint={plan.sprint} "
                  f"target={plan.move_target}")
            shown += 1
        m.step()
    return 0


if __name__ == "__main__":
    sys.exit(main())
