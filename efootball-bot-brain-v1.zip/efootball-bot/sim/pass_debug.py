"""Trace every US pass flight: launch geometry vs arrival outcome.

Usage:  python -m sim.pass_debug [seed]
"""
from __future__ import annotations

import sys

from bot.brain import Brain
from bot.geom import Vec2
from sim.baseline import SimpleBrain
from sim.match import CLAIM_R, Match, Side


class ProbeMatch(Match):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.launches = []

    def _execute_buttons(self, side, plan):
        if side is Side.US and plan.intent is not None \
                and plan.intent.kind in ("pass", "through"):
            taker = self.players[self.carrier]
            # find nearest teammate to the target = intended receiver
            mates = [p for p in self.players
                     if p.team is Side.US and p.num != taker.num]
            recv = min(mates, key=lambda p: p.pos.dist(plan.intent.target))
            opp, d_opp = None, 999
            for p in self.players:
                if p.team is Side.THEM:
                    d = p.pos.dist(plan.intent.target)
                    if d < d_opp:
                        opp, d_opp = p, d
            self.launches.append({
                "t": self.t, "kind": plan.intent.kind,
                "from": (taker.pos.x, taker.pos.y),
                "to": (plan.intent.target.x, plan.intent.target.y),
                "recv": recv.num,
                "recv_d_at_launch": recv.pos.dist(plan.intent.target),
                "opp_d_at_launch": d_opp,
            })
        super()._execute_buttons(side, plan)

    def _resolve_arrival(self):
        f = self.flight
        if f is not None and f.team is Side.US \
                and f.kind in ("pass", "through") and self.launches:
            rec = self.launches[-1] if self.launches[-1]["t"] >= 0 else None
            # find current nearest of each side to the arrival point
            best = {}
            for i, p in enumerate(self.players):
                d = p.pos.dist(f.to)
                side_key = "us" if p.team is Side.US else "them"
                if side_key not in best or d < best[side_key][1]:
                    best[side_key] = (p.num, d)
            carrier = (self.players[self.carrier].num,
                       self.players[self.carrier].team.name) \
                if self.carrier is not None else None
            print(f"t={rec['t']:5.0f} {rec['kind']:<7} "
                  f"{rec['from']} -> {rec['to']} recv#{rec['recv']} "
                  f"(launch d={rec['recv_d_at_launch']:.1f} "
                  f"opp d={rec['opp_d_at_launch']:.1f}) | "
                  f"arrival nearest: "
                  f"us={best.get('us')} them={best.get('them')} "
                  f"claim={carrier}")
        super()._resolve_arrival()


def main() -> int:
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    m = ProbeMatch(seed, Brain(), SimpleBrain())
    shown = 0
    while not m.done and shown < 60:
        m.step()
        shown = len(m.launches)
    print(f"\ntotal US passes: {len(m.launches)}")
    print(f"completed: {m.stats.passes_ok[Side.US]}/{m.stats.passes[Side.US]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
