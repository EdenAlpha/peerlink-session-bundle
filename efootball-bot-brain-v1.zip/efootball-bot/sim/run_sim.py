"""Run the brain through full simulated matches vs the naive baseline.

Usage (from the project root):
    python -m sim.run_sim [n_matches] [seed0]
"""
from __future__ import annotations

import sys

from bot.brain import Brain
from sim.baseline import SimpleBrain
from sim.match import Match, Side


def run(seed: int) -> Match:
    m = Match(seed, Brain(), SimpleBrain())
    while not m.done:
        m.step()
    return m


def main() -> int:
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    seed0 = int(sys.argv[2]) if len(sys.argv) > 2 else 1

    results = []
    for k in range(n):
        m = run(seed0 + k)
        print(m.report())
        print()
        results.append(m)

    us = sum(1 for m in results if m.score[Side.US] > m.score[Side.THEM])
    draw = sum(1 for m in results
               if m.score[Side.US] == m.score[Side.THEM])
    them = len(results) - us - draw
    gf = sum(m.score[Side.US] for m in results) / len(results)
    ga = sum(m.score[Side.THEM] for m in results) / len(results)
    poss = sum(m.stats.possession[Side.US] for m in results) / len(results)
    poss_all = sum(sum(m.stats.possession.values()) for m in results)
    shots = sum(m.stats.shots[Side.US] for m in results) / len(results)
    pacc = sum(m.stats.passes[Side.US] for m in results)
    pok = sum(m.stats.passes_ok[Side.US] for m in results)

    print("=" * 60)
    print(f"AGGREGATE over {len(results)} matches:")
    print(f"  record      W {us} - D {draw} - L {them}")
    print(f"  goals      {gf:.1f} for / {ga:.1f} against per match")
    print(f"  possession {poss / max(1.0, poss_all / len(results)) * 100:.0f}%")
    print(f"  shots      {shots:.1f} per match | "
          f"pass accuracy {pok}/{pacc} ({pok / max(1, pacc) * 100:.0f}%)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
