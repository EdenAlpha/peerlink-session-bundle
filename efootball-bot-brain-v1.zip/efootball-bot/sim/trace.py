"""Step-by-step tracer for debugging the simulator.

Usage:  python -m sim.trace [steps] [seed]
"""
from __future__ import annotations

import sys

from bot.brain import Brain
from sim.baseline import SimpleBrain
from sim.match import Match, Side


def main() -> int:
    steps = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    m = Match(seed, Brain(), SimpleBrain())

    for k in range(steps):
        t = m.t
        carrier = (f"#{m.players[m.carrier].num}/"
                   f"{m.players[m.carrier].team.name}"
                   ) if m.carrier is not None else "-"
        fl = (f"{m.flight.kind}->{m.flight.to}" if m.flight else "-")
        ball = f"({m.ball.x:.0f},{m.ball.y:.0f})"
        cu = m._controlled_for(Side.US)
        ct = m._controlled_for(Side.THEM)
        us9 = next(p for p in m.players if p.num == 9 and p.team is Side.US)
        them10 = next(p for p in m.players if p.num == 10
                      and p.team is Side.THEM)
        print(f"t={t:5.0f} phase={m.phase.value:<12} carrier={carrier:<10} "
              f"ball={ball:<9} vel={m.ball_vel.length:4.1f} flight={fl:<18} "
              f"ctrl=({cu},{ct}) us9=({us9.pos.x:.0f},{us9.pos.y:.0f}) "
              f"them10=({them10.pos.x:.0f},{them10.pos.y:.0f})")
        m.step()

    print("\nlast events:", m.events[-5:] if m.events else "(none)")
    print("our log tail:", m.our_log[-5:] if m.our_log else "(none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
