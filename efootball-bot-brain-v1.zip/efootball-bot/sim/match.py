"""A simplified but honest 2D match simulator for testing the brain.

What this is NOT: it is not the bit-exact engine replica (that project lives
in /apk_lab — unicorn-driven libUE4.so with the game's own ball kernel).
This is the fast harness the brain needs TODAY: right geometry, plausible
possession flow, and borrowed real constants where the engine research
produced them (quadratic-drag family, speed gates) — placeholder
probabilities everywhere else, clearly marked in the README.

Rules of the harness:
  * 11 v 11 on a 105 x 68 pitch, 1-second steps, 90 game minutes.
  * Each side runs one "brain" with the same think() contract; the away
    side is fed a mirrored GameState so both brains can be written as
    'we attack +x'.
  * Only each side's controlled player obeys its brain; the other 10 hold
    4-3-3 anchors (see bot/tactics.py).
  * Offside is NOT modeled (noted in README). Cards/injuries/fouls: none.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from bot import tactics
from bot.brain import Action, ActionPlan, Brain, mirrored_plan
from bot.geom import Vec2, clamp, point_segment_dist
from bot.state import (
    GOAL_HALF, PITCH_L, PITCH_W, GameState, Phase, Player, Role, Side,
)

# --- speeds / radii ------------------------------------------------------
PASS_SPEED = 16.0
THROUGH_SPEED = 19.0
SHOT_SPEED = 26.0
CROSS_SPEED = 13.0
LOB_SPEED = 13.0
DRIBBLE_SPEED = 6.3
SPRINT_MULT = 1.22
CLAIM_R = 2.0            # arrival-claim radius
PICKUP_R = 1.2            # loose-ball pickup radius
INTERCEPT_R = 1.6
INTERCEPT_P = 0.18         # per-step mid-flight interception chance
TACKLE_R = 1.4
TACKLE_WIN = 0.55
TACKLE_COOLDOWN_S = 2.0   # a defender can't spam the tackle button
SEPARATION_M = 0.7        # two bodies can't occupy the same point
ROLL_DECEL = 3.5          # m/s^2 rolling friction (see README: engine's
                          # quadratic-drag/speed-gate family, simplified)
PASSIVE_CHALLENGE_P = 0.15   # per adjacent non-controlled defender per step
MATCH_LEN_S = 5400.0
HALF_LEN_S = 2700.0
GOAL_LO = PITCH_W / 2 - GOAL_HALF
GOAL_HI = PITCH_W / 2 + GOAL_HALF


@dataclass
class Flight:
    kind: str          # "pass" | "through" | "lob" | "cross" | "shot"
    team: Side         # passing/shooting side
    to: Vec2
    speed: float
    dist_goal: float = 0.0    # at launch, for shot quality
    press: float = 0.0        # 0..0.2, pressure at launch
    completed_to: Optional[Side] = None


@dataclass
class Stats:
    possession: Dict[Side, float] = field(
        default_factory=lambda: {Side.US: 0.0, Side.THEM: 0.0})
    shots: Dict[Side, int] = field(
        default_factory=lambda: {Side.US: 0, Side.THEM: 0})
    on_target: Dict[Side, int] = field(
        default_factory=lambda: {Side.US: 0, Side.THEM: 0})
    passes: Dict[Side, int] = field(
        default_factory=lambda: {Side.US: 0, Side.THEM: 0})
    passes_ok: Dict[Side, int] = field(
        default_factory=lambda: {Side.US: 0, Side.THEM: 0})
    tackles: Dict[Side, int] = field(
        default_factory=lambda: {Side.US: 0, Side.THEM: 0})

    def line(self, side: Side) -> str:
        p = self.possession[side] / max(1.0, sum(self.possession.values()))
        acc = self.passes_ok[side] / max(1, self.passes[side])
        return (f"poss {p * 100:.0f}% | shots {self.shots[side]} "
                f"(on target {self.on_target[side]}) | "
                f"passes {self.passes_ok[side]}/{self.passes[side]} "
                f"({acc * 100:.0f}%) | tackles won {self.tackles[side]}")


class Match:
    def __init__(self, seed: int, home_brain: Brain, away_brain: Brain,
                 name_home: str = "Bot United", name_away: str = "Simple FC"):
        self.rng = random.Random(seed)
        self.seed = seed
        self.brains = {Side.US: home_brain, Side.THEM: away_brain}
        self.names = {Side.US: name_home, Side.THEM: name_away}

        self.players: List[Player] = (tactics.build_squad(Side.US)
                                     + tactics.build_squad(Side.THEM))
        self.t = 0.0
        self.half = 1
        self.score = {Side.US: 0, Side.THEM: 0}
        self.ball = Vec2(PITCH_L / 2, PITCH_W / 2)
        self.ball_vel = Vec2(0.0, 0.0)
        self.carrier: Optional[int] = None
        self.flight: Optional[Flight] = None
        self.phase = Phase.OPEN_PLAY
        self.last_touch: Side = Side.US
        self.stats = Stats()
        self.events: List[str] = []
        self.our_log: List[Tuple[float, str]] = []   # (t, note) button decisions
        self.done = False
        self._restart_guard = 0
        self._last_tackle_t: Dict[int, float] = {}   # player index -> time

        self._place_kickoff(Side.US)

    # ------------------------------------------------------------- snapshots

    def _snapshot(self) -> GameState:
        players = [Player(num=p.num, team=p.team, role=p.role, pos=p.pos,
                         vel=p.vel, speed=p.speed) for p in self.players]
        return GameState(
            time_s=self.t, half=self.half,
            score_us=self.score[Side.US], score_them=self.score[Side.THEM],
            ball=self.ball, ball_vel=self.ball_vel, carrier=self.carrier,
            players=players, phase=self.phase,
            ball_landing=self.flight.to if self.flight is not None else None,
        )

    def _controlled_for(self, side: Side) -> int:
        if self.carrier is not None \
                and self.players[self.carrier].team is side:
            return self.carrier
        cands = [i for i, p in enumerate(self.players)
                 if p.team is side and p.role is not Role.GK]
        return min(cands, key=lambda i: self.players[i].pos.dist(self.ball))

    # ------------------------------------------------------------------ step

    def step(self, dt: float = 1.0) -> None:
        if self.done:
            return
        state = self._snapshot()
        ctrl_us = self._controlled_for(Side.US)
        ctrl_them = self._controlled_for(Side.THEM)

        plan_us = self.brains[Side.US].think(state, ctrl_us)
        m_state = state.mirrored()
        plan_them = mirrored_plan(self.brains[Side.THEM].think(m_state,
                                                               ctrl_them))

        if plan_us.buttons:
            self.our_log.append((self.t, plan_us.note))

        we_have_ball = (self.carrier is not None
                        and self.players[self.carrier].team is Side.US)
        # alternate who moves first each step: a fixed order hands one side
        # a permanent half-step advantage in every race
        order = [Side.US, Side.THEM] if int(self.t) % 2 == 0 \
            else [Side.THEM, Side.US]
        self._move_side(order[0], ctrl_us if order[0] is Side.US else ctrl_them,
                        plan_us if order[0] is Side.US else plan_them, dt,
                        we_have_ball)
        self._move_side(order[1], ctrl_us if order[1] is Side.US else ctrl_them,
                        plan_us if order[1] is Side.US else plan_them, dt,
                        we_have_ball)
        self._separate()

        self._resolve_tackles(ctrl_us, plan_us, ctrl_them, plan_them)
        self._passive_challenges()
        self._execute_buttons(Side.US, plan_us)
        self._execute_buttons(Side.THEM, plan_them)

        if self.carrier is not None:
            c = self.players[self.carrier]
            facing = c.vel.normalized() if c.vel.length > 0.5 else \
                (Vec2(1, 0) if c.team is Side.US else Vec2(-1, 0))
            self.ball = c.pos + facing * 0.8
            self.ball_vel = c.vel
            self.stats.possession[c.team] += dt
        elif self.flight is not None:
            self._advance_flight(dt)
        else:
            self._roll_and_pickup(dt)

        self._out_of_bounds()

        self.t += dt
        if self.half == 1 and self.t >= HALF_LEN_S:
            self.half = 2
            self.events.append(f"{self._min()}' HT")
        if self.t >= MATCH_LEN_S:
            self.done = True
            self.events.append(f"{self._min()}' FT")

        # restart safeguard: never sit in a set-piece phase for long
        if self.phase is not Phase.OPEN_PLAY:
            self._restart_guard += 1
            if self._restart_guard > 2:
                self.phase = Phase.OPEN_PLAY
        else:
            self._restart_guard = 0

    def _roll_and_pickup(self, dt: float) -> None:
        """Loose ball on the deck: roll it, decelerate it, let players
        pick it up."""
        spd = self.ball_vel.length
        if spd > 0.05:
            self.ball = (self.ball + self.ball_vel * dt).clamped(
                Vec2(0.0, 0.0), Vec2(PITCH_L, PITCH_W))
            new_spd = max(0.0, spd - ROLL_DECEL * dt)
            self.ball_vel = self.ball_vel.normalized() * new_spd
        else:
            self.ball_vel = Vec2(0.0, 0.0)

        # nearest player within pickup radius takes possession
        best, bd = None, PICKUP_R
        for i, p in enumerate(self.players):
            d = p.pos.dist(self.ball)
            if d < bd:
                best, bd = i, d
        if best is not None:
            self.carrier = best

    def _separate(self) -> None:
        """No two bodies in the same spot: everyone except the carrier is
        pushed out of a small ring around him. Keeps a presser from
        standing INSIDE the man he's marking."""
        if self.carrier is None:
            return
        c = self.players[self.carrier].pos
        for i, p in enumerate(self.players):
            if i == self.carrier:
                continue
            away = p.pos - c
            d = away.length
            if d < SEPARATION_M:
                if d < 1e-6:
                    away = Vec2(1.0, 0.0)
                    d = 1.0
                p.pos = c + away.normalized() * SEPARATION_M

    def _min(self) -> int:
        return int(self.t // 60) + 1

    # -------------------------------------------------------------- movement

    def _move_side(self, side: Side, ctrl_i: int, plan: ActionPlan, dt: float,
                   we_have_ball: bool) -> None:
        for i, p in enumerate(self.players):
            if p.team is not side:
                continue
            if i == ctrl_i and plan.steer.length > 0.05:
                base = DRIBBLE_SPEED if i == self.carrier else p.speed
                spd = base * (SPRINT_MULT if plan.sprint else 1.0)
                stride = spd * dt
                if plan.move_target is not None:
                    # stop ON the target instead of a full stride past it
                    stride = min(stride, p.pos.dist(plan.move_target))
                mv = plan.steer * stride
            else:
                tgt = tactics.target_for(p, self.ball, we_have_ball)
                d = p.pos.dist(tgt)
                if d < 0.5:
                    p.vel = Vec2(0.0, 0.0)
                    continue
                mv = (tgt - p.pos).normalized() * min(p.speed * 0.9 * dt, d)
            old = p.pos
            p.pos = (p.pos + mv).clamped(Vec2(0.5, 0.5),
                                         Vec2(PITCH_L - 0.5, PITCH_W - 0.5))
            p.vel = (p.pos - old) / dt

    # --------------------------------------------------------------- tackles

    def _resolve_tackles(self, cu: int, pu: ActionPlan, ct: int,
                         pt: ActionPlan) -> None:
        order = [(Side.US, cu, pu), (Side.THEM, ct, pt)]
        if self.rng.random() < 0.5:
            order.reverse()
        for side, ctrl, plan in order:
            if Action.TACKLE not in [t.action for t in plan.buttons]:
                continue
            if self.carrier is None:
                continue
            victim = self.players[self.carrier]
            if victim.team is side:
                continue                     # can't tackle yourself
            if self._last_tackle_t.get(ctrl, -99.0) > self.t - TACKLE_COOLDOWN_S:
                continue                     # on the floor, recovering
            if self.players[ctrl].pos.dist(victim.pos) > TACKLE_R + 0.15:
                continue
            self._last_tackle_t[ctrl] = self.t
            roll = self.rng.random()
            if roll < TACKLE_WIN:
                self.carrier = ctrl
                self.stats.tackles[side] += 1
                self.phase = Phase.OPEN_PLAY
            elif roll < TACKLE_WIN + 0.18:   # ball squirts loose
                self.carrier = None
                jitter = Vec2(self.rng.uniform(-2, 2), self.rng.uniform(-2, 2))
                self.ball = (victim.pos + jitter).clamped(
                    Vec2(1, 1), Vec2(PITCH_L - 1, PITCH_W - 1))
                self.ball_vel = jitter
                self.phase = Phase.OPEN_PLAY

    # ---------------------------------------------------------------- passes

    def _passive_challenges(self) -> None:
        """Standing challenges by non-controlled defenders who happen to be
        right on top of the carrier. Models the teammate AI every football
        game has: a straight-line dribbler can't ghost through a back line."""
        if self.carrier is None:
            return
        victim = self.players[self.carrier]
        for i, p in enumerate(self.players):
            if p.team is victim.team or i == self.carrier:
                continue
            if p.pos.dist(victim.pos) < 1.1 \
                    and self.rng.random() < PASSIVE_CHALLENGE_P:
                self.carrier = i
                self.stats.tackles[p.team] += 1
                return

    def _execute_buttons(self, side: Side, plan: ActionPlan) -> None:
        if plan.intent is None or self.carrier is None:
            return
        if self.players[self.carrier].team is not side:
            return
        it = plan.intent
        taker = self.players[self.carrier]
        d_goal = taker.pos.dist(
            Vec2(0, PITCH_W / 2) if side is Side.THEM else
            Vec2(PITCH_L, PITCH_W / 2))

        speed = {"pass": PASS_SPEED, "through": THROUGH_SPEED,
                 "lob": LOB_SPEED, "cross": CROSS_SPEED}.get(it.kind)
        if it.kind == "shot":
            speed = SHOT_SPEED * (0.82 + 0.30 * it.power)
            scatter = self.rng.uniform(-2.4, 2.4) * (0.5 + 0.5 * it.power)
            to = Vec2(it.target.x, clamp(it.target.y + scatter, 24.0, 44.0))
            d_opp = min((p.pos.dist(taker.pos) for p in self.players
                         if p.team is not side), default=99.0)
            press = 0.18 if d_opp < 2.0 else 0.0
            self.stats.shots[side] += 1
            self.flight = Flight("shot", side, to, speed, d_goal, press)
        else:
            if it.kind in ("pass", "through"):
                self.stats.passes[side] += 1
            self.flight = Flight(it.kind, side, it.target, speed)

        self.carrier = None
        self.last_touch = side
        self.phase = Phase.OPEN_PLAY
        self._restart_guard = 0

    def _advance_flight(self, dt: float) -> None:
        f = self.flight
        assert f is not None
        prev = self.ball
        remain = f.to.dist(self.ball)
        step_len = f.speed * dt
        if remain <= step_len + 0.05:
            self.ball = f.to
            self.ball_vel = Vec2(0.0, 0.0)
            self._resolve_arrival()
            return
        direction = (f.to - self.ball).normalized()
        self.ball = self.ball + direction * step_len
        self.ball_vel = direction * f.speed
        # mid-flight interception by the defending side
        for i, p in enumerate(self.players):
            if p.team is f.team or p.role is Role.GK:
                continue
            if point_segment_dist(p.pos, prev, self.ball) < INTERCEPT_R \
                    and self.rng.random() < INTERCEPT_P:
                self.carrier = i
                self.flight = None
                return

    def _resolve_arrival(self) -> None:
        f = self.flight
        self.flight = None
        assert f is not None

        if f.kind == "shot":
            self._resolve_shot_arrival(f)
            return

        # claim contested ball at the landing spot. The passing side's
        # nearest man has read the pass; the interceptor is guessing —
        # ties go to the receiver 65/35 and any real closeness wins clean
        near_us = near_them = None
        for i, p in enumerate(self.players):
            d = p.pos.dist(f.to)
            if d > CLAIM_R:
                continue
            if p.team is f.team and (near_us is None
                                    or d < near_us[1]):
                near_us = (i, d)
            if p.team is not f.team and (near_them is None
                                         or d < near_them[1]):
                near_them = (i, d)
        winner = None
        if near_us is not None and near_them is not None:
            if near_them[1] + 0.5 < near_us[1]:
                winner = near_them
            elif near_us[1] + 0.5 < near_them[1] or \
                    near_us[1] <= near_them[1]:
                winner = near_us
            elif self.rng.random() < 0.35:
                winner = near_them
            else:
                winner = near_us
        else:
            winner = near_us or near_them
        if winner is not None:
            self.carrier = winner[0]
            if self.players[winner[0]].team is f.team \
                    and f.kind in ("pass", "through"):
                self.stats.passes_ok[f.team] += 1
        else:
            # nobody there: ball rolls on with residual pace
            direction = (f.to - self.ball).normalized()
            self.ball_vel = direction * f.speed * 0.22

    def _resolve_shot_arrival(self, f: Flight) -> None:
        assert f.kind == "shot"
        on_target = GOAL_LO <= f.to.y <= GOAL_HI
        if on_target:
            self.stats.on_target[f.team] += 1
            p_goal = clamp(0.26 - 0.008 * f.dist_goal - f.press, 0.02, 0.28)
            if self.rng.random() < p_goal:
                self._goal(f.team)
                return
            # saved: keeper gathers
            gk = next(p for p in self.players
                      if p.team is not f.team and p.role is Role.GK)
            gk.pos = Vec2(clamp(f.to.x - 1.5, 1.0, PITCH_L - 1.0),
                          clamp(f.to.y, 26.0, 42.0))
            self.carrier = self.players.index(gk)
            self.ball = gk.pos + Vec2(0, 1.0)
        else:
            self.events.append(f"{self._min()}' shot off target "
                               f"({self.names[f.team]})")
            defending = Side.THEM if f.team is Side.US else Side.US
            self._restart_goal_kick(defending)

    # -------------------------------------------------------------- outcomes

    def _goal(self, scorer: Side) -> None:
        self.score[scorer] += 1
        buildup = ""
        if scorer is Side.US and self.our_log:
            notes = [n for _, n in self.our_log[-4:]]
            buildup = " [" + "; ".join(notes) + "]"
        self.events.append(f"{self._min()}' GOAL {self.names[scorer]}"
                            f" ({self.score[Side.US]}-{self.score[Side.THEM]})"
                            f"{buildup}")
        other = Side.THEM if scorer is Side.US else Side.US
        self._place_kickoff(other)

    def _out_of_bounds(self) -> None:
        if self.flight is not None or self.carrier is not None:
            return
        b = self.ball
        if b.y < 0.3 or b.y > PITCH_W - 0.3:
            team = Side.THEM if self.last_touch is Side.US else Side.US
            pos = Vec2(clamp(b.x, 1.0, PITCH_L - 1.0),
                      0.6 if b.y < PITCH_W / 2 else PITCH_W - 0.6)
            self._restart_throw_in(team, pos)
            return
        if b.x < 0.3:
            if GOAL_LO <= b.y <= GOAL_HI:
                self._goal(Side.THEM)
            elif self.last_touch is Side.THEM:
                self._restart_goal_kick(Side.US)
            else:
                self._restart_corner(Side.THEM, Vec2(0.6, b.y))
            return
        if b.x > PITCH_L - 0.3:
            if GOAL_LO <= b.y <= GOAL_HI:
                self._goal(Side.US)
            elif self.last_touch is Side.US:
                self._restart_goal_kick(Side.THEM)
            else:
                self._restart_corner(Side.US,
                                     Vec2(PITCH_L - 0.6, b.y))

    # ------------------------------------------------------------- restarts

    def _restart_throw_in(self, team: Side, pos: Vec2) -> None:
        self._set_restart(team, pos, Phase.THROWIN_US if team is Side.US
                          else Phase.THROWIN_THEM)

    def _restart_goal_kick(self, team: Side) -> None:
        pos = Vec2(5.5 if team is Side.US else PITCH_L - 5.5, PITCH_W / 2)
        self._set_restart(team, pos, Phase.GOALKICK_US if team is Side.US
                          else Phase.GOALKICK_THEM, gk_takes=True)

    def _restart_corner(self, team: Side, pos: Vec2) -> None:
        pos = Vec2(clamp(pos.x, 0.6, PITCH_L - 0.6),
                   0.6 if pos.y < PITCH_W / 2 else PITCH_W - 0.6)
        self._set_restart(team, pos, Phase.CORNER_US if team is Side.US
                          else Phase.CORNER_THEM)

    def _set_restart(self, team: Side, pos: Vec2, phase: Phase,
                     gk_takes: bool = False) -> None:
        self.flight = None
        self.ball = pos
        self.ball_vel = Vec2(0.0, 0.0)
        if gk_takes:
            taker = next(p for p in self.players
                         if p.team is team and p.role is Role.GK)
        else:
            taker = min((p for p in self.players
                         if p.team is team and p.role is not Role.GK),
                        key=lambda p: p.pos.dist(pos))
        taker.pos = pos
        self.carrier = self.players.index(taker)
        self.last_touch = team
        self.phase = phase
        self._restart_guard = 0

    def _place_kickoff(self, team: Side) -> None:
        for p in self.players:
            _, anchor = tactics.ANCHORS_433[p.num]
            if p.team is Side.US:
                p.pos = Vec2(min(anchor.x, 46.0), anchor.y)
            else:
                p.pos = Vec2(max(PITCH_L - anchor.x, PITCH_L - 46.0), anchor.y)
            p.vel = Vec2(0.0, 0.0)
        taker = next(p for p in self.players
                     if p.team is team and p.num == 9)
        taker.pos = Vec2(PITCH_L / 2 - 0.5 if team is Side.US
                         else PITCH_L / 2 + 0.5, PITCH_W / 2)
        self.ball = taker.pos + Vec2(0.5 if team is Side.US else -0.5, 0.0)
        self.ball_vel = Vec2(0.0, 0.0)
        self.carrier = self.players.index(taker)
        self.flight = None
        self.last_touch = team
        self.phase = Phase.KICKOFF_US if team is Side.US \
            else Phase.KICKOFF_THEM
        self._restart_guard = 0

    # ---------------------------------------------------------------- report

    def report(self) -> str:
        lines = [f"--- {self.names[Side.US]} {self.score[Side.US]} - "
                 f"{self.score[Side.THEM]} {self.names[Side.THEM]} "
                 f"(seed {self.seed}) ---"]
        lines.extend(f"  {e}" for e in self.events)
        lines.append(f"  us   : {self.stats.line(Side.US)}")
        lines.append(f"  them : {self.stats.line(Side.THEM)}")
        return "\n".join(lines)
