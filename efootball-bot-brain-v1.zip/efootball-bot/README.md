# eFootball Bot — the Brain (v1)

This is the piece that was missing from all the engine research in `apk_lab`:
the player. Everything there (bit-exact ball kernel, match-state
construction) described the GAME; this package is what actually plays it —
the decision engine that gets called once per second, looks at the match,
and answers one question: **what do I do right now?**

It runs the real game in an emulator on your PC (LDPlayer 9), logged in as
a normal player. Friends join a friendly room from their phones with a
6-digit code, exactly like any other friendly. No private servers, no fake
clients, nothing talking to Konami's servers except the genuine game
client itself.

## Status

| piece                          | file               | status                        |
|--------------------------------|--------------------|-------------------------------|
| decision brain (1 Hz)          | `bot/brain.py`     | done — 12/12 scenario tests   |
| game-state model               | `bot/state.py`     | done                          |
| off-ball tactics (sim only)    | `bot/tactics.py`   | done                          |
| match simulator                | `sim/`             | done — arcade, see below      |
| scenario tests                 | `tests/`           | 12/12 passing                 |
| touch controller (ADB)         | `bot/controller.py`| skeleton — needs emulator     |
| vision (screen -> state)       | —                  | next — needs emulator         |

## Layout

```
efootball-bot/
├── bot/
│   ├── geom.py        2D vectors, lanes, point-segment distance
│   ├── state.py       GameState: players, ball, phase + mirror support
│   ├── brain.py       THE BRAIN: think(state, controlled) -> ActionPlan
│   ├── tactics.py     4-3-3 anchors (sim's off-ball movement)
│   └── controller.py  ActionPlan -> adb touches (skeleton)
├── sim/
│   ├── match.py       90-minute match engine (1 s steps)
│   ├── baseline.py    SimpleBrain: deliberately naive sparring partner
│   ├── run_sim.py     run matches, print reports
│   ├── trace.py       per-step game tracer (debugging)
│   ├── pass_debug.py  trace every pass launch -> arrival (debugging)
│   └── def_debug.py   trace our defense vs their carrier (debugging)
└── tests/
    └── test_brain.py  12 frozen match situations, assert the plan
```

## Run it

From this directory:

```
python -m tests.test_brain     # 12 scenario tests
python -m sim.run_sim 3       # brain vs baseline, 3 matches
python -m sim.trace 30        # watch 30 seconds of a match step by step
```

No dependencies — pure standard library Python 3.10+.

## What the brain decides (one second at a time)

**With the ball** (priority order):
1. **Shoot** — inside 21 m with a clean lane to the far post (away from
   the keeper's position); power scales with distance. Losing after the
   78th minute widens the range by 5 m — chase the game.
2. **Through ball** — a runner ahead of the ball whose landing spot is
   beyond their last defender, through a clean lane, into open space.
   6-second cooldown so it isn't spammed.
3. **Pass** — when pressed inside 3.2 m, to the best open teammate
   (openness + progress + lane clearance scored; never back to the keeper;
   never into our own box; lanes out of our own third need extra air).
4. **Clearance** — pressed inside 1.4 m with no pass on: hoof it long and
   wide. Honest football.
5. **Dribble** — carry at their goal, repelling around the two nearest
   defenders, hard touchline and own-box rules, sprint only in open field.

**Keeper with the ball**: unpressed -> open short option; pressed ->
long and wide. Never dribbles out.

**Without the ball**:
- Their carrier: iterated **pursuit intercept** (run to where our paths
  cross — chasing his current spot against a 7.7 m/s runner means being a
  permanent 7 m shadow), tackle the moment we're in lunge range.
- Loose ball: run to where it **lands**, not where it is.
- Keeper: hold the line between ball and goal center.

**Set pieces**: kickoff -> simple release; goal kick -> open defender or
long; corner -> far-post cross; throw-in -> nearest open man.

## Simulator results — read this honestly

Brain vs naive baseline over 3 seeded matches:

```
record: 0 W - 0 D - 3 L, ~7.7 goals for / 23.7 against per match
possession 29% | our shots 47/match | pass accuracy 45%
```

The brain LOSES to a dumb opponent. That is a real result, and it's mostly
a statement about the simulator, not the brain:

- The baseline plays max-volume football (dribble straight at goal, shoot
  from 16 m, always). In an arcade with 13% shot conversion, no fatigue,
  no offside and perfect dribble control, volume wins.
- The sim's off-ball "teammates" are anchors, not footballers — the
  brain's patient, structured style (pass, move, create angles) has no
  one to pass to who behaves like a real teammate.

What the sim WAS for — and delivered on — is bug-hunting. It caught six
real brain bugs no unit test would have shown:
1. chase overshoot (players sailing past the ball, oscillating around it)
2. receivers running to the wrong side of flying passes (ball+vel/2
   prediction overshoots a 16 m/s ball by 8 m — fixed with `ball_landing`)
3. tackle range measured against a 0.35 s projection of the runner —
   unreachable by construction, so the brain could never tackle
4. jockeying to a stand-off point 1.5 m outside tackle range — same
   disease, different symptom
5. chasing the carrier's current spot instead of an intercept point —
   a permanent 7 m shadow on any sprinter
6. keeper distributing short into pressure — instant concession loop

Plus sim-side fixes: mirror recursion, dead-ball freeze, body separation,
receiver-advantage claims, alternating move order.

**The numbers that matter will come from the live emulator loop, not from
this harness.** Every probability in `sim/match.py` is a placeholder until
then; the constants inherited from the engine research (the ball-drag
family, quadratic drag with speed gates at 10/85 km/h, effective airRegist
~0.4, g_eff 10.19 m/s²) are the only ones with real lineage — see
`apk_lab/analysis/FINDINGS.md`.

## Relationship to the apk_lab engine work

The decision brain doesn't touch it, deliberately. Two possible bridges
later, both optional:
- The bit-exact unicorn-driven ball kernel can replace this sim's invented
  flight physics when we want a high-fidelity practice environment.
- The match-state construction work (M9/M10) informs what a future
  "perfect vision" could know. Not required for live play.

## What needs the emulator (next session)

1. `adb connect 127.0.0.1:5555` to LDPlayer, screenshot loop at 1-2 Hz.
2. **Calibrate the touch layout**: screenshot your eFootball control
   scheme, locate buttons, write `layout.json` (`_calibrated: true`).
3. **Vision**: read the HUD (score, clock) and estimate players/ball
   positions per frame -> fill `GameState` (with `ball_landing` estimated
   from two frames).
4. **The 1 Hz loop**: `state = vision(); plan = brain.think(state, ctrl);
   controller.execute(plan)`.
5. **Multitouch v2**: raw `sendevent` so the stick holds while buttons
   press (v1 sequences single touches — works, drops movement ~100 ms
   around each press).
6. Friendly room: create it from the alt account in the emulator, send
   friends the 6-digit code, play.

## Tuning knobs

All in `BrainConfig` (`bot/brain.py`). The ones most likely to need
live-game recalibration: `shoot_range_m`, `shot_clearance_m`,
`pressure_pass_m`, `tackle_range_m`, and the hold-time mapping in
`controller.py` (shot power -> button milliseconds).
